import Foundation
import SwiftUI

struct PosterItem: Identifiable, Hashable {
    let kind: Kind
    let contentId: String
    let title: String
    let image: String
    let backdrop: String
    let rating: Double
    let year: String
    let genre: String
    let plot: String
    let ext: String
    let categoryId: String
    let added: Int64

    var id: String { kind.rawValue + ":" + contentId }
    var ratingText: String { rating > 0 ? String(format: "%.1f", rating) : "" }
    var yearText: String { Txt.year(year).map { String($0) } ?? Txt.year(title).map { String($0) } ?? "" }

    init(_ v: Vod) {
        kind = .movie; contentId = v.id; title = v.name; image = v.icon; backdrop = ""; rating = v.rating
        year = v.year; genre = v.genre; plot = v.plot; ext = v.ext; categoryId = v.categoryId; added = v.added
    }

    init(_ s: SeriesItem) {
        kind = .series; contentId = s.id; title = s.name; image = s.cover; backdrop = s.backdrop; rating = s.rating
        year = s.year; genre = s.genre; plot = s.plot; ext = "mp4"; categoryId = s.categoryId; added = s.added
    }
}

enum RowStyle { case poster, top10, wide, continueWatching }

struct HomeRow: Identifiable {
    let id: String
    let title: String
    let style: RowStyle
    let items: [PosterItem]
}

struct HomeData {
    var hero: [PosterItem] = []
    var top10: [PosterItem] = []
    var newMovies: [PosterItem] = []
    var newSeries: [PosterItem] = []
    var genreRows: [HomeRow] = []
    var popular: [PosterItem] = []
}

/// Catálogo Xtream con caché en disco (como CatalogCache en Android).
@MainActor
final class CatalogStore: ObservableObject {
    @Published private(set) var liveCats: [Category] = []
    @Published private(set) var live: [Channel] = []
    @Published private(set) var vodCats: [Category] = []
    @Published private(set) var vods: [Vod] = []
    @Published private(set) var seriesCats: [Category] = []
    @Published private(set) var series: [SeriesItem] = []
    @Published private(set) var home = HomeData()
    @Published private(set) var loading = false
    @Published private(set) var ready = false
    @Published private(set) var updatedAt: Date? = nil
    @Published private(set) var kids = false
    @Published private(set) var lastRefreshOK = false

    private var raw = RawCatalog()
    private var creds: Creds?
    private var refreshTask: Task<Void, Never>?

    private(set) var vodById: [String: Vod] = [:]
    private(set) var seriesById: [String: SeriesItem] = [:]
    private(set) var liveById: [String: Channel] = [:]
    private(set) var catNames: [String: String] = [:]

    struct RawCatalog {
        var liveCats: [Category] = []
        var live: [Channel] = []
        var vodCats: [Category] = []
        var vods: [Vod] = []
        var seriesCats: [Category] = []
        var series: [SeriesItem] = []
    }

    private static func cacheDir(_ c: Creds) -> URL {
        let key = String(Txt.sha256("\(c.base)|\(c.user.lowercased())").prefix(16))
        let d = FileManager.default.urls(for: .cachesDirectory, in: .userDomainMask)[0].appendingPathComponent("catalog/\(key)", isDirectory: true)
        try? FileManager.default.createDirectory(at: d, withIntermediateDirectories: true)
        return d
    }

    func start(_ c: Creds, kids k: Bool) {
        if creds == c {
            if k != kids { setKids(k) }
            return
        }
        creds = c
        kids = k
        ready = false
        raw = RawCatalog()
        apply()
        let dir = Self.cacheDir(c)
        Task {
            let cached = await Task.detached(priority: .userInitiated) { () -> (RawCatalog, Date?) in
                CatalogStore.readCache(dir)
            }.value
            guard self.creds == c else { return }
            if !cached.0.vods.isEmpty || !cached.0.live.isEmpty {
                self.raw = cached.0
                self.updatedAt = cached.1
                self.apply()
            }
            let stale = (cached.1 ?? .distantPast).timeIntervalSinceNow < -6 * 3600
            if stale || cached.0.vods.isEmpty && cached.0.live.isEmpty { self.refresh() }
        }
    }

    func stop() {
        refreshTask?.cancel()
        creds = nil
        raw = RawCatalog()
        ready = false
        apply()
    }

    func setKids(_ k: Bool) {
        kids = k
        apply()
    }

    nonisolated private static func readCache(_ dir: URL) -> (RawCatalog, Date?) {
        func data(_ a: String) -> Data? { try? Data(contentsOf: dir.appendingPathComponent(a + ".json")) }
        var r = RawCatalog()
        r.liveCats = XtreamParse.categories(data("get_live_categories"))
        r.live = XtreamParse.live(data("get_live_streams"))
        r.vodCats = XtreamParse.categories(data("get_vod_categories"))
        r.vods = XtreamParse.vods(data("get_vod_streams"))
        r.seriesCats = XtreamParse.categories(data("get_series_categories"))
        r.series = XtreamParse.series(data("get_series"))
        let date = (try? FileManager.default.attributesOfItem(atPath: dir.appendingPathComponent("get_vod_streams.json").path)[.modificationDate]) as? Date
        return (r, date)
    }

    /// Descarga todo de nuevo sin cerrar la app.
    func refresh(completion: ((Bool) -> Void)? = nil) {
        guard let c = creds else { completion?(false); return }
        refreshTask?.cancel()
        loading = true
        let dir = Self.cacheDir(c)
        refreshTask = Task {
            let fetched = await Task.detached(priority: .userInitiated) { () -> (RawCatalog, Int) in
                await CatalogStore.download(c, dir)
            }.value
            guard !Task.isCancelled, self.creds == c else { return }
            self.loading = false
            self.lastRefreshOK = fetched.1 > 0
            if fetched.1 > 0 {
                var r = self.raw
                if !fetched.0.liveCats.isEmpty || !fetched.0.live.isEmpty { r.liveCats = fetched.0.liveCats; r.live = fetched.0.live }
                if !fetched.0.vods.isEmpty { r.vodCats = fetched.0.vodCats; r.vods = fetched.0.vods }
                if !fetched.0.series.isEmpty { r.seriesCats = fetched.0.seriesCats; r.series = fetched.0.series }
                self.raw = r
                self.updatedAt = Date()
                self.apply()
            } else if !self.ready {
                self.ready = true
            }
            completion?(fetched.1 > 0)
        }
    }

    func refreshNow() async -> Bool {
        refresh()
        await refreshTask?.value
        return lastRefreshOK
    }

    nonisolated private static func download(_ c: Creds, _ dir: URL) async -> (RawCatalog, Int) {
        var r = RawCatalog()
        var okCount = 0
        let actions = ["get_live_categories", "get_live_streams", "get_vod_categories", "get_vod_streams", "get_series_categories", "get_series"]
        await withTaskGroup(of: (String, Data?).self) { group in
            for a in actions {
                group.addTask {
                    let timeout: TimeInterval = a.hasSuffix("streams") || a == "get_series" ? 120 : 30
                    var d = try? await Xtream.fetch(c, a, timeout: timeout)
                    if d == nil { d = try? await Xtream.fetch(c, a, timeout: timeout) }
                    return (a, d)
                }
            }
            for await (a, d) in group {
                guard let d = d else { continue }
                try? d.write(to: dir.appendingPathComponent(a + ".json"), options: .atomic)
                okCount += 1
                switch a {
                case "get_live_categories": r.liveCats = XtreamParse.categories(d)
                case "get_live_streams": r.live = XtreamParse.live(d)
                case "get_vod_categories": r.vodCats = XtreamParse.categories(d)
                case "get_vod_streams": r.vods = XtreamParse.vods(d)
                case "get_series_categories": r.seriesCats = XtreamParse.categories(d)
                default: r.series = XtreamParse.series(d)
                }
            }
        }
        return (r, okCount)
    }

    struct Applied {
        var liveCats: [Category] = []
        var live: [Channel] = []
        var vodCats: [Category] = []
        var vods: [Vod] = []
        var seriesCats: [Category] = []
        var series: [SeriesItem] = []
        var names: [String: String] = [:]
        var vodById: [String: Vod] = [:]
        var seriesById: [String: SeriesItem] = [:]
        var liveById: [String: Channel] = [:]
        var home = HomeData()
    }

    private var applyToken = 0

    /// Aplica el filtro Kids y arma el Inicio fuera del hilo principal.
    private func apply() {
        applyToken += 1
        let token = applyToken
        let r = raw
        let k = kids
        if r.vods.isEmpty && r.live.isEmpty && r.series.isEmpty {
            liveCats = []; live = []; vodCats = []; vods = []; seriesCats = []; series = []
            vodById = [:]; seriesById = [:]; liveById = [:]; catNames = [:]; home = HomeData()
            return
        }
        Task {
            let out = await Task.detached(priority: .userInitiated) { CatalogStore.compute(r, kids: k) }.value
            guard token == self.applyToken else { return }
            self.catNames = out.names
            self.liveCats = out.liveCats; self.live = out.live
            self.vodCats = out.vodCats; self.vods = out.vods
            self.seriesCats = out.seriesCats; self.series = out.series
            self.vodById = out.vodById; self.seriesById = out.seriesById; self.liveById = out.liveById
            self.home = out.home
            self.ready = true
        }
    }

    nonisolated private static func compute(_ r: RawCatalog, kids k: Bool) -> Applied {
        var a = Applied()
        var names: [String: String] = [:]
        for c in r.liveCats { names["tv:" + c.id] = c.name }
        for c in r.vodCats { names["movie:" + c.id] = c.name }
        for c in r.seriesCats { names["series:" + c.id] = c.name }
        a.names = names
        if k {
            a.live = r.live.filter { KidsFilter.canalPermitido(nombre: $0.name, categoria: names["tv:" + $0.categoryId] ?? "") }
            a.vods = r.vods.filter { KidsFilter.contenidoPermitido(nombre: $0.name, genero: $0.genre, categoria: names["movie:" + $0.categoryId] ?? "") }
            a.series = r.series.filter { KidsFilter.contenidoPermitido(nombre: $0.name, genero: $0.genre, categoria: names["series:" + $0.categoryId] ?? "") }
            let liveIds = Set(a.live.map { $0.categoryId }), vodIds = Set(a.vods.map { $0.categoryId }), serIds = Set(a.series.map { $0.categoryId })
            a.liveCats = r.liveCats.filter { liveIds.contains($0.id) }
            a.vodCats = r.vodCats.filter { vodIds.contains($0.id) }
            a.seriesCats = r.seriesCats.filter { serIds.contains($0.id) }
        } else {
            a.live = r.live; a.vods = r.vods; a.series = r.series
            a.liveCats = r.liveCats; a.vodCats = r.vodCats; a.seriesCats = r.seriesCats
        }
        a.vodById.reserveCapacity(r.vods.count)
        for v in r.vods { a.vodById[v.id] = v }
        a.seriesById.reserveCapacity(r.series.count)
        for s in r.series { a.seriesById[s.id] = s }
        a.liveById.reserveCapacity(r.live.count)
        for l in r.live { a.liveById[l.id] = l }
        a.home = HomeBuilder.build(HomeBuilder.Input(vods: a.vods, series: a.series, names: names, kids: k))
        return a
    }

    // MARK: Consultas

    func categoryName(_ kind: Kind, _ id: String) -> String { catNames["\(kind.rawValue):\(id)"] ?? "" }

    func isAdultCategory(_ kind: Kind, _ id: String) -> Bool { KidsFilter.esAdulto(categoryName(kind, id)) }

    func poster(_ kind: Kind, _ id: String) -> PosterItem? {
        switch kind {
        case .movie: return vodById[id].map { PosterItem($0) }
        case .series: return seriesById[id].map { PosterItem($0) }
        case .tv: return nil
        }
    }

    func items(_ kind: Kind) -> [PosterItem] {
        kind == .movie ? vods.map { PosterItem($0) } : series.map { PosterItem($0) }
    }

    func cats(_ kind: Kind) -> [Category] {
        switch kind {
        case .movie: return vodCats
        case .series: return seriesCats
        case .tv: return liveCats
        }
    }
}

// MARK: - Armado del Inicio (fuera del hilo principal)

enum HomeBuilder {
    struct Input {
        let vods: [Vod]
        let series: [SeriesItem]
        let names: [String: String]
        let kids: Bool
    }

    struct Zone {
        let title: String
        let keys: [String]
        let style: RowStyle
    }

    static let zones: [Zone] = [
        Zone(title: "Acción", keys: ["accion", "action", "aventura", "adventure"], style: .poster),
        Zone(title: "Comedia", keys: ["comedia", "comedy", "humor"], style: .poster),
        Zone(title: "Terror", keys: ["terror", "horror", "suspenso", "thriller"], style: .wide),
        Zone(title: "Infantil", keys: ["infantil", "kids", "ninos", "animacion", "animation", "caricatura"], style: .poster),
        Zone(title: "Anime", keys: ["anime", "dorama", "manga"], style: .poster),
        Zone(title: "Drama y romance", keys: ["drama", "romance", "romantica"], style: .wide),
        Zone(title: "Documentales", keys: ["documental", "documentary", "docu", "historia", "natura"], style: .poster),
        Zone(title: "Ciencia ficción y fantasía", keys: ["ciencia ficcion", "sci-fi", "scifi", "fantasia", "fantasy"], style: .wide),
        Zone(title: "Clásicos", keys: ["clasico", "classic", "retro", "80s", "90s"], style: .poster),
        Zone(title: "Música", keys: ["musica", "music", "concierto", "concert"], style: .wide),
        Zone(title: "Noticias", keys: ["noticia", "news", "informativo"], style: .wide)
    ]

    static func build(_ input: Input) -> HomeData {
        var h = HomeData()
        let now = Calendar.current.component(.year, from: Date())
        func adult(_ kind: String, _ cat: String, _ name: String) -> Bool {
            KidsFilter.esAdulto((input.names[kind + ":" + cat] ?? "") + " " + name)
        }
        let movies = input.vods.filter { $0.icon.hasPrefix("http") && !adult("movie", $0.categoryId, $0.name) }
        let shows = input.series.filter { $0.cover.hasPrefix("http") && !adult("series", $0.categoryId, $0.name) }
        let moviesByDate = movies.sorted { $0.added > $1.added }
        let showsByDate = shows.sorted { $0.added > $1.added }

        // Banner: estrenos del año en curso, si no, lo más reciente.
        func isCurrent(_ y: String, _ name: String) -> Bool {
            let yr = Txt.year(y) ?? Txt.year(name) ?? 0
            return yr >= now - 1
        }
        var hero = Array(moviesByDate.prefix(400).filter { isCurrent($0.year, $0.name) }.prefix(6).map { PosterItem($0) })
        hero += Array(showsByDate.prefix(200).filter { isCurrent($0.year, $0.name) }.prefix(3).map { PosterItem($0) })
        if hero.count < 4 {
            hero += moviesByDate.prefix(6).map { PosterItem($0) }
        }
        var seenHero = Set<String>()
        h.hero = Array(hero.filter { seenHero.insert($0.id).inserted }.prefix(8))

        h.newMovies = Array(moviesByDate.prefix(25).map { PosterItem($0) })
        h.newSeries = Array(showsByDate.prefix(25).map { PosterItem($0) })

        // Top 10 de hoy: calificación + novedad + giro del día.
        let cal = Calendar.current
        let seed = "\(cal.component(.year, from: Date()))-\(cal.ordinality(of: .day, in: .year, for: Date()) ?? 0)"
        func score(_ p: PosterItem) -> Double {
            var r = p.rating
            if r > 0 && r <= 5 { r *= 2 }
            r = min(10, max(0, r))
            let y = Txt.year(p.year) ?? 0
            let novelty: Double
            switch now - y {
            case 0: novelty = 2.5
            case 1: novelty = 1.5
            case 2: novelty = 0.6
            default: novelty = 0
            }
            let spin = Double(Txt.stableHash(p.id + seed) % 1000) / 1000 * 1.8
            return r + novelty + spin
        }
        let candidates = Array(moviesByDate.prefix(400).map { PosterItem($0) }) + Array(showsByDate.prefix(200).map { PosterItem($0) })
        var scored: [(PosterItem, Double)] = candidates.map { p in (p, score(p)) }
        scored.sort { a, b in a.1 > b.1 }
        var seenTop = Set<String>()
        var top: [PosterItem] = []
        for (p, _) in scored {
            if seenTop.insert(Txt.norm(TitleClean.clean(p.title))).inserted { top.append(p) }
            if top.count >= 10 { break }
        }
        h.top10 = top

        // Filas por género.
        var rows: [HomeRow] = []
        let all: [PosterItem] = Array(moviesByDate.prefix(3000).map { PosterItem($0) }) + Array(showsByDate.prefix(1500).map { PosterItem($0) })
        let texts: [String] = all.map { Txt.norm($0.genre + " " + (input.names[$0.kind.rawValue + ":" + $0.categoryId] ?? "") + " " + $0.title) }
        for z in zones {
            if input.kids && z.title != "Infantil" && z.title != "Música" { continue }
            var items: [PosterItem] = []
            for (i, p) in all.enumerated() where z.keys.contains(where: { texts[i].contains($0) }) {
                items.append(p)
                if items.count >= 25 { break }
            }
            if items.count >= 5 { rows.append(HomeRow(id: "zona-" + z.title, title: z.title, style: z.style, items: items)) }
        }
        h.genreRows = rows
        h.popular = Array(h.top10.prefix(6))
        return h
    }
}
