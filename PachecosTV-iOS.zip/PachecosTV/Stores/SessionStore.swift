import Foundation
import SwiftUI

struct SavedAccount: Identifiable, Hashable {
    var alias: String
    var usuario: String
    var password: String
    var servidorUrl: String
    var servidorNumero: Int
    var fechaVencimiento: String

    var id: String { usuario.lowercased() }
    var expiry: Int64 { Txt.seconds(fechaVencimiento) }

    /// Verde = vigente, rojo = vencida, gris = sin revisar.
    var statusColor: Color {
        let e = expiry
        if e <= 0 { return Color(red: 84 / 255, green: 89 / 255, blue: 99 / 255) }
        return e > Int64(Date().timeIntervalSince1970)
            ? Color(red: 34 / 255, green: 160 / 255, blue: 72 / 255)
            : Color(red: 215 / 255, green: 48 / 255, blue: 63 / 255)
    }
    var statusText: String {
        let e = expiry
        if e <= 0 { return "Sin revisar" }
        return e > Int64(Date().timeIntervalSince1970) ? "Vence: \(Txt.date(e))" : "Vencida"
    }

    var json: JObj {
        ["alias": alias, "usuario": usuario, "password": password, "servidorUrl": servidorUrl,
         "servidorNumero": servidorNumero, "fechaVencimiento": fechaVencimiento]
    }

    init(alias: String, usuario: String, password: String, servidorUrl: String, servidorNumero: Int, fechaVencimiento: String) {
        self.alias = alias; self.usuario = usuario; self.password = password
        self.servidorUrl = servidorUrl; self.servidorNumero = servidorNumero; self.fechaVencimiento = fechaVencimiento
    }

    init?(_ o: JObj) {
        let u = o.str("usuario")
        guard !u.isEmpty else { return nil }
        self.init(alias: o.str("alias", u), usuario: u, password: o.str("password"), servidorUrl: o.str("servidorUrl"),
                  servidorNumero: o.int("servidorNumero"), fechaVencimiento: o.str("fechaVencimiento"))
    }
}

enum AccessState: Equatable {
    case ok, expired, inactive, removed, sessionExpired, unknown

    var blocks: Bool { [AccessState.expired, .inactive, .removed, .sessionExpired].contains(self) }

    var title: String {
        switch self {
        case .expired: return "Tu cuenta está vencida"
        case .inactive: return "Cuenta desactivada"
        case .removed: return "Servicio no disponible"
        case .sessionExpired: return "Sesión vencida"
        default: return "Sin conexión"
        }
    }

    func message(expiry: Int64) -> String {
        switch self {
        case .expired:
            return (expiry > 0 ? "Venció el \(Txt.date(expiry)). " : "") + "No se puede reproducir nada hasta renovarla.\nComunícate con soporte para renovar."
        case .inactive: return "Tu cuenta fue suspendida o desactivada.\nNo puedes reproducir. Contacta a soporte."
        case .removed: return "Tu servicio no está disponible.\nLa reproducción está desactivada. Contacta a soporte."
        case .sessionExpired: return "Por seguridad, inicia sesión nuevamente.\nTus perfiles e historial permanecen guardados."
        default: return "No se pudo comprobar la cuenta.\nLa reproducción está detenida. Reintenta cuando tengas conexión."
        }
    }
}

@MainActor
final class SessionStore: ObservableObject {
    @Published private(set) var user = ""
    @Published private(set) var password = ""
    @Published private(set) var server = ""
    @Published private(set) var serverNumber = 0
    @Published private(set) var token = ""
    @Published private(set) var accountKey = ""
    @Published private(set) var expiry: Int64 = 0
    @Published private(set) var playbackServers: [String] = []
    @Published private(set) var savedAccounts: [SavedAccount] = []
    @Published var blocked: AccessState? = nil
    @Published var checking = false

    private let prefs = Prefs.named("sesion")
    private var lastCheck = Date.distantPast

    var isLoggedIn: Bool { !user.isEmpty && !password.isEmpty && !server.isEmpty }
    var creds: Creds { Creds(server: server, user: user, pass: password, extraServers: playbackServers) }
    var cloud: CloudCtx { CloudCtx(token: token, accountKey: accountKey, password: password, deviceId: Device.id, user: user) }

    init() { load() }

    func load() {
        user = prefs.str("usuario")
        password = prefs.str("password")
        server = prefs.str("servidor_url")
        serverNumber = prefs.int("servidor_numero")
        token = prefs.str("session_token")
        expiry = Txt.seconds(prefs.str("fecha_vencimiento"))
        playbackServers = prefs.str("servidores_playback").split(separator: ",").map { String($0) }.filter { !$0.isEmpty }
        var key = prefs.str("account_key")
        if key.isEmpty && !user.isEmpty {
            key = Txt.nameUUID("pachecostv|" + user.trimmed.lowercased())
            prefs.set("account_key", key)
        }
        accountKey = key
        savedAccounts = loadSaved()
    }

    // MARK: Inicio de sesión (Pacheco's TV Cloud)

    func login(user rawUser: String, password rawPass: String) async -> String? {
        let u = rawUser.trimmed, p = rawPass.trimmed
        guard !u.isEmpty, !p.isEmpty else { return "Escribe tu usuario y contraseña" }
        let body: JObj = ["username": u, "password": p, "deviceId": Device.id, "deviceName": Device.name, "deviceType": "mobile"]
        let response: (Any?, Int)
        do {
            response = try await Http.post(Endpoints.login, json: body, headers: ["User-Agent": "PachecosTV/2.0"], timeout: 30)
        } catch {
            return "Sin servicio por ahora. Intenta más tarde."
        }
        guard let json = response.0 as? JObj else { return "Sin servicio por ahora. Intenta más tarde." }
        guard json.bool("success") else { return json.str("message", "Usuario o contraseña incorrectos").nilIfEmpty ?? "Usuario o contraseña incorrectos" }
        guard let data = json.obj("data"), let info = data.obj("user_info") else { return "No se pudo iniciar sesión. Intenta de nuevo." }
        let auth = info.int("auth") == 1 || info.str("auth").lowercased() == "true"
        let status = info.str("status").lowercased()
        guard auth, !["disabled", "banned", "expired"].contains(status) else { return "Cuenta rechazada o credenciales incorrectas" }
        guard let si = data.obj("server_info") else { return "No se pudo iniciar sesión. Intenta de nuevo." }
        let url = Self.serverURL(si)
        guard !url.isEmpty else { return "No se pudo iniciar sesión. Intenta de nuevo." }
        let servers = Self.playbackServers(json, data, url)
        var key = json.obj("account")?.str("accountKey") ?? ""
        if key.isEmpty { key = Txt.nameUUID("pachecostv|" + u.lowercased()) }
        let exp = info.str("exp_date")
        prefs.edit { d in
            d["usuario"] = u
            d["password"] = p
            d["servidor_url"] = url
            d["servidor_numero"] = json.int("serverNumber")
            d["account_key"] = key
            d["session_token"] = json.str("sessionToken")
            d["sesion_iniciada"] = true
            d["fecha_vencimiento"] = exp
            d["servidores_playback"] = servers.joined(separator: ",")
        }
        saveAccount(SavedAccount(alias: u, usuario: u, password: p, servidorUrl: url, servidorNumero: json.int("serverNumber"), fechaVencimiento: exp))
        load()
        blocked = nil
        lastCheck = Date()
        return nil
    }

    static func serverURL(_ si: JObj) -> String {
        var proto = si.str("server_protocol", "http")
        if proto.isEmpty { proto = "http" }
        proto = proto.replacingOccurrences(of: "://", with: "")
        let host = si.str("url").replacingOccurrences(of: "http://", with: "").replacingOccurrences(of: "https://", with: "")
            .trimmingCharacters(in: CharacterSet(charactersIn: "/"))
        guard !host.isEmpty else { return "" }
        let port = si.str(proto.lowercased() == "https" ? "https_port" : "port", si.str("port")).trimmed
        let isDefault = (proto.lowercased() == "http" && (port.isEmpty || port == "80")) || (proto.lowercased() == "https" && (port.isEmpty || port == "443"))
        return isDefault ? "\(proto)://\(host)" : "\(proto)://\(host):\(port)"
    }

    static func playbackServers(_ root: JObj, _ data: JObj, _ main: String) -> [String] {
        var out: [String] = []
        func add(_ s: String) {
            let c = s.trimmed.trimmingCharacters(in: CharacterSet(charactersIn: "/"))
            if (c.hasPrefix("http://") || c.hasPrefix("https://")) && !out.contains(c) { out.append(c) }
        }
        add(main)
        for key in ["servers", "server_list", "playback_servers", "stream_servers"] {
            for source in [root.arr(key), data.arr(key)] {
                for item in source {
                    if let s = item as? String { add(s) }
                    else if let o = item as? JObj {
                        for f in ["url", "server_url", "base_url", "playback_url", "host"] { add(o.str(f)) }
                    }
                }
            }
        }
        return Array(out.prefix(5))
    }

    func logout() {
        let t = token
        if !t.isEmpty {
            Task.detached {
                _ = try? await Http.post(Endpoints.logout, json: ["sessionToken": t], headers: ["Authorization": "Bearer \(t)"], timeout: 5)
            }
        }
        prefs.remove("usuario", "password", "account_key", "sesion_iniciada", "perfil_activo_id", "perfil_activo_nombre", "session_token")
        blocked = nil
        load()
    }

    // MARK: Control de acceso (mismas razones que AccesoServicio)

    func checkAccess(force: Bool = false) async {
        guard isLoggedIn else { return }
        if !force && Date().timeIntervalSince(lastCheck) < 170 { return }
        lastCheck = Date()
        guard !token.isEmpty else { blocked = .sessionExpired; return }
        checking = true
        defer { checking = false }
        let result: (Any?, Int)
        do {
            result = try await Http.post(Endpoints.sessionStatus, json: ["password": password],
                                         headers: ["Authorization": "Bearer \(token)"], timeout: 14)
        } catch {
            return
        }
        guard let data = result.0 as? JObj else { return }
        let code = result.1
        let exp = Txt.seconds(data.str("expiresAt"))
        if (200..<300).contains(code) && data.bool("success") && data.bool("active") {
            if exp > 0 { expiry = exp; prefs.set("fecha_vencimiento", "\(exp)") }
            blocked = nil
            return
        }
        if !(200..<300).contains(code) && ![400, 401, 403, 404, 410].contains(code) { return }
        switch data.str("reason").trimmed.lowercased() {
        case "server_removed": blocked = .removed
        case "account_expired":
            if exp > 0 { expiry = exp }
            blocked = .expired
        case "account_inactive", "invalid_credentials": blocked = .inactive
        case "session_expired", "session_required", "session_revoked": blocked = .sessionExpired
        default: break
        }
    }

    // MARK: Cuentas guardadas

    private func loadSaved() -> [SavedAccount] {
        guard let arr = JSON.parse(Prefs.named("cuentas_guardadas").str("lista", "[]")) as? [Any] else { return [] }
        return arr.compactMap { $0 as? JObj }.compactMap { SavedAccount($0) }
    }

    private func storeSaved(_ list: [SavedAccount]) {
        Prefs.named("cuentas_guardadas").set("lista", JSON.string(list.map { $0.json }))
        savedAccounts = list
    }

    func saveAccount(_ a: SavedAccount) {
        var list = loadSaved().filter { $0.id != a.id }
        list.insert(a, at: 0)
        storeSaved(Array(list.prefix(8)))
    }

    func deleteAccount(_ a: SavedAccount) {
        storeSaved(loadSaved().filter { $0.id != a.id })
    }
}
