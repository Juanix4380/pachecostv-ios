import Foundation
import SwiftUI

struct Profile: Identifiable, Hashable {
    let index: Int
    var name: String
    var avatar: Int
    var kids: Bool
    var hasPin: Bool
    var id: Int { index }
}

enum Avatars {
    static let count = 13
    static func image(_ i: Int) -> String { "Avatar\(min(12, max(0, i)))" }
    static func color(_ i: Int) -> Color {
        switch i {
        case 1: return Color(red: 0xE2 / 255, green: 0xA9 / 255, blue: 0x13 / 255)
        case 2: return Color(red: 0x15 / 255, green: 0x95 / 255, blue: 0xC9 / 255)
        case 3: return Color(red: 0x7B / 255, green: 0x2F / 255, blue: 0xCF / 255)
        case 4: return Color(red: 0xC8 / 255, green: 0x16 / 255, blue: 0x2E / 255)
        case 5, 11: return Color(red: 0x1E / 255, green: 0x9B / 255, blue: 0x3C / 255)
        case 6, 10: return Color(red: 0xEF / 255, green: 0x7B / 255, blue: 0x10 / 255)
        case 7: return Color(red: 0x0E / 255, green: 0x8F / 255, blue: 0x86 / 255)
        case 8: return Color(red: 0xD4 / 255, green: 0x56 / 255, blue: 0x7E / 255)
        case 9: return Color(red: 0x6E / 255, green: 0xA9 / 255, blue: 0x1D / 255)
        default: return Color(red: 0x23 / 255, green: 0x50 / 255, blue: 0xD8 / 255)
        }
    }
}

// MARK: - Perfiles de la cuenta

@MainActor
final class ProfileManager: ObservableObject {
    @Published private(set) var profiles: [Profile] = []
    @Published private(set) var activeIndex: Int? = nil
    @Published private(set) var syncing = false

    private(set) var ctx = CloudCtx(token: "", accountKey: "", password: "", deviceId: "", user: "")

    var active: Profile? { profiles.first { $0.index == activeIndex } }
    private var prefs: Prefs { CloudSync.profilesPrefs(ctx) }

    func bind(_ c: CloudCtx) {
        let changed = c.accountKey != ctx.accountKey
        ctx = c
        if changed { activeIndex = nil }
        reload()
    }

    func reload() {
        guard !ctx.accountKey.isEmpty else { profiles = []; return }
        let p = prefs
        profiles = (0..<CloudSync.maxProfiles).compactMap { (i: Int) -> Profile? in
            let name = p.str("perfil_\(i)_nombre")
            guard !name.isEmpty else { return nil }
            return Profile(index: i, name: name, avatar: min(12, max(0, p.int("perfil_\(i)_avatar", min(9, i)))),
                           kids: p.bool("perfil_\(i)_ninos"), hasPin: !p.str("perfil_\(i)_pin").isEmpty)
        }
    }

    /// La nube es la autoridad sobre los perfiles de la cuenta.
    func refreshFromCloud() async {
        guard !ctx.accountKey.isEmpty else { return }
        syncing = true
        let c = ctx
        let ok = await CloudSync.downloadProfiles(c)
        reload()
        if ok {
            for p in profiles { _ = await CloudSync.refreshPin(c, index: p.index) }
            reload()
        }
        if profiles.isEmpty {
            _ = await create(name: "Principal", avatar: 0, kids: false)
        }
        syncing = false
    }

    func create(name: String, avatar: Int, kids: Bool) async -> Int? {
        let used = Set(profiles.map { $0.index })
        guard let slot = (0..<CloudSync.maxProfiles).first(where: { !used.contains($0) }) else { return nil }
        // Una ranura nueva nunca hereda datos de un perfil borrado.
        prefs.remove("perfil_\(slot)_uuid", "perfil_\(slot)_pin")
        CloudSync.dataPrefs(ctx, slot).clear()
        write(slot, name: name, avatar: avatar, kids: kids)
        let c = ctx
        _ = await CloudSync.saveProfile(c, index: slot, name: name, avatar: avatar, kids: kids)
        reload()
        return slot
    }

    func update(_ index: Int, name: String, avatar: Int, kids: Bool) async {
        write(index, name: name, avatar: avatar, kids: kids)
        reload()
        let c = ctx
        _ = await CloudSync.saveProfile(c, index: index, name: name, avatar: avatar, kids: kids)
    }

    private func write(_ index: Int, name: String, avatar: Int, kids: Bool) {
        prefs.edit { d in
            d["perfil_\(index)_nombre"] = name
            d["perfil_\(index)_avatar"] = avatar
            d["perfil_\(index)_ninos"] = kids
        }
        _ = CloudSync.profileUuid(ctx, index)
    }

    func delete(_ index: Int) async -> Bool {
        let c = ctx
        let ok = await CloudSync.deleteProfile(c, index: index)
        guard ok else { return false }
        prefs.remove("perfil_\(index)_nombre", "perfil_\(index)_avatar", "perfil_\(index)_ninos", "perfil_\(index)_pin", "perfil_\(index)_uuid")
        CloudSync.dataPrefs(c, index).clear()
        if activeIndex == index { activeIndex = nil }
        reload()
        return true
    }

    func setPin(_ index: Int, _ pin: String?) {
        Pin.save(ctx, index, pin: pin)
        reload()
    }

    func verifyPin(_ index: Int, _ pin: String) -> Bool { Pin.verify(ctx, index, pin) }

    func refreshPin(_ index: Int) async {
        let c = ctx
        _ = await CloudSync.refreshPin(c, index: index)
        reload()
    }

    func enter(_ index: Int) {
        guard let p = profiles.first(where: { $0.index == index }) else { return }
        prefs.set("perfil_activo", index)
        Prefs.named("perfil_activo_\(ctx.accountKey)").edit { d in
            d["id"] = index
            d["nombre"] = p.name
            d["es_ninos"] = p.kids
        }
        Prefs.named("sesion").edit { d in
            d["perfil_activo_id"] = index
            d["perfil_activo_nombre"] = p.name
            d["perfil_activo_ninos"] = p.kids
        }
        activeIndex = index
    }

    func leave() { activeIndex = nil }

    var lastUsed: Int? {
        let id = Prefs.named("perfil_activo_\(ctx.accountKey)").int("id", -1)
        return profiles.contains { $0.index == id } ? id : nil
    }
}

// MARK: - Mi lista, historial y TV del perfil activo (mismas claves que Android)

struct WatchItem: Identifiable, Hashable {
    let type: String
    let key: String
    let title: String
    let url: String
    let position: Int64
    let duration: Int64
    let date: Int64
    let episodeId: String
    let season: Int
    let episode: Int

    var id: String { type + ":" + key }
    var canResume: Bool { position > 0 && (duration <= 0 || position < duration - 30_000) }
    var progress: Double { duration > 0 ? min(1, max(0, Double(position) / Double(duration))) : 0 }
    var remainingText: String {
        guard duration > 0 else { return "" }
        let mins = max(1, Int((duration - position) / 60_000))
        return mins >= 60 ? "Quedan \(mins / 60) h \(mins % 60) min" : "Quedan \(mins) min"
    }
}

@MainActor
final class LibraryStore: ObservableObject {
    @Published private(set) var version = 0

    private var ctx: CloudCtx?
    private(set) var index = 0
    private var uploadTask: Task<Void, Never>?
    private var uploading = false
    private var again = false

    private var prefs: Prefs? { ctx.map { CloudSync.dataPrefs($0, index) } }

    func bind(_ c: CloudCtx, _ i: Int) {
        ctx = c
        index = i
        version += 1
    }

    func unbind() { ctx = nil; version += 1 }

    func syncOnEntry() async {
        guard let c = ctx else { return }
        let i = index
        _ = await CloudSync.syncOnEntry(c, i)
        if ctx?.accountKey == c.accountKey && index == i { version += 1 }
    }

    func pull() async {
        guard let c = ctx, let p = prefs, !p.bool("cloud_dirty") else { return }
        let i = index
        if await CloudSync.download(c, i), ctx?.accountKey == c.accountKey, index == i { version += 1 }
    }

    private func dirty() {
        guard let p = prefs else { return }
        p.edit { d in
            d["cloud_dirty"] = true
            d["cloud_change_id"] = Int64(Date().timeIntervalSince1970 * 1_000_000)
        }
        version += 1
        scheduleUpload()
    }

    private func scheduleUpload() {
        uploadTask?.cancel()
        uploadTask = Task { [weak self] in
            try? await Task.sleep(nanoseconds: 1_200_000_000)
            if Task.isCancelled { return }
            await self?.runUpload()
        }
    }

    private func runUpload() async {
        guard let c = ctx else { return }
        if uploading { again = true; return }
        uploading = true
        let i = index
        var attempts = 0
        repeat {
            again = false
            _ = await CloudSync.upload(c, i)
            attempts += 1
        } while again && attempts < 4
        uploading = false
    }

    // MARK: Mi lista

    func isFavorite(_ type: Kind, _ id: String) -> Bool { prefs?.stringSet("favoritos_\(type.rawValue)").contains(id) ?? false }

    @discardableResult
    func toggleFavorite(_ type: Kind, _ id: String) -> Bool {
        guard let p = prefs else { return false }
        var set = p.stringSet("favoritos_\(type.rawValue)")
        var order = p.str("orden_favoritos_\(type.rawValue)").split(separator: ",").map { String($0) }.filter { !$0.isEmpty }
        let added: Bool
        if set.contains(id) {
            set.remove(id); order.removeAll { $0 == id }; added = false
        } else {
            set.insert(id); order.removeAll { $0 == id }; order.insert(id, at: 0); added = true
        }
        p.edit { d in
            d["favoritos_\(type.rawValue)"] = Array(set)
            d["orden_favoritos_\(type.rawValue)"] = order.prefix(200).joined(separator: ",")
        }
        dirty()
        return added
    }

    /// Lo recién agregado primero.
    func favorites(_ type: Kind) -> [String] {
        guard let p = prefs else { return [] }
        let set = p.stringSet("favoritos_\(type.rawValue)")
        let order = p.str("orden_favoritos_\(type.rawValue)").split(separator: ",").map { String($0) }.filter { set.contains($0) }
        return order + set.subtracting(order).sorted()
    }

    // MARK: TV en vivo

    func favoriteChannels() -> Set<String> { prefs?.stringSet("favoritos_tv") ?? [] }

    func toggleFavoriteChannel(_ id: String) {
        guard let p = prefs else { return }
        var s = p.stringSet("favoritos_tv")
        if s.contains(id) { s.remove(id) } else { s.insert(id) }
        p.set("favoritos_tv", Array(s))
        dirty()
    }

    func recentChannels() -> [String] {
        (prefs?.str("recientes_tv") ?? "").split(separator: ",").map { String($0) }.filter { !$0.isEmpty }
    }

    func addRecentChannel(_ id: String, title: String, url: String) {
        guard let p = prefs else { return }
        var list = recentChannels()
        list.removeAll { $0 == id }
        list.insert(id, at: 0)
        p.edit { d in
            d["recientes_tv"] = list.prefix(30).joined(separator: ",")
            d["ultimo_tv_id"] = id
            d["ultimo_tv_titulo"] = title
            d["ultimo_tv_url"] = url
            d["ultimo_tv_fecha"] = Int64(Date().timeIntervalSince1970 * 1000)
        }
        dirty()
    }

    var lastChannel: String { prefs?.str("ultimo_tv_id") ?? "" }

    // MARK: Historial

    func history(_ type: Kind) -> [WatchItem] {
        guard let p = prefs else { return [] }
        let t = type.rawValue
        let ids = p.str("historial_\(t)").split(separator: ",").map { String($0) }.filter { !$0.isEmpty }
        return ids.compactMap { (id: String) -> WatchItem? in
            guard let raw = p.get("item_\(t)_\(id)") else { return nil }
            let o: JObj? = (raw as? JObj) ?? ((raw as? String).flatMap { JSON.parse($0) as? JObj })
            guard let obj = o else { return nil }
            let deleted = p.int64("__watch_deleted_\(t)_\(id)")
            if deleted > 0 && deleted >= obj.int64("fecha") { return nil }
            return WatchItem(type: t, key: obj.str("id", id), title: obj.str("titulo", "Contenido"), url: obj.str("url"),
                             position: obj.int64("posicion"), duration: obj.int64("duracion"), date: obj.int64("fecha"),
                             episodeId: obj.str("episodio_id"), season: obj.int("temporada"), episode: obj.int("numero_episodio"))
        }
    }

    func find(_ type: Kind, _ id: String) -> WatchItem? { history(type).first { $0.key == id } }

    func record(_ type: Kind, id: String, title: String, url: String, position: Int64, duration: Int64,
                episodeId: String = "", season: Int = 0, episode: Int = 0) {
        guard let p = prefs, !(id.isEmpty && url.isEmpty) else { return }
        let t = type.rawValue
        let key = id.isEmpty ? "\(Txt.stableHash(url))" : id
        var ids = p.str("historial_\(t)").split(separator: ",").map { String($0) }.filter { !$0.isEmpty }
        ids.removeAll { $0 == key }
        ids.insert(key, at: 0)
        var removed: [String] = []
        while ids.count > 50 { removed.append(ids.removeLast()) }
        let now = Int64(Date().timeIntervalSince1970 * 1000)
        var item: JObj = ["id": key, "titulo": title, "url": url, "posicion": position, "duracion": duration,
                          "episodio_id": episodeId, "fecha": now]
        if season > 0 { item["temporada"] = season; item["numero_episodio"] = episode }
        p.edit { d in
            for r in removed { d.removeValue(forKey: "item_\(t)_\(r)") }
            d["historial_\(t)"] = ids.joined(separator: ",")
            d["item_\(t)_\(key)"] = JSON.string(item)
            d.removeValue(forKey: "__watch_deleted_\(t)_\(key)")
            d["__watch_pending_\(t)_\(key)"] = now
            d["ultimo_tipo"] = t
            d["ultimo_id"] = key
            d["ultimo_titulo"] = title
            d["ultimo_url"] = url
            d["ultimo_posicion"] = position
            d["ultimo_duracion"] = duration
        }
        dirty()
    }

    func remove(_ type: Kind, _ id: String) {
        guard let p = prefs else { return }
        let t = type.rawValue
        let ids = p.str("historial_\(t)").split(separator: ",").map { String($0) }.filter { !$0.isEmpty && $0 != id }
        let now = Int64(Date().timeIntervalSince1970 * 1000)
        p.edit { d in
            d["historial_\(t)"] = ids.joined(separator: ",")
            d.removeValue(forKey: "item_\(t)_\(id)")
            d["__watch_deleted_\(t)_\(id)"] = now
            d.removeValue(forKey: "__watch_pending_\(t)_\(id)")
            if (d["ultimo_tipo"] as? String) == t && (d["ultimo_id"] as? String) == id {
                for k in ["ultimo_tipo", "ultimo_id", "ultimo_titulo", "ultimo_url", "ultimo_posicion", "ultimo_duracion"] { d.removeValue(forKey: k) }
            }
        }
        dirty()
    }

    /// Veces vistas por título en todos los perfiles de la cuenta (para el Top 10).
    func viewsAllProfiles() -> [String: Int] {
        guard let c = ctx else { return [:] }
        var out: [String: Int] = [:]
        for i in 0..<CloudSync.maxProfiles {
            let p = CloudSync.dataPrefs(c, i)
            for t in ["movie", "series"] {
                for id in p.str("historial_\(t)").split(separator: ",") { out["\(t):\(id)", default: 0] += 1 }
            }
        }
        return out
    }
}
