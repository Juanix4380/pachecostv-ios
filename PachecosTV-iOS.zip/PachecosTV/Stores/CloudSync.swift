import Foundation

struct CloudCtx {
    let token: String
    let accountKey: String
    let password: String
    let deviceId: String
    let user: String
    var enabled: Bool { !token.isEmpty && !accountKey.isEmpty }
}

/// Puerto de CloudSyncManager (Android): perfiles, PIN e historial en Pacheco's TV Cloud.
enum CloudSync {
    static let maxProfiles = 10
    static let maxAvatars = 13

    static func profilesPrefs(_ c: CloudCtx) -> Prefs { Prefs.named("perfiles_\(c.accountKey)") }
    static func dataPrefs(_ c: CloudCtx, _ index: Int) -> Prefs { Prefs.named("datos_perfil_\(c.accountKey)_\(index)") }

    static func post(_ c: CloudCtx, _ route: String, _ body: JObj) async -> JObj? {
        guard !c.token.isEmpty else { return nil }
        var b = body
        b["sessionToken"] = c.token
        do {
            let (obj, code) = try await Http.post("\(Endpoints.cloud)/\(route)", json: b,
                                                  headers: ["Authorization": "Bearer \(c.token)"], timeout: 15)
            if let o = obj as? JObj { return o }
            return ["success": false, "httpCode": code]
        } catch {
            return nil
        }
    }

    static func profileUuid(_ c: CloudCtx, _ index: Int) -> String {
        let p = profilesPrefs(c)
        let key = "perfil_\(index)_uuid"
        let prev = p.str(key)
        if !prev.isEmpty { return prev }
        let fresh = UUID().uuidString.lowercased()
        p.set(key, fresh)
        return fresh
    }

    // MARK: Perfiles

    static func downloadProfiles(_ c: CloudCtx) async -> Bool {
        guard c.enabled, let r = await post(c, "profiles/list", [:]), r.bool("success") else { return false }
        let profiles = r.objs("profiles")
        let prefs = profilesPrefs(c)
        var incoming: [Int: String] = [:]
        for (i, p) in profiles.enumerated() {
            let slot = p.int("positionOrder", i)
            if (0..<maxProfiles).contains(slot) { incoming[slot] = p.str("profileUuid") }
        }
        for slot in 0..<maxProfiles {
            let savedUuid = prefs.str("perfil_\(slot)_uuid")
            let savedName = prefs.str("perfil_\(slot)_nombre")
            let remote = incoming[slot] ?? ""
            if (!savedUuid.isEmpty && savedUuid != remote) || (!savedName.isEmpty && incoming[slot] == nil) {
                dataPrefs(c, slot).clear()
                prefs.remove("perfil_\(slot)_pin", "perfil_\(slot)_visual_pendiente", "perfil_\(slot)_uuid",
                             "perfil_\(slot)_nombre", "perfil_\(slot)_avatar", "perfil_\(slot)_ninos")
                let active = Prefs.named("perfil_activo_\(c.accountKey)")
                if active.int("id", -1) == slot { active.clear() }
            }
        }
        prefs.edit { d in
            d["profiles_cloud_dirty"] = false
            for i in 0..<maxProfiles {
                for k in ["nombre", "avatar", "ninos", "uuid"] { d.removeValue(forKey: "perfil_\(i)_\(k)") }
            }
            for (i, p) in profiles.enumerated() {
                let index = min(maxProfiles - 1, max(0, p.int("positionOrder", i)))
                d["perfil_\(index)_nombre"] = p.str("profileName", "Principal")
                d["perfil_\(index)_avatar"] = min(maxAvatars - 1, max(0, Int(p.str("avatar", "0")) ?? 0))
                d["perfil_\(index)_ninos"] = p.bool("isKids")
                let uuid = p.str("profileUuid")
                if !uuid.isEmpty { d["perfil_\(index)_uuid"] = uuid }
            }
        }
        return true
    }

    static func saveProfile(_ c: CloudCtx, index: Int, name: String, avatar: Int, kids: Bool) async -> Bool {
        guard c.enabled else { return false }
        let body: JObj = ["profileUuid": profileUuid(c, index), "profileName": name, "avatar": "\(avatar)",
                          "positionOrder": index, "isKids": kids]
        let saved = await post(c, "profiles/save", body)?.bool("success") ?? false
        let data = dataPrefs(c, index)
        data.edit { d in
            d["__cloud_profile_name"] = name
            d["__cloud_profile_avatar"] = min(maxAvatars - 1, max(0, avatar))
            d["__cloud_profile_position"] = index
            d["__cloud_profile_is_kids"] = kids
            d["cloud_dirty"] = true
        }
        let synced = await upload(c, index)
        return saved || synced
    }

    static func deleteProfile(_ c: CloudCtx, index: Int) async -> Bool {
        guard c.enabled else { return false }
        let uuid = profileUuid(c, index)
        let ok = await post(c, "profiles/delete", ["profileUuid": uuid, "accountPassword": c.password])?.bool("success") ?? false
        if ok && profilesPrefs(c).str("perfil_\(index)_uuid") == uuid { profilesPrefs(c).remove("perfil_\(index)_uuid") }
        return ok
    }

    /// Lee solo la protección del perfil antes de abrirlo.
    static func refreshPin(_ c: CloudCtx, index: Int) async -> Bool {
        guard c.enabled else { return true }
        guard let r = await post(c, "sync/download", ["profileUuid": profileUuid(c, index)]) else { return false }
        if !r.bool("success") {
            if r.obj("syncData") == nil { Pin.markChecked(c, index); return true }
            return false
        }
        let remote = r.obj("syncData")
        let date = remote?.int64("__profile_pin_changed_at") ?? 0
        if date > 0 {
            guard remote?["__profile_pin_hash"] != nil else { return false }
            let hash = remote?.str("__profile_pin_hash") ?? ""
            if !hash.isEmpty && !Pin.isHash(hash) { return false }
            Pin.applyFromCloud(c, index, hash, date)
        } else if !(remote?.str("__profile_pin_hash") ?? "").isEmpty {
            return false
        }
        Pin.markChecked(c, index)
        return true
    }

    // MARK: Historial, favoritos y PIN

    static func toJSON(_ p: Prefs) -> JObj {
        var out: JObj = [:]
        for (k, v) in p.all {
            if ["cloud_revision", "cloud_dirty", "cloud_change_id", "pin_requires_auth"].contains(k) || k.hasPrefix("__watch_pending_") { continue }
            out[k] = v
        }
        return out
    }

    static func restore(_ p: Prefs, _ json: JObj) {
        let oldRev = p.int64("cloud_revision")
        let oldChange = p.int64("cloud_change_id")
        var fresh: JObj = [:]
        for (k, v) in json {
            if v is NSNull { continue }
            if let o = v as? JObj { fresh[k] = JSON.string(o); continue }
            if let a = v as? [Any] { fresh[k] = a.map { ($0 as? String) ?? "\($0)" }; continue }
            fresh[k] = v
        }
        fresh["cloud_revision"] = oldRev
        fresh["cloud_change_id"] = oldChange
        fresh["cloud_dirty"] = false
        p.replaceAll(fresh)
    }

    static func upload(_ c: CloudCtx, _ index: Int, retryConflict: Bool = true) async -> Bool {
        guard c.enabled, !profilesPrefs(c).str("perfil_\(index)_uuid").isEmpty else { return false }
        let p = dataPrefs(c, index)
        let changeId = p.int64("cloud_change_id")
        var body: JObj = ["profileUuid": profileUuid(c, index), "deviceId": c.deviceId,
                          "revision": p.int64("cloud_revision"), "syncData": toJSON(p)]
        if p.bool("pin_requires_auth") { body["accountPassword"] = c.password }
        guard let r = await post(c, "sync/upload", body) else { return false }
        if r.bool("conflict") && retryConflict {
            guard let remote = await post(c, "sync/download", ["profileUuid": profileUuid(c, index)]),
                  remote.bool("success"), let remoteData = remote.obj("syncData") else { return false }
            let pendingTimestamps = p.all.filter { $0.key.hasPrefix("__watch_pending_") }
            let pendingKeys = Set(pendingTimestamps.keys.map { "item_" + $0.dropFirst("__watch_pending_".count) })
            let merged = SyncMerge.merge(remote: remoteData, local: toJSON(p), pending: pendingKeys)
            let pinAuth = p.bool("pin_requires_auth")
            restore(p, merged)
            p.edit { d in
                for (k, v) in pendingTimestamps { d[k] = v }
                if pinAuth { d["pin_requires_auth"] = true }
                d["cloud_revision"] = remote.int64("revision")
                d["cloud_dirty"] = true
            }
            return await upload(c, index, retryConflict: false)
        }
        if r.bool("success") {
            p.edit { d in
                d["cloud_revision"] = r.int64("revision")
                let current = (d["cloud_change_id"] as? NSNumber)?.int64Value ?? 0
                if current == changeId {
                    d["cloud_dirty"] = false
                    d.removeValue(forKey: "pin_requires_auth")
                    for k in d.keys where k.hasPrefix("__watch_pending_") { d.removeValue(forKey: k) }
                }
            }
            return true
        }
        return false
    }

    static func download(_ c: CloudCtx, _ index: Int) async -> Bool {
        guard c.enabled, !profilesPrefs(c).str("perfil_\(index)_uuid").isEmpty else { return false }
        let p = dataPrefs(c, index)
        if p.bool("cloud_dirty") { return false }
        let changeId = p.int64("cloud_change_id")
        guard let r = await post(c, "sync/download", ["profileUuid": profileUuid(c, index)]), r.bool("success") else { return false }
        let hasData = r["hasData"] != nil ? r.bool("hasData") : r.int64("revision") > 0
        guard hasData else { return false }
        let sync = r.obj("syncData") ?? [:]
        if p.bool("cloud_dirty") || p.int64("cloud_change_id") != changeId { return false }
        restore(p, sync)
        p.set("cloud_revision", r.int64("revision"))
        if sync["__profile_pin_changed_at"] != nil && sync["__profile_pin_hash"] != nil {
            Pin.applyFromCloud(c, index, sync.str("__profile_pin_hash"), sync.int64("__profile_pin_changed_at"))
        }
        let name = sync.str("__cloud_profile_name").trimmed
        if !name.isEmpty {
            let pos = min(maxProfiles - 1, max(0, sync.int("__cloud_profile_position", index)))
            profilesPrefs(c).edit { d in
                d["perfil_\(pos)_nombre"] = name
                d["perfil_\(pos)_avatar"] = min(maxAvatars - 1, max(0, sync.int("__cloud_profile_avatar")))
            }
        }
        return true
    }

    static func syncOnEntry(_ c: CloudCtx, _ index: Int) async -> Bool {
        guard c.enabled else { return false }
        if dataPrefs(c, index).bool("cloud_dirty") {
            if !(await upload(c, index)) { return false }
        }
        return await download(c, index)
    }
}

// MARK: - Mezcla de historial (puerto de PlaybackSyncMerge)

enum SyncMerge {
    private static func item(_ any: Any?) -> JObj? {
        if let o = any as? JObj { return o }
        if let s = any as? String { return JSON.parse(s) as? JObj }
        return nil
    }

    private static func ids(_ o: JObj, _ type: String) -> [String] {
        o.str("historial_\(type)").split(separator: ",").map { String($0) }.filter { !$0.isEmpty }
    }

    static func merge(remote: JObj, local: JObj, pending: Set<String>) -> JObj {
        var merged = remote
        for (k, v) in local where !(k.hasPrefix("item_movie_") || k.hasPrefix("item_series_") ||
                                     k == "historial_movie" || k == "historial_series" || k.hasPrefix("__watch_deleted_")) {
            merged[k] = v
        }
        let rPin = remote.int64("__profile_pin_changed_at"), lPin = local.int64("__profile_pin_changed_at")
        if rPin >= lPin && rPin > 0 && remote["__profile_pin_hash"] != nil {
            merged["__profile_pin_hash"] = remote.str("__profile_pin_hash")
            merged["__profile_pin_changed_at"] = rPin
        }
        for type in ["movie", "series"] {
            let prefix = "item_\(type)_", delPrefix = "__watch_deleted_\(type)_"
            let remoteIds = Set(ids(remote, type)), localIds = Set(ids(local, type))
            var deletion = Set<String>()
            for src in [remote, local] { for k in src.keys where k.hasPrefix(delPrefix) { deletion.insert(String(k.dropFirst(delPrefix.count))) } }
            var candidates = remoteIds
            for id in localIds where remote["historial_\(type)"] == nil || pending.contains(prefix + id) { candidates.insert(id) }
            var items: [String: JObj] = [:]
            for id in candidates {
                var options: [JObj] = []
                for src in [remote, local] where ids(src, type).contains(id) {
                    if let o = item(src[prefix + id]) { options.append(o) }
                }
                guard let newest = options.max(by: { $0.int64("fecha") < $1.int64("fecha") }) else { continue }
                let deletedAt = max(remote.int64(delPrefix + id), local.int64(delPrefix + id))
                if deletedAt == 0 || newest.int64("fecha") > deletedAt { items[id] = newest }
            }
            for k in merged.keys where k.hasPrefix(prefix) || k.hasPrefix(delPrefix) { merged.removeValue(forKey: k) }
            for id in deletion.union(candidates) {
                let deletedAt = max(remote.int64(delPrefix + id), local.int64(delPrefix + id))
                if deletedAt > 0 && (items[id]?.int64("fecha") ?? 0) <= deletedAt { merged[delPrefix + id] = deletedAt }
            }
            let selected = items.sorted { $0.value.int64("fecha") > $1.value.int64("fecha") }.prefix(50)
            merged["historial_\(type)"] = selected.map { $0.key }.joined(separator: ",")
            for (k, v) in selected { merged[prefix + k] = JSON.string(v) }
        }
        var latest: (String, JObj)?
        for type in ["movie", "series"] {
            if let id = ids(merged, type).first, let o = item(merged["item_\(type)_\(id)"]) {
                if latest == nil || o.int64("fecha") > latest!.1.int64("fecha") { latest = (type, o) }
            }
        }
        if merged.str("ultimo_tipo") != "tv" {
            if let l = latest {
                let type = l.0, o = l.1
                merged["ultimo_tipo"] = type
                merged["ultimo_id"] = o.str("id")
                merged["ultimo_titulo"] = o.str("titulo")
                merged["ultimo_url"] = o.str("url")
                merged["ultimo_posicion"] = o.int64("posicion")
                merged["ultimo_duracion"] = o.int64("duracion")
            } else {
                for k in ["ultimo_tipo", "ultimo_id", "ultimo_titulo", "ultimo_url", "ultimo_posicion", "ultimo_duracion"] { merged.removeValue(forKey: k) }
            }
        }
        return merged
    }
}

// MARK: - PIN (huella SHA-256 "ptv|indice|pin", nunca el PIN en claro)

enum Pin {
    static func hash(_ pin: String, _ index: Int) -> String { Txt.sha256("ptv|\(index)|\(pin)") }
    static func isHash(_ s: String) -> Bool { s.count == 64 && s.allSatisfy { $0.isHexDigit } }

    static func has(_ c: CloudCtx, _ index: Int) -> Bool { !CloudSync.profilesPrefs(c).str("perfil_\(index)_pin").isEmpty }

    static func verify(_ c: CloudCtx, _ index: Int, _ pin: String) -> Bool {
        CloudSync.profilesPrefs(c).str("perfil_\(index)_pin").lowercased() == hash(pin, index)
    }

    /// Guarda (o quita con "") el PIN y lo deja pendiente de subir.
    static func save(_ c: CloudCtx, _ index: Int, pin: String?) {
        let fingerprint = (pin ?? "").isEmpty ? "" : hash(pin ?? "", index)
        CloudSync.profilesPrefs(c).set("perfil_\(index)_pin", fingerprint.isEmpty ? nil : fingerprint)
        let data = CloudSync.dataPrefs(c, index)
        let now = Int64(Date().timeIntervalSince1970 * 1000)
        let date = max(now, data.int64("__profile_pin_changed_at") + 1)
        data.edit { d in
            d["__profile_pin_hash"] = fingerprint
            d["__profile_pin_changed_at"] = date
            d["__profile_pin_checked"] = true
            d["cloud_dirty"] = true
            d["pin_requires_auth"] = true
            d["cloud_change_id"] = Int64(Date().timeIntervalSince1970 * 1_000_000)
        }
        Task.detached { _ = await CloudSync.upload(c, index) }
    }

    static func applyFromCloud(_ c: CloudCtx, _ index: Int, _ hash: String, _ date: Int64) {
        guard date > 0, hash.isEmpty || isHash(hash) else { return }
        let data = CloudSync.dataPrefs(c, index)
        if date >= data.int64("__profile_pin_changed_at") {
            CloudSync.profilesPrefs(c).set("perfil_\(index)_pin", hash.isEmpty ? nil : hash)
            data.edit { d in
                d["__profile_pin_hash"] = hash
                d["__profile_pin_changed_at"] = date
                d["__profile_pin_checked"] = true
            }
        }
    }

    static func markChecked(_ c: CloudCtx, _ index: Int) {
        CloudSync.dataPrefs(c, index).set("__profile_pin_checked", true)
    }
}
