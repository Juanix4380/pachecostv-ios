import SwiftUI

struct MyProfileView: View {
    @EnvironmentObject var app: AppModel
    @EnvironmentObject var session: SessionStore
    @EnvironmentObject var profiles: ProfileManager
    @EnvironmentObject var catalog: CatalogStore
    @EnvironmentObject var library: LibraryStore
    @EnvironmentObject var router: Router
    @State private var confirmLogout = false
    @State private var refreshing = false

    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(spacing: 24) {
                header
                switcher
                let cont = continueRow
                if !cont.isEmpty {
                    PosterRow(title: "Continuar viendo", items: cont.map { $0.0 }, style: .continueWatching,
                              progress: Dictionary(uniqueKeysWithValues: cont.map { ($0.0.id, $0.1) })) { p in
                        if p.kind == .movie { app.playMovie(p) } else { Task { await app.playSeries(p) } }
                    }
                }
                let list = myList
                if !list.isEmpty {
                    PosterRow(title: "Mi lista", items: list, onSeeAll: { router.open(.myList) }) { app.open($0) }
                }
                menu
                Text("Pacheco's TV para iPhone · versión \(Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String ?? "")")
                    .font(.system(size: 12)).foregroundStyle(PTV.text3)
                Color.clear.frame(height: 100)
            }
            .padding(.top, 20)
        }
        .background(AmbientBackground(color: Avatars.color(profiles.active?.avatar ?? 0).opacity(0.7)))
        .toolbar(.hidden, for: .navigationBar)
        .confirmationDialog("¿Cerrar sesión?", isPresented: $confirmLogout, titleVisibility: .visible) {
            Button("Cerrar sesión", role: .destructive) { app.logout() }
            Button("Cancelar", role: .cancel) {}
        } message: { Text("Tus perfiles e historial permanecen guardados en la nube.") }
    }

    private var header: some View {
        VStack(spacing: 12) {
            AvatarView(avatar: profiles.active?.avatar ?? 0, size: 104, selected: true)
                .shadow(color: Avatars.color(profiles.active?.avatar ?? 0).opacity(0.6), radius: 24)
            HStack(spacing: 6) {
                Text(profiles.active?.name ?? "Perfil").font(.system(size: 26, weight: .heavy)).foregroundStyle(.white)
                if profiles.active?.kids == true {
                    Text("KIDS").font(.system(size: 10, weight: .black)).foregroundStyle(.black)
                        .padding(.horizontal, 6).padding(.vertical, 3).background(PTV.gold, in: Capsule())
                }
            }
            accountLine
        }
    }

    private var accountLine: some View {
        let now = Int64(Date().timeIntervalSince1970)
        let exp = session.expiry
        let color: Color = exp <= 0 ? Color(white: 0.45) : (exp > now ? PTV.green : PTV.red)
        let text = exp <= 0 ? "Cuenta: \(session.user)" : (exp > now ? "Cuenta: \(session.user) · Vence \(Txt.date(exp))" : "Cuenta: \(session.user) · Vencida")
        return HStack(spacing: 6) {
            Circle().fill(color).frame(width: 8, height: 8)
            Text(text).font(.system(size: 13, weight: .medium)).foregroundStyle(PTV.text2)
        }
        .padding(.horizontal, 14).frame(height: 32)
        .glassCapsule(interactive: false)
    }

    private var switcher: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 16) {
                ForEach(profiles.profiles) { p in
                    Button {
                        guard p.index != profiles.activeIndex else { return }
                        Device.haptic(.medium)
                        app.switchProfile()
                    } label: {
                        VStack(spacing: 6) {
                            AvatarView(avatar: p.avatar, size: 58, selected: p.index == profiles.activeIndex)
                                .opacity(p.index == profiles.activeIndex ? 1 : 0.75)
                            Text(p.name).font(.system(size: 12, weight: .semibold)).foregroundStyle(.white).lineLimit(1).frame(width: 66)
                        }
                    }
                    .buttonStyle(PressScale())
                }
                Button { router.open(.manageProfiles) } label: {
                    VStack(spacing: 6) {
                        Image(systemName: "pencil").font(.system(size: 20, weight: .semibold)).foregroundStyle(.white)
                            .frame(width: 58, height: 58).glass(RoundedRectangle(cornerRadius: 14, style: .continuous), interactive: true)
                        Text("Editar").font(.system(size: 12, weight: .semibold)).foregroundStyle(PTV.text2)
                    }
                }
                .buttonStyle(PressScale())
            }
            .padding(.horizontal, 20)
        }
    }

    private var continueRow: [(PosterItem, Double)] {
        _ = library.version
        var out: [(PosterItem, Double)] = []
        for w in (library.history(.movie) + library.history(.series)).sorted(by: { $0.date > $1.date }) {
            let k: Kind = w.type == "series" ? .series : .movie
            guard let p = catalog.poster(k, w.key), !out.contains(where: { $0.0.id == p.id }) else { continue }
            out.append((p, w.progress))
            if out.count >= 15 { break }
        }
        return out
    }

    private var myList: [PosterItem] {
        _ = library.version
        let m = library.favorites(.movie).compactMap { catalog.poster(.movie, $0) }
        let s = library.favorites(.series).compactMap { catalog.poster(.series, $0) }
        return Array((m + s).prefix(30))
    }

    private var menu: some View {
        VStack(spacing: 0) {
            menuRow("person.2.fill", "Administrar perfiles") { router.open(.manageProfiles) }
            divider
            menuRow("person.text.rectangle.fill", "Mi cuenta") { router.open(.account) }
            divider
            menuRow("gearshape.fill", "Ajustes") { router.open(.settings) }
            divider
            menuRow(refreshing ? "hourglass" : "arrow.clockwise", refreshing ? "Actualizando listas…" : "Actualizar listas") {
                guard !refreshing else { return }
                refreshing = true
                Task {
                    let ok = await catalog.refreshNow()
                    refreshing = false
                    router.show(ok ? "Lista actualizada" : "No se pudo actualizar")
                }
            }
            divider
            menuRow("message.fill", "Soporte por WhatsApp") { Device.openWhatsApp() }
            divider
            menuRow("rectangle.portrait.and.arrow.right", "Cerrar sesión", destructive: true) { confirmLogout = true }
        }
        .glass(RoundedRectangle(cornerRadius: 22, style: .continuous))
        .padding(.horizontal, 16)
    }

    private var divider: some View { Rectangle().fill(Color.white.opacity(0.07)).frame(height: 0.6).padding(.leading, 54) }

    private func menuRow(_ icon: String, _ title: String, destructive: Bool = false, action: @escaping () -> Void) -> some View {
        Button { Device.haptic(); action() } label: {
            HStack(spacing: 14) {
                Image(systemName: icon).font(.system(size: 16, weight: .semibold))
                    .foregroundStyle(destructive ? PTV.red : .white).frame(width: 24)
                Text(title).font(.system(size: 16, weight: .semibold)).foregroundStyle(destructive ? PTV.red : .white)
                Spacer()
                if !destructive { Image(systemName: "chevron.right").font(.system(size: 13, weight: .bold)).foregroundStyle(PTV.text3) }
            }
            .padding(.horizontal, 16).frame(height: 54)
            .contentShape(Rectangle())
        }
        .buttonStyle(PressScale(scale: 0.98))
    }
}

struct ManageProfilesView: View {
    @EnvironmentObject var profiles: ProfileManager
    @EnvironmentObject var session: SessionStore
    @State private var edit: ProfilePickerView.EditTarget?

    var body: some View {
        List {
            ForEach(profiles.profiles) { p in
                Button { edit = .init(profile: p) } label: {
                    HStack(spacing: 14) {
                        AvatarView(avatar: p.avatar, size: 50)
                        VStack(alignment: .leading, spacing: 3) {
                            Text(p.name).font(.system(size: 16, weight: .bold)).foregroundStyle(.white)
                            HStack(spacing: 8) {
                                if p.kids { Text("Kids").foregroundStyle(PTV.gold) }
                                if p.hasPin { Label("PIN", systemImage: "lock.fill") }
                            }
                            .font(.system(size: 12, weight: .semibold)).foregroundStyle(PTV.text2)
                        }
                        Spacer()
                        Image(systemName: "pencil").foregroundStyle(PTV.text3)
                    }
                }
                .listRowBackground(Color.white.opacity(0.05))
            }
            if profiles.profiles.count < CloudSync.maxProfiles {
                Button { edit = .init(profile: nil) } label: {
                    Label("Agregar perfil", systemImage: "plus.circle.fill").font(.system(size: 16, weight: .semibold)).foregroundStyle(PTV.red)
                }
                .listRowBackground(Color.white.opacity(0.05))
            }
        }
        .scrollContentBackground(.hidden)
        .background(PTV.bg.ignoresSafeArea())
        .navigationTitle("Perfiles")
        .refreshable { await profiles.refreshFromCloud() }
        .sheet(item: $edit) { t in
            ProfileEditor(profile: t.profile).environmentObject(profiles).environmentObject(session)
                .presentationBackground(.ultraThinMaterial)
        }
    }
}

struct AccountView: View {
    @EnvironmentObject var session: SessionStore
    @State private var info: JObj?
    @State private var loading = true

    var body: some View {
        List {
            Section {
                row("Usuario", session.user)
                row("Estado", status)
                row("Vencimiento", session.expiry > 0 ? Txt.date(session.expiry) : "Sin fecha")
                row("Días restantes", days)
                if let i = info {
                    row("Conexiones", "\(i.str("active_cons", "0")) / \(i.str("max_connections", "1"))")
                }
            }
            .listRowBackground(Color.white.opacity(0.05))
            Section {
                Button { Device.openWhatsApp("Hola, quiero renovar mi cuenta de Pacheco's TV (\(session.user))") } label: {
                    Label("Renovar por WhatsApp", systemImage: "message.fill").foregroundStyle(PTV.green)
                }
                Button { Task { await session.checkAccess(force: true); await reload() } } label: {
                    Label(session.checking ? "Verificando…" : "Verificar cuenta", systemImage: "checkmark.shield.fill")
                }
            }
            .listRowBackground(Color.white.opacity(0.05))
        }
        .scrollContentBackground(.hidden)
        .background(PTV.bg.ignoresSafeArea())
        .navigationTitle("Mi cuenta")
        .overlay { if loading && info == nil { ProgressView().tint(.white) } }
        .task { await reload() }
    }

    private var status: String {
        if let b = session.blocked { return b.title }
        switch (info?.str("status") ?? "").lowercased() {
        case "active": return "Activa"
        case "expired": return "Vencida"
        case "disabled": return "Desactivada"
        case "banned": return "Bloqueada"
        default: return session.expiry > Int64(Date().timeIntervalSince1970) ? "Activa" : "Sin revisar"
        }
    }

    private var days: String {
        guard session.expiry > 0 else { return "Ilimitado" }
        let d = (session.expiry - Int64(Date().timeIntervalSince1970)) / 86400
        if d > 1 { return "\(d)" }
        if d == 1 { return "1" }
        if d == 0 { return "Vence hoy" }
        return "Cuenta vencida"
    }

    private func row(_ k: String, _ v: String) -> some View {
        HStack {
            Text(k).foregroundStyle(PTV.text2)
            Spacer()
            Text(v).fontWeight(.semibold).foregroundStyle(.white)
        }
    }

    private func reload() async {
        loading = true
        info = await Xtream.accountInfo(session.creds)
        loading = false
    }
}

struct SettingsView: View {
    @EnvironmentObject var catalog: CatalogStore
    @EnvironmentObject var router: Router
    @AppStorage("live_format") private var liveFormat = LiveFormat.auto.rawValue
    @AppStorage("player_engine") private var engine = PlayerPref.auto.rawValue
    @AppStorage("auto_next") private var autoNext = true

    var body: some View {
        List {
            Section {
                Picker("Formato de TV en vivo", selection: $liveFormat) {
                    ForEach(LiveFormat.allCases, id: \.rawValue) { f in Text(f.title).tag(f.rawValue) }
                }
                Picker("Reproductor", selection: $engine) {
                    ForEach(PlayerPref.allCases, id: \.rawValue) { p in Text(p.title).tag(p.rawValue) }
                }
            } header: { Text("Reproducción") } footer: {
                Text("Automático usa el reproductor del iPhone (con imagen en imagen y AirPlay) y cambia a VLC cuando el formato lo requiere.")
            }
            .listRowBackground(Color.white.opacity(0.05))
            Section("Series") {
                Toggle("Reproducir el siguiente episodio", isOn: $autoNext).tint(PTV.red)
            }
            .listRowBackground(Color.white.opacity(0.05))
            Section {
                Button("Actualizar listas ahora") {
                    Task { let ok = await catalog.refreshNow(); router.show(ok ? "Lista actualizada" : "No se pudo actualizar") }
                }
                Button("Borrar imágenes guardadas") {
                    ImagePipeline.shared.clear()
                    router.show("Imágenes borradas")
                }
                if let d = catalog.updatedAt {
                    HStack {
                        Text("Última actualización").foregroundStyle(PTV.text2)
                        Spacer()
                        Text(d.formatted(date: .abbreviated, time: .shortened)).foregroundStyle(.white)
                    }
                }
            } header: { Text("Listas") }
            .listRowBackground(Color.white.opacity(0.05))
        }
        .scrollContentBackground(.hidden)
        .background(PTV.bg.ignoresSafeArea())
        .navigationTitle("Ajustes")
    }
}

/// Menú "Más" a pantalla completa con el Inicio desenfocado detrás.
struct MoreMenuView: View {
    @EnvironmentObject var router: Router
    @EnvironmentObject var catalog: CatalogStore
    @State private var appear = false

    var body: some View {
        ZStack {
            Rectangle().fill(.ultraThinMaterial).ignoresSafeArea()
            Color.black.opacity(0.45).ignoresSafeArea()
            VStack(alignment: .leading, spacing: 4) {
                Spacer()
                option("house.fill", "Inicio", current: true) {}
                option("film.fill", "Películas") { router.open(.catalog(.movie)) }
                option("tv.fill", "Series") { router.open(.catalog(.series)) }
                if !catalog.kids { option("sportscourt.fill", "Deportes") { router.open(.events) } }
                option("dot.radiowaves.left.and.right", "TV en vivo") { router.tab = .live }
                option("plus.rectangle.on.rectangle", "Mi lista") { router.open(.myList) }
                option("gearshape.fill", "Ajustes") { router.open(.settings) }
                Spacer()
            }
            .padding(.horizontal, 36)
            .frame(maxWidth: .infinity, alignment: .leading)
            .offset(y: appear ? 0 : 18)
            .opacity(appear ? 1 : 0)
            VStack {
                Spacer()
                CircleIconButton(icon: "xmark", size: 64) { close() }
                    .padding(.bottom, 36)
            }
        }
        .onAppear { withAnimation(.spring(response: 0.35, dampingFraction: 0.85)) { appear = true } }
    }

    private func option(_ icon: String, _ title: String, current: Bool = false, action: @escaping () -> Void) -> some View {
        Button {
            Device.haptic()
            close()
            Task { @MainActor in try? await Task.sleep(nanoseconds: 150_000_000); action() }
        } label: {
            HStack(spacing: 20) {
                Image(systemName: icon).font(.system(size: 24, weight: .semibold)).frame(width: 34)
                Text(title).font(.system(size: 26, weight: current ? .bold : .medium))
            }
            .foregroundStyle(current ? Color.white : Color.white.opacity(0.7))
            .padding(.vertical, 12)
        }
        .buttonStyle(PressScale())
    }

    private func close() {
        withAnimation(.easeOut(duration: 0.15)) { router.moreMenu = false }
    }
}
