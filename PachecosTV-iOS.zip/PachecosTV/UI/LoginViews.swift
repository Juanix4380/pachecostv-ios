import SwiftUI

struct AmbientBackground: View {
    var color: Color = PTV.red
    @State private var move = false

    var body: some View {
        ZStack {
            PTV.bg
            Circle().fill(color.opacity(0.55)).frame(width: 420, height: 420).blur(radius: 120)
                .offset(x: move ? -90 : 110, y: move ? -260 : -180)
            Circle().fill(Color(red: 0.45, green: 0.0, blue: 0.08).opacity(0.7)).frame(width: 380, height: 380).blur(radius: 130)
                .offset(x: move ? 120 : -100, y: move ? 280 : 200)
            LinearGradient(colors: [.clear, PTV.bg.opacity(0.9)], startPoint: .top, endPoint: .bottom)
        }
        .ignoresSafeArea()
        .onAppear { withAnimation(.easeInOut(duration: 9).repeatForever(autoreverses: true)) { move = true } }
    }
}

struct SplashView: View {
    @State private var appear = false
    var body: some View {
        ZStack {
            AmbientBackground()
            VStack(spacing: 18) {
                Image("Logo").resizable().scaledToFit().frame(width: 190)
                    .scaleEffect(appear ? 1 : 0.86)
                    .opacity(appear ? 1 : 0)
                    .shadow(color: PTV.red.opacity(0.6), radius: 30)
                ProgressView().tint(.white).opacity(appear ? 0.8 : 0)
            }
        }
        .onAppear { withAnimation(.spring(response: 0.7, dampingFraction: 0.75)) { appear = true } }
    }
}

struct LoginView: View {
    @EnvironmentObject var app: AppModel
    @EnvironmentObject var session: SessionStore

    @State private var user = ""
    @State private var pass = ""
    @State private var showPass = false
    @State private var loading = false
    @State private var error: String?
    @FocusState private var focus: Field?

    enum Field { case user, pass }

    var body: some View {
        ZStack {
            AmbientBackground()
            ScrollView(showsIndicators: false) {
                VStack(spacing: 26) {
                    Image("Logo").resizable().scaledToFit().frame(width: 170)
                        .shadow(color: PTV.red.opacity(0.55), radius: 26)
                        .padding(.top, 50)
                    VStack(spacing: 6) {
                        Text("Bienvenido").font(.system(size: 30, weight: .heavy)).foregroundStyle(.white)
                        Text("Películas, series y TV en vivo en un solo lugar.")
                            .font(.system(size: 15)).foregroundStyle(PTV.text2).multilineTextAlignment(.center)
                    }
                    VStack(spacing: 14) {
                        field(icon: "person.fill", placeholder: "Usuario", text: $user, secure: false)
                            .focused($focus, equals: .user)
                            .submitLabel(.next)
                            .onSubmit { focus = .pass }
                        field(icon: "lock.fill", placeholder: "Contraseña", text: $pass, secure: !showPass, trailing: true)
                            .focused($focus, equals: .pass)
                            .submitLabel(.go)
                            .onSubmit { signIn() }
                        if let e = error {
                            HStack(spacing: 8) {
                                Image(systemName: "exclamationmark.triangle.fill")
                                Text(e).font(.system(size: 14, weight: .semibold))
                            }
                            .foregroundStyle(Color(red: 1, green: 0.45, blue: 0.45))
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .transition(.move(edge: .top).combined(with: .opacity))
                        }
                        PrimaryButton(title: loading ? "CONECTANDO..." : "INICIAR SESIÓN", loading: loading) { signIn() }
                            .disabled(loading)
                            .padding(.top, 4)
                    }
                    .padding(20)
                    .glass(RoundedRectangle(cornerRadius: 28, style: .continuous))
                    .padding(.horizontal, 20)

                    if !session.savedAccounts.isEmpty { savedAccounts }

                    Button { Device.openWhatsApp() } label: {
                        HStack(spacing: 8) {
                            Image(systemName: "message.fill")
                            Text("¿Necesitas ayuda? Escríbenos").font(.system(size: 14, weight: .semibold))
                        }
                        .foregroundStyle(PTV.text2)
                    }
                    .padding(.bottom, 40)
                }
                .frame(maxWidth: 520)
                .frame(maxWidth: .infinity)
            }
            .scrollDismissesKeyboard(.interactively)
        }
        .animation(.spring(response: 0.35, dampingFraction: 0.85), value: error)
    }

    private func field(icon: String, placeholder: String, text: Binding<String>, secure: Bool, trailing: Bool = false) -> some View {
        HStack(spacing: 12) {
            Image(systemName: icon).foregroundStyle(PTV.text3).frame(width: 20)
            Group {
                if secure {
                    SecureField("", text: text, prompt: Text(placeholder).foregroundColor(PTV.text3))
                } else {
                    TextField("", text: text, prompt: Text(placeholder).foregroundColor(PTV.text3))
                }
            }
            .textInputAutocapitalization(.never)
            .autocorrectionDisabled()
            .textContentType(secure || trailing ? .password : .username)
            .font(.system(size: 17, weight: .medium))
            .foregroundStyle(.white)
            if trailing {
                Button { showPass.toggle() } label: {
                    Image(systemName: showPass ? "eye.slash.fill" : "eye.fill").foregroundStyle(PTV.text3)
                }
            }
        }
        .padding(.horizontal, 16)
        .frame(height: 56)
        .background(Color.white.opacity(0.07), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 16, style: .continuous).stroke(Color.white.opacity(0.10), lineWidth: 0.8))
    }

    private var savedAccounts: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Cuentas guardadas").font(.system(size: 15, weight: .bold)).foregroundStyle(PTV.text2).padding(.horizontal, 24)
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 12) {
                    ForEach(session.savedAccounts) { a in
                        Button {
                            user = a.usuario; pass = a.password; signIn()
                        } label: {
                            HStack(spacing: 12) {
                                ZStack {
                                    Circle().fill(a.statusColor.opacity(0.22))
                                    Text(String(a.alias.prefix(1)).uppercased()).font(.system(size: 18, weight: .heavy)).foregroundStyle(.white)
                                }
                                .frame(width: 44, height: 44)
                                .overlay(Circle().stroke(a.statusColor, lineWidth: 2))
                                VStack(alignment: .leading, spacing: 3) {
                                    Text(a.alias).font(.system(size: 15, weight: .bold)).foregroundStyle(.white).lineLimit(1)
                                    HStack(spacing: 5) {
                                        Circle().fill(a.statusColor).frame(width: 7, height: 7)
                                        Text(a.statusText).font(.system(size: 12, weight: .medium)).foregroundStyle(PTV.text2)
                                    }
                                }
                            }
                            .padding(.horizontal, 14).padding(.vertical, 12)
                            .glass(RoundedRectangle(cornerRadius: 18, style: .continuous), interactive: true)
                        }
                        .buttonStyle(PressScale())
                        .contextMenu {
                            Button(role: .destructive) { session.deleteAccount(a) } label: { Label("Quitar cuenta", systemImage: "trash") }
                        }
                    }
                }
                .padding(.horizontal, 20)
            }
        }
    }

    private func signIn() {
        guard !loading else { return }
        focus = nil
        error = nil
        loading = true
        Task {
            let e = await session.login(user: user, password: pass)
            loading = false
            if let e = e {
                error = e
                Device.error()
            } else {
                Device.success()
                await app.afterLogin()
            }
        }
    }
}

/// Bloqueo global cuando la cuenta está vencida, desactivada o la sesión caducó.
struct AccessBlockView: View {
    @EnvironmentObject var app: AppModel
    @EnvironmentObject var session: SessionStore
    let state: AccessState

    var body: some View {
        ZStack {
            Rectangle().fill(.ultraThinMaterial).ignoresSafeArea()
            Color.black.opacity(0.55).ignoresSafeArea()
            ScrollView(showsIndicators: false) {
                VStack(spacing: 18) {
                    ZStack {
                        Circle().fill(PTV.red.opacity(0.18)).frame(width: 92, height: 92)
                        Image(systemName: state == .sessionExpired ? "person.badge.key.fill" : "exclamationmark.shield.fill")
                            .font(.system(size: 40, weight: .semibold)).foregroundStyle(PTV.red)
                    }
                    .padding(.top, 30)
                    Text(state.title).font(.system(size: 24, weight: .heavy)).foregroundStyle(.white).multilineTextAlignment(.center)
                    Text(state.message(expiry: session.expiry))
                        .font(.system(size: 15)).foregroundStyle(PTV.text2).multilineTextAlignment(.center)
                    if state != .sessionExpired {
                        VStack(spacing: 8) {
                            Image("WhatsAppQR").resizable().scaledToFit().frame(width: 170)
                                .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
                            Text("Escanea para contactar a soporte").font(.system(size: 13, weight: .medium)).foregroundStyle(PTV.text3)
                        }
                    }
                    VStack(spacing: 12) {
                        if state == .sessionExpired {
                            PrimaryButton(title: "INICIAR SESIÓN", icon: "arrow.right.circle.fill") { app.logout() }
                        } else {
                            PrimaryButton(title: session.checking ? "VERIFICANDO…" : "REINTENTAR", icon: "arrow.clockwise", loading: session.checking) {
                                Task { await session.checkAccess(force: true) }
                            }
                            GlassButton(title: "Soporte por WhatsApp", icon: "message.fill") { Device.openWhatsApp() }
                            Button("Cerrar sesión") { app.logout() }
                                .font(.system(size: 15, weight: .semibold)).foregroundStyle(PTV.text2).padding(.top, 6)
                        }
                    }
                    .padding(.top, 6)
                }
                .padding(26)
                .glass(RoundedRectangle(cornerRadius: 32, style: .continuous))
                .padding(20)
                .frame(maxWidth: 520)
                .frame(maxWidth: .infinity)
            }
        }
        .transition(.opacity)
    }
}
