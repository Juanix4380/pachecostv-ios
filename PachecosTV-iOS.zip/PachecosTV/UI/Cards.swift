import SwiftUI

struct PosterCard: View {
    let item: PosterItem
    var width: CGFloat = 116
    var progress: Double? = nil
    var caption: String? = nil

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            ZStack(alignment: .bottomLeading) {
                RemoteImage(url: item.image, maxPixel: 420, placeholder: item.title)
                    .frame(width: width, height: width * 1.5)
                    .clipped()
                if item.rating >= 7.5 && progress == nil {
                    Text("★ \(item.ratingText)")
                        .font(.system(size: 10, weight: .heavy))
                        .foregroundStyle(.black)
                        .padding(.horizontal, 6).padding(.vertical, 3)
                        .background(PTV.gold, in: Capsule())
                        .padding(6)
                        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topTrailing)
                }
                if let p = progress {
                    VStack(spacing: 0) {
                        Spacer()
                        LinearGradient(colors: [.clear, .black.opacity(0.85)], startPoint: .top, endPoint: .bottom).frame(height: 44)
                    }
                    Image(systemName: "play.fill")
                        .font(.system(size: 16, weight: .bold)).foregroundStyle(.white)
                        .frame(width: 38, height: 38)
                        .glass(Circle())
                        .frame(maxWidth: .infinity, maxHeight: .infinity)
                    GeometryReader { g in
                        ZStack(alignment: .leading) {
                            Capsule().fill(Color.white.opacity(0.25))
                            Capsule().fill(PTV.red).frame(width: max(4, g.size.width * p))
                        }
                    }
                    .frame(height: 4)
                    .padding(.horizontal, 8).padding(.bottom, 8)
                }
            }
            .frame(width: width, height: width * 1.5)
            .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 12, style: .continuous).stroke(Color.white.opacity(0.07), lineWidth: 0.6))
            if let c = caption {
                Text(c).font(.system(size: 11, weight: .medium)).foregroundStyle(PTV.text2).lineLimit(1)
                    .frame(width: width, alignment: .leading)
            }
        }
    }
}

struct WideCard: View {
    let item: PosterItem
    var width: CGFloat = 250

    var body: some View {
        ZStack(alignment: .bottomLeading) {
            RemoteImage(url: item.backdrop.isEmpty ? item.image : item.backdrop, maxPixel: 700, placeholder: item.title)
                .frame(width: width, height: width * 0.56)
                .clipped()
            LinearGradient(colors: [.clear, .black.opacity(0.9)], startPoint: .center, endPoint: .bottom)
            VStack(alignment: .leading, spacing: 2) {
                Text(item.title).font(.system(size: 15, weight: .bold)).foregroundStyle(.white).lineLimit(1)
                HStack(spacing: 6) {
                    if !item.yearText.isEmpty { Text(item.yearText) }
                    if !item.ratingText.isEmpty { Text("★ \(item.ratingText)").foregroundStyle(PTV.gold) }
                    Text(item.kind == .series ? "Serie" : "Película")
                }
                .font(.system(size: 11, weight: .semibold)).foregroundStyle(PTV.text2)
            }
            .padding(12)
        }
        .frame(width: width, height: width * 0.56)
        .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 14, style: .continuous).stroke(Color.white.opacity(0.07), lineWidth: 0.6))
    }
}

struct Top10Card: View {
    let item: PosterItem
    let rank: Int

    var body: some View {
        HStack(alignment: .bottom, spacing: -18) {
            OutlinedNumber(text: "\(rank)")
                .frame(width: rank == 10 ? 92 : 64, height: 120, alignment: .trailing)
                .zIndex(0)
            PosterCard(item: item, width: 104)
                .zIndex(1)
        }
    }
}

struct OutlinedNumber: View {
    let text: String
    var body: some View {
        ZStack {
            ForEach(0..<8, id: \.self) { i in
                let a = Double(i) * .pi / 4
                Text(text)
                    .font(.system(size: 118, weight: .black, design: .rounded))
                    .foregroundStyle(PTV.gold.opacity(0.9))
                    .offset(x: cos(a) * 2.2, y: sin(a) * 2.2)
            }
            Text(text)
                .font(.system(size: 118, weight: .black, design: .rounded))
                .foregroundStyle(LinearGradient(colors: [Color(white: 0.06), Color(white: 0.16)], startPoint: .top, endPoint: .bottom))
        }
        .fixedSize()
        .offset(y: 16)
    }
}

struct AvatarView: View {
    let avatar: Int
    var size: CGFloat = 96
    var selected = false

    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: size * 0.24, style: .continuous)
                .fill(LinearGradient(colors: [Avatars.color(avatar), Avatars.color(avatar).opacity(0.55)], startPoint: .topLeading, endPoint: .bottomTrailing))
            Image(Avatars.image(avatar))
                .resizable().scaledToFit()
                .padding(size * 0.06)
        }
        .frame(width: size, height: size)
        .clipShape(RoundedRectangle(cornerRadius: size * 0.24, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: size * 0.24, style: .continuous)
            .stroke(selected ? Color.white : Color.white.opacity(0.10), lineWidth: selected ? 3 : 0.8))
    }
}

struct ChannelLogo: View {
    let url: String
    let name: String
    var size: CGFloat = 52

    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 12, style: .continuous).fill(Color.white.opacity(0.06))
            if url.hasPrefix("http") {
                RemoteImage(url: url, maxPixel: 200, contentMode: .fit)
                    .padding(6)
            } else {
                Text(String(name.prefix(2)).uppercased())
                    .font(.system(size: size * 0.32, weight: .heavy)).foregroundStyle(PTV.text2)
            }
        }
        .frame(width: size, height: size)
        .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
    }
}

/// Fila horizontal de pósteres con estilos de Android (póster, Top 10, ancho, continuar).
struct PosterRow: View {
    let title: String
    let items: [PosterItem]
    var style: RowStyle = .poster
    var progress: [String: Double] = [:]
    var captions: [String: String] = [:]
    var onSeeAll: (() -> Void)? = nil
    let onTap: (PosterItem) -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            SectionTitle(title: title, action: onSeeAll)
            ScrollView(.horizontal, showsIndicators: false) {
                LazyHStack(spacing: style == .top10 ? 6 : 10) {
                    ForEach(Array(items.enumerated()), id: \.element.id) { idx, item in
                        Button { Device.haptic(); onTap(item) } label: {
                            switch style {
                            case .top10: Top10Card(item: item, rank: idx + 1)
                            case .wide: WideCard(item: item)
                            case .continueWatching: PosterCard(item: item, width: 116, progress: progress[item.id] ?? 0, caption: captions[item.id])
                            case .poster: PosterCard(item: item)
                            }
                        }
                        .buttonStyle(PressScale(scale: 0.96))
                        .scrollTransition(.interactive, axis: .horizontal) { content, phase in
                            content.scaleEffect(phase.isIdentity ? 1 : 0.94).opacity(phase.isIdentity ? 1 : 0.8)
                        }
                    }
                }
                .padding(.horizontal, 16)
                .scrollTargetLayout()
            }
            .scrollTargetBehavior(.viewAligned)
        }
    }
}

struct EmptyState: View {
    let icon: String
    let title: String
    var message: String = ""
    var body: some View {
        VStack(spacing: 12) {
            Image(systemName: icon).font(.system(size: 40, weight: .light)).foregroundStyle(PTV.text3)
            Text(title).font(.system(size: 18, weight: .bold)).foregroundStyle(.white)
            if !message.isEmpty {
                Text(message).font(.system(size: 14)).foregroundStyle(PTV.text2).multilineTextAlignment(.center)
            }
        }
        .padding(32)
        .frame(maxWidth: .infinity)
    }
}

struct LoadingRow: View {
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            RoundedRectangle(cornerRadius: 6).fill(Color.white.opacity(0.08)).frame(width: 160, height: 18).padding(.horizontal, 16)
            HStack(spacing: 10) {
                ForEach(0..<4, id: \.self) { _ in
                    RoundedRectangle(cornerRadius: 12).fill(Color.white.opacity(0.07)).frame(width: 116, height: 174)
                }
            }
            .padding(.horizontal, 16)
        }
        .shimmer()
    }
}
