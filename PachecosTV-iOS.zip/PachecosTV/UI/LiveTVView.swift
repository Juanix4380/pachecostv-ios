import SwiftUI

@MainActor
final class EpgCache: ObservableObject {
    static let shared = EpgCache()
    @Published private(set) var items: [String: [EpgItem]] = [:]
    private var loading = Set<String>()
    private var stamps: [String: Date] = [:]

    func now(_ id: String) -> EpgItem? { items[id]?.first { $0.isNow } ?? items[id]?.first }
    func next(_ id: String) -> EpgItem? {
        guard let list = items[id], let n = now(id), let i = list.firstIndex(of: n), i + 1 < list.count else { return nil }
        return list[i + 1]
    }

    func load(_ id: String, creds: Creds, limit: Int = 4) async {
        if loading.contains(id) { return }
        if let s = stamps[id], Date().timeIntervalSince(s) < 600, (items[id]?.count ?? 0) >= min(limit, 2) { return }
        loading.insert(id)
        let list = await Xtream.shortEpg(creds, id, limit: limit)
        loading.remove(id)
        stamps[id] = Date()
        items[id] = list
    }
}

struct LiveTVView: View {
    @EnvironmentObject var app: AppModel
    @EnvironmentObject var catalog: CatalogStore
    @EnvironmentObject var library: LibraryStore
    @EnvironmentObject var session: SessionStore
    @EnvironmentObject var router: Router
    /// Sin observar: el reproductor se redibuja solo, la lista no se recalcula cada medio segundo.
    @State private var player = PlayerModel()

    @State private var category = "all"
    @State private var query = ""
    @State private var fullscreen = false
    @State private var unlockedAdult = false
    @State private var askAdult: Category?
    @State private var adultPass = ""
    @State private var guideFor: Channel?
    @State private var showChannels = false
    @State private var started = false
    @State private var current: Channel?

    private var adultCats: Set<String> {
        Set(catalog.liveCats.filter { KidsFilter.esAdulto($0.name) }.map { $0.id })
    }

    private var channels: [Channel] {
        _ = library.version
        var list: [Channel]
        switch category {
        case "fav":
            let favs = library.favoriteChannels()
            list = catalog.live.filter { favs.contains($0.id) }
        case "recent":
            list = library.recentChannels().compactMap { catalog.liveById[$0] }
            if catalog.kids { let ok = Set(catalog.live.map { $0.id }); list = list.filter { ok.contains($0.id) } }
        case "all":
            let blocked = unlockedAdult ? Set<String>() : adultCats
            list = catalog.live.filter { !blocked.contains($0.categoryId) }
        default:
            list = catalog.live.filter { $0.categoryId == category }
        }
        let q = Txt.norm(query.trimmed)
        if !q.isEmpty { list = list.filter { $0.norm.contains(q) } }
        return list
    }

    var body: some View {
        GeometryReader { geo in
            VStack(spacing: 0) {
                ZStack {
                    PlayerScreen(model: player, compact: !fullscreen,
                                 onClose: { setFullscreen(false) },
                                 onExpand: { setFullscreen(true) },
                                 onShowChannels: { withAnimation(.spring(response: 0.35, dampingFraction: 0.85)) { showChannels = true } })
                    if current == nil { previewPlaceholder }
                    if fullscreen && showChannels { fullscreenChannels.transition(.move(edge: .trailing)) }
                }
                .frame(width: geo.size.width, height: fullscreen ? geo.size.height : geo.size.width * 9 / 16)
                if !fullscreen {
                    NowStrip(channel: current, onGuide: { c in guideFor = c })
                    listArea
                }
            }
        }
        .background((fullscreen ? Color.black : PTV.bg).ignoresSafeArea())
        .statusBarHidden(fullscreen)
        .persistentSystemOverlays(fullscreen ? .hidden : .automatic)
        .toolbar(.hidden, for: .navigationBar)
        .onReceive(player.$request) { r in
            if r?.channel?.id != current?.id { current = r?.channel }
        }
        .onAppear {
            player.configure(creds: session.creds, library: library)
            if !started { startLast() }
        }
        .onChange(of: router.tab) { _, t in
            if t != .live {
                if fullscreen { setFullscreen(false) }
                player.stop()
                started = false
            } else if !started {
                startLast()
            }
        }
        .onChange(of: router.player?.id) { _, id in if id != nil { player.pause() } }
        .onChange(of: catalog.live.count) { _, _ in if !started { startLast() } }
        .sheet(item: $guideFor) { ch in
            GuideSheet(channel: ch) { guideFor = nil; play(ch) }
                .presentationDetents([.medium, .large]).presentationBackground(.ultraThinMaterial)
        }
        .alert("Contenido para adultos", isPresented: Binding(get: { askAdult != nil }, set: { if !$0 { askAdult = nil } })) {
            SecureField("Contraseña de la cuenta", text: $adultPass)
            Button("Desbloquear") {
                if adultPass == session.password, let c = askAdult { unlockedAdult = true; category = c.id; Device.success() } else { Device.error() }
                adultPass = ""
            }
            Button("Cancelar", role: .cancel) { adultPass = "" }
        } message: { Text("Escribe la contraseña de tu cuenta para ver esta categoría.") }
    }

    private func startLast() {
        guard router.tab == .live, !catalog.live.isEmpty, session.blocked == nil else { return }
        let lastId = library.lastChannel
        let candidate = catalog.live.first { $0.id == lastId } ?? catalog.live.first
        guard let ch = candidate else { return }
        started = true
        if !library.favoriteChannels().isEmpty && category == "all" { category = "fav" }
        play(ch)
    }

    private func play(_ ch: Channel) {
        if let b = session.blocked, b.blocks { Device.error(); return }
        var list = channels
        if !list.contains(ch) { list = catalog.live.filter { $0.categoryId == ch.categoryId } }
        player.start(app.channelRequest(ch, in: list, landscape: true))
        Task { await EpgCache.shared.load(ch.id, creds: session.creds) }
    }

    private func setFullscreen(_ on: Bool) {
        Device.haptic(.medium)
        if !on { showChannels = false }
        withAnimation(.easeInOut(duration: 0.3)) {
            fullscreen = on
            router.tabBarHidden = on
        }
        if on { Orientation.set(.landscape, rotate: .landscapeRight) } else { Orientation.set(.portrait, rotate: .portrait) }
    }

    private var previewPlaceholder: some View {
        ZStack {
            LinearGradient(colors: [Color(red: 0.25, green: 0.02, blue: 0.05), .black], startPoint: .topLeading, endPoint: .bottomTrailing)
            VStack(spacing: 10) {
                Image("LogoMark").resizable().scaledToFit().frame(width: 54)
                Text(catalog.live.isEmpty ? "Cargando canales…" : "Elige un canal").font(.system(size: 15, weight: .semibold)).foregroundStyle(PTV.text2)
            }
        }
        .allowsHitTesting(false)
    }

    // MARK: Categorías y canales

    private var listArea: some View {
        let list = channels
        let favs = library.favoriteChannels()
        let playingId = current?.id
        return VStack(spacing: 0) {
            HStack(spacing: 10) {
                Image(systemName: "magnifyingglass").foregroundStyle(PTV.text3)
                TextField("", text: $query, prompt: Text("Buscar canal").foregroundColor(PTV.text3))
                    .textInputAutocapitalization(.never).autocorrectionDisabled().foregroundStyle(.white)
                if !query.isEmpty { Button { query = "" } label: { Image(systemName: "xmark.circle.fill").foregroundStyle(PTV.text3) } }
            }
            .padding(.horizontal, 14).frame(height: 42)
            .background(Color.white.opacity(0.08), in: RoundedRectangle(cornerRadius: 12, style: .continuous))
            .padding(.horizontal, 14).padding(.top, 10)
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 8) {
                    Chip(title: "Favoritos", icon: "star.fill", selected: category == "fav") { category = "fav" }
                    Chip(title: "Recientes", icon: "clock.fill", selected: category == "recent") { category = "recent" }
                    Chip(title: "Todos", selected: category == "all") { category = "all" }
                    ForEach(catalog.liveCats) { c in
                        let adult = adultCats.contains(c.id)
                        Chip(title: c.name, icon: adult && !unlockedAdult ? "lock.fill" : nil, selected: category == c.id) {
                            if adult && !unlockedAdult { askAdult = c } else { category = c.id }
                        }
                    }
                }
                .padding(.horizontal, 14).padding(.vertical, 10)
            }
            ScrollViewReader { proxy in
                ScrollView(showsIndicators: false) {
                    LazyVStack(spacing: 2) {
                        if list.isEmpty {
                            EmptyState(icon: category == "fav" ? "star" : "tv",
                                       title: category == "fav" ? "Sin favoritos" : "Sin canales",
                                       message: category == "fav" ? "Toca la estrella de un canal para tenerlo aquí." : "No hay canales en esta categoría.")
                        }
                        ForEach(list) { ch in
                            ChannelRow(channel: ch, playing: playingId == ch.id, favorite: favs.contains(ch.id), creds: session.creds)
                                .id(ch.id)
                                .onTapGesture {
                                    Device.haptic()
                                    if playingId == ch.id && player.failed == nil { setFullscreen(true) } else { play(ch) }
                                }
                                .contextMenu {
                                    Button { library.toggleFavoriteChannel(ch.id) } label: {
                                        Label(favs.contains(ch.id) ? "Quitar de favoritos" : "Agregar a favoritos", systemImage: "star")
                                    }
                                    Button { guideFor = ch } label: { Label("Guía de programación", systemImage: "list.bullet.rectangle") }
                                }
                        }
                        Color.clear.frame(height: 100)
                    }
                    .padding(.horizontal, 8)
                }
                .onChange(of: current?.id) { _, id in
                    if let id = id { withAnimation { proxy.scrollTo(id, anchor: .center) } }
                }
            }
        }
    }

    private var fullscreenChannels: some View {
        let list = player.request?.channels ?? []
        let playingId = current?.id
        return ZStack(alignment: .trailing) {
            Color.black.opacity(0.3).onTapGesture { withAnimation { showChannels = false } }
            VStack(alignment: .leading, spacing: 0) {
                HStack {
                    Text("Canales").font(.system(size: 18, weight: .bold)).foregroundStyle(.white)
                    Spacer()
                    CircleIconButton(icon: "xmark", size: 34) { withAnimation { showChannels = false } }
                }
                .padding(16)
                ScrollViewReader { proxy in
                    ScrollView {
                        LazyVStack(spacing: 2) {
                            ForEach(list) { ch in
                                ChannelRow(channel: ch, playing: playingId == ch.id, favorite: false, creds: session.creds, compact: true)
                                    .id(ch.id)
                                    .onTapGesture {
                                        if let i = list.firstIndex(of: ch) { player.playChannel(at: i) }
                                        withAnimation { showChannels = false }
                                    }
                            }
                        }
                        .padding(.horizontal, 6)
                    }
                    .onAppear { if let id = playingId { proxy.scrollTo(id, anchor: .center) } }
                }
            }
            .frame(width: 340)
            .glass(Rectangle())
        }
    }
}

struct NowStrip: View {
    let channel: Channel?
    let onGuide: (Channel) -> Void
    @EnvironmentObject var library: LibraryStore
    @EnvironmentObject var router: Router
    @ObservedObject private var epg = EpgCache.shared

    var body: some View {
        let now = channel.flatMap { epg.now($0.id) }
        let next = channel.flatMap { epg.next($0.id) }
        HStack(spacing: 12) {
            if let c = channel { ChannelLogo(url: c.icon, name: c.name, size: 46) }
            VStack(alignment: .leading, spacing: 3) {
                Text(channel?.name ?? "TV en vivo").font(.system(size: 16, weight: .bold)).foregroundStyle(.white).lineLimit(1)
                if let n = now {
                    Text("\(Txt.hour(n.start)) · \(n.title)").font(.system(size: 13, weight: .medium)).foregroundStyle(PTV.text2).lineLimit(1)
                    ProgressView(value: n.progress).tint(PTV.red).scaleEffect(x: 1, y: 0.6)
                } else {
                    Text("Desliza el video para cambiar de canal").font(.system(size: 13)).foregroundStyle(PTV.text3).lineLimit(1)
                }
                if let x = next {
                    Text("Después: \(Txt.hour(x.start)) \(x.title)").font(.system(size: 11)).foregroundStyle(PTV.text3).lineLimit(1)
                }
            }
            Spacer(minLength: 0)
            if let c = channel {
                let fav = library.favoriteChannels().contains(c.id)
                Button {
                    library.toggleFavoriteChannel(c.id)
                    Device.success()
                    router.show(fav ? "Quitado de favoritos" : "Agregado a favoritos")
                } label: {
                    Image(systemName: fav ? "star.fill" : "star").font(.system(size: 18, weight: .semibold))
                        .foregroundStyle(fav ? PTV.gold : .white).frame(width: 42, height: 42).glass(Circle(), interactive: true)
                        .contentTransition(.symbolEffect(.replace))
                }
                Button { onGuide(c) } label: {
                    Image(systemName: "list.bullet.rectangle").font(.system(size: 17, weight: .semibold)).foregroundStyle(.white)
                        .frame(width: 42, height: 42).glass(Circle(), interactive: true)
                }
            }
        }
        .padding(.horizontal, 14).padding(.vertical, 10)
        .background(Color.white.opacity(0.04))
    }
}

struct ChannelRow: View {
    let channel: Channel
    let playing: Bool
    let favorite: Bool
    let creds: Creds
    var compact = false
    @ObservedObject private var epg = EpgCache.shared

    var body: some View {
        let now = epg.now(channel.id)
        HStack(spacing: 12) {
            Text("\(channel.num)").font(.system(size: 12, weight: .bold, design: .rounded)).foregroundStyle(PTV.text3)
                .frame(width: 30).monospacedDigit()
            ChannelLogo(url: channel.icon, name: channel.name, size: compact ? 40 : 50)
            VStack(alignment: .leading, spacing: 3) {
                HStack(spacing: 6) {
                    Text(channel.name).font(.system(size: 15, weight: .semibold)).foregroundStyle(playing ? PTV.red : .white).lineLimit(1)
                    if favorite { Image(systemName: "star.fill").font(.system(size: 10)).foregroundStyle(PTV.gold) }
                }
                if let n = now {
                    Text(n.title).font(.system(size: 12)).foregroundStyle(PTV.text2).lineLimit(1)
                    GeometryReader { g in
                        ZStack(alignment: .leading) {
                            Capsule().fill(Color.white.opacity(0.12))
                            Capsule().fill(playing ? PTV.red : Color.white.opacity(0.55)).frame(width: g.size.width * n.progress)
                        }
                    }
                    .frame(height: 3)
                }
            }
            Spacer(minLength: 0)
            if playing {
                Image(systemName: "waveform").font(.system(size: 16, weight: .bold)).foregroundStyle(PTV.red)
                    .symbolEffect(.variableColor.iterative, options: .repeating)
            }
        }
        .padding(.horizontal, 10).padding(.vertical, compact ? 6 : 9)
        .background(playing ? Color.white.opacity(0.08) : Color.clear, in: RoundedRectangle(cornerRadius: 14, style: .continuous))
        .contentShape(Rectangle())
        .task(id: channel.id) {
            if !compact { await epg.load(channel.id, creds: creds) }
        }
    }
}

struct GuideSheet: View {
    let channel: Channel
    let onPlay: () -> Void
    @EnvironmentObject var session: SessionStore
    @State private var items: [EpgItem] = []
    @State private var loading = true

    var body: some View {
        NavigationStack {
            List {
                if loading { ProgressView().tint(.white).frame(maxWidth: .infinity).listRowBackground(Color.clear) }
                else if items.isEmpty { Text("Sin guía de programación").foregroundStyle(PTV.text2).listRowBackground(Color.clear) }
                ForEach(items) { e in
                    VStack(alignment: .leading, spacing: 4) {
                        HStack {
                            Text("\(Txt.hour(e.start)) - \(Txt.hour(e.end))").font(.system(size: 12, weight: .bold)).foregroundStyle(e.isNow ? PTV.red : PTV.text2)
                            if e.isNow {
                                Text("AHORA").font(.system(size: 9, weight: .black)).foregroundStyle(.white)
                                    .padding(.horizontal, 6).padding(.vertical, 2).background(PTV.red, in: Capsule())
                            }
                        }
                        Text(e.title).font(.system(size: 15, weight: .bold)).foregroundStyle(.white)
                        if !e.desc.isEmpty { Text(e.desc).font(.system(size: 13)).foregroundStyle(PTV.text2).lineLimit(3) }
                    }
                    .listRowBackground(Color.clear)
                }
            }
            .listStyle(.plain)
            .scrollContentBackground(.hidden)
            .navigationTitle(channel.name)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button { onPlay() } label: { Label("Ver", systemImage: "play.fill") }
                }
            }
        }
        .task {
            items = await Xtream.shortEpg(session.creds, channel.id, limit: 12)
            loading = false
        }
    }
}
