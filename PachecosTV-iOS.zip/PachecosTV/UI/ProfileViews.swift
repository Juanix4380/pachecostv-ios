import SwiftUI

struct ProfilePickerView: View {
    @EnvironmentObject var app: AppModel
    @EnvironmentObject var profiles: ProfileManager
    @EnvironmentObject var session: SessionStore

    @State private var editing = false
    @State private var editTarget: EditTarget?
    @State private var pinFor: Profile?
    @State private var opening: Int?

    struct EditTarget: Identifiable {
        let id = UUID()
        let profile: Profile?
    }

    private let columns = [GridItem(.flexible(), spacing: 18), GridItem(.flexible(), spacing: 18), GridItem(.flexible(), spacing: 18)]

    var body: some View {
        ZStack {
            AmbientBackground(color: Color(red: 0.6, green: 0.05, blue: 0.1))
            VStack(spacing: 0) {
                HStack {
                    Image("Logo").resizable().scaledToFit().frame(height: 40)
                    Spacer()
                    Button(editing ? "Listo" : "Editar") {
                        Device.haptic()
                        withAnimation(.spring(response: 0.35, dampingFraction: 0.8)) { editing.toggle() }
                    }
                    .font(.system(size: 16, weight: .bold)).foregroundStyle(.white)
                    .padding(.horizontal, 16).frame(height: 38)
                    .glassCapsule()
                }
                .padding(.horizontal, 20).padding(.top, 8)

                ScrollView(showsIndicators: false) {
                    VStack(spacing: 30) {
                        Text(editing ? "Administrar perfiles" : "¿Quién está viendo?")
                            .font(.system(size: 28, weight: .heavy)).foregroundStyle(.white)
                            .padding(.top, 40)
                            .contentTransition(.opacity)
                        LazyVGrid(columns: columns, spacing: 26) {
                            ForEach(profiles.profiles) { p in profileCell(p) }
                            if profiles.profiles.count < CloudSync.maxProfiles {
                                Button { editTarget = EditTarget(profile: nil) } label: {
                                    VStack(spacing: 10) {
                                        ZStack {
                                            RoundedRectangle(cornerRadius: 24, style: .continuous).fill(Color.white.opacity(0.07))
                                            Image(systemName: "plus").font(.system(size: 34, weight: .semibold)).foregroundStyle(PTV.text2)
                                        }
                                        .frame(width: 100, height: 100)
                                        .overlay(RoundedRectangle(cornerRadius: 24, style: .continuous).stroke(Color.white.opacity(0.15), style: StrokeStyle(lineWidth: 1.2, dash: [6, 5])))
                                        Text("Agregar").font(.system(size: 14, weight: .semibold)).foregroundStyle(PTV.text2)
                                    }
                                }
                                .buttonStyle(PressScale())
                            }
                        }
                        .padding(.horizontal, 20)
                        if profiles.syncing && profiles.profiles.isEmpty {
                            ProgressView().tint(.white)
                        }
                    }
                    .padding(.bottom, 60)
                }
                .refreshable { await profiles.refreshFromCloud() }

                Button { app.logout() } label: {
                    Text("Cerrar sesión · \(session.user)").font(.system(size: 14, weight: .semibold)).foregroundStyle(PTV.text3)
                }
                .padding(.bottom, 16)
            }
        }
        .sheet(item: $editTarget) { t in
            ProfileEditor(profile: t.profile).environmentObject(profiles).environmentObject(session)
                .presentationDetents([.large])
                .presentationBackground(.ultraThinMaterial)
        }
        .fullScreenCover(item: $pinFor) { p in
            PinPadView(profile: p) { ok in
                pinFor = nil
                if ok { app.enter(p.index) }
            }
            .environmentObject(profiles).environmentObject(session)
        }
        .task {
            if profiles.profiles.isEmpty { await profiles.refreshFromCloud() }
            app.autoEnterIfSingle()
        }
    }

    private func profileCell(_ p: Profile) -> some View {
        Button { tap(p) } label: {
            VStack(spacing: 10) {
                ZStack(alignment: .bottomTrailing) {
                    AvatarView(avatar: p.avatar, size: 100)
                        .overlay {
                            if editing {
                                ZStack {
                                    RoundedRectangle(cornerRadius: 24, style: .continuous).fill(Color.black.opacity(0.5))
                                    Image(systemName: "pencil").font(.system(size: 28, weight: .bold)).foregroundStyle(.white)
                                }
                            }
                        }
                        .scaleEffect(opening == p.index ? 1.12 : 1)
                    if p.hasPin && !editing {
                        Image(systemName: "lock.fill").font(.system(size: 12, weight: .bold)).foregroundStyle(.white)
                            .frame(width: 26, height: 26).background(Color.black.opacity(0.7), in: Circle())
                            .offset(x: 6, y: 6)
                    }
                }
                HStack(spacing: 4) {
                    Text(p.name).font(.system(size: 15, weight: .semibold)).foregroundStyle(.white).lineLimit(1)
                    if p.kids {
                        Text("KIDS").font(.system(size: 9, weight: .black)).foregroundStyle(.black)
                            .padding(.horizontal, 5).padding(.vertical, 2).background(PTV.gold, in: Capsule())
                    }
                }
            }
        }
        .buttonStyle(PressScale())
    }

    private func tap(_ p: Profile) {
        Device.haptic(.medium)
        if editing { editTarget = EditTarget(profile: p); return }
        withAnimation(.spring(response: 0.3, dampingFraction: 0.6)) { opening = p.index }
        Task {
            await profiles.refreshPin(p.index)
            opening = nil
            let current = profiles.profiles.first { $0.index == p.index } ?? p
            if current.hasPin { pinFor = current } else { app.enter(p.index) }
        }
    }
}

struct ProfileEditor: View {
    @EnvironmentObject var profiles: ProfileManager
    @EnvironmentObject var session: SessionStore
    @Environment(\.dismiss) private var dismiss

    let profile: Profile?
    @State private var name = ""
    @State private var avatar = 0
    @State private var kids = false
    @State private var saving = false
    @State private var askPin = false
    @State private var confirmDelete = false
    @State private var deletePassword = ""
    @State private var deleteError: String?

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 24) {
                    AvatarView(avatar: avatar, size: 120, selected: true)
                        .padding(.top, 12)
                        .contentTransition(.interpolate)
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 12) {
                            ForEach(0..<Avatars.count, id: \.self) { i in
                                Button {
                                    Device.haptic()
                                    withAnimation(.spring(response: 0.3, dampingFraction: 0.7)) { avatar = i }
                                } label: { AvatarView(avatar: i, size: 64, selected: i == avatar) }
                                .buttonStyle(PressScale())
                            }
                        }
                        .padding(.horizontal, 20)
                    }
                    VStack(spacing: 14) {
                        TextField("", text: $name, prompt: Text("Nombre del perfil").foregroundColor(PTV.text3))
                            .font(.system(size: 18, weight: .semibold)).foregroundStyle(.white)
                            .padding(.horizontal, 16).frame(height: 54)
                            .background(Color.white.opacity(0.08), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                        Toggle(isOn: $kids) {
                            VStack(alignment: .leading, spacing: 2) {
                                Text("Perfil infantil (Kids)").font(.system(size: 16, weight: .semibold))
                                Text("Solo contenido para niños").font(.system(size: 13)).foregroundStyle(PTV.text2)
                            }
                        }
                        .tint(PTV.red)
                        .padding(16)
                        .background(Color.white.opacity(0.06), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                        if let p = profile {
                            Button { askPin = true } label: {
                                HStack {
                                    Image(systemName: p.hasPin ? "lock.fill" : "lock.open")
                                    Text(p.hasPin ? "Cambiar o quitar PIN" : "Proteger con PIN").font(.system(size: 16, weight: .semibold))
                                    Spacer()
                                    Image(systemName: "chevron.right").foregroundStyle(PTV.text3)
                                }
                                .foregroundStyle(.white)
                                .padding(16)
                                .background(Color.white.opacity(0.06), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                            }
                        }
                    }
                    .padding(.horizontal, 20)

                    PrimaryButton(title: "GUARDAR", icon: "checkmark", loading: saving) { save() }
                        .padding(.horizontal, 20)
                        .disabled(name.trimmed.isEmpty || saving)
                        .opacity(name.trimmed.isEmpty ? 0.5 : 1)

                    if let p = profile, profiles.profiles.count > 1 {
                        Button(role: .destructive) { confirmDelete = true } label: {
                            Label("Eliminar perfil", systemImage: "trash").font(.system(size: 15, weight: .semibold))
                        }
                        .foregroundStyle(PTV.red)
                        .alert("Eliminar \(p.name)", isPresented: $confirmDelete) {
                            SecureField("Contraseña de la cuenta", text: $deletePassword)
                            Button("Eliminar", role: .destructive) { delete(p) }
                            Button("Cancelar", role: .cancel) { deletePassword = "" }
                        } message: {
                            Text("Se borrarán su historial y su lista en todos tus dispositivos. Confirma la contraseña de tu cuenta.")
                        }
                    }
                    if let e = deleteError { Text(e).font(.system(size: 14)).foregroundStyle(PTV.red) }
                }
                .padding(.bottom, 30)
            }
            .navigationTitle(profile == nil ? "Nuevo perfil" : "Editar perfil")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Cerrar") { dismiss() } }
            }
        }
        .onAppear {
            if let p = profile { name = p.name; avatar = p.avatar; kids = p.kids }
            else { avatar = Int.random(in: 0..<10) }
        }
        .fullScreenCover(isPresented: $askPin) {
            if let p = profile {
                PinSetupView(profile: p) { askPin = false }
                    .environmentObject(profiles).environmentObject(session)
            }
        }
    }

    private func save() {
        let n = String(name.trimmed.prefix(20))
        saving = true
        Task {
            if let p = profile {
                await profiles.update(p.index, name: n, avatar: avatar, kids: kids)
            } else {
                _ = await profiles.create(name: n, avatar: avatar, kids: kids)
            }
            saving = false
            Device.success()
            dismiss()
        }
    }

    private func delete(_ p: Profile) {
        guard deletePassword == session.password else {
            deleteError = "Contraseña incorrecta"
            deletePassword = ""
            Device.error()
            return
        }
        deletePassword = ""
        Task {
            if await profiles.delete(p.index) { dismiss() } else { deleteError = "No se pudo eliminar. Revisa tu conexión." }
        }
    }
}

/// Teclado numérico propio para el PIN de 4 números.
struct PinKeypad: View {
    @Binding var code: String
    var shakes: Int
    var onComplete: (String) -> Void

    var body: some View {
        VStack(spacing: 34) {
            HStack(spacing: 22) {
                ForEach(0..<4, id: \.self) { i in
                    Circle()
                        .fill(i < code.count ? Color.white : Color.white.opacity(0.14))
                        .frame(width: 16, height: 16)
                        .scaleEffect(i < code.count ? 1.15 : 1)
                        .animation(.spring(response: 0.25, dampingFraction: 0.6), value: code.count)
                }
            }
            .modifier(ShakeEffect(animatableData: CGFloat(shakes)))
            .animation(.linear(duration: 0.42), value: shakes)
            VStack(spacing: 18) {
                ForEach(0..<3, id: \.self) { r in
                    HStack(spacing: 26) {
                        ForEach(1...3, id: \.self) { c in key("\(r * 3 + c)") }
                    }
                }
                HStack(spacing: 26) {
                    Color.clear.frame(width: 76, height: 76)
                    key("0")
                    Button {
                        if !code.isEmpty { code.removeLast(); Device.haptic() }
                    } label: {
                        Image(systemName: "delete.left").font(.system(size: 24, weight: .medium)).foregroundStyle(.white)
                            .frame(width: 76, height: 76)
                    }
                }
            }
        }
    }

    private func key(_ d: String) -> some View {
        Button {
            guard code.count < 4 else { return }
            Device.haptic()
            code.append(d)
            if code.count == 4 { let c = code; Task { @MainActor in try? await Task.sleep(nanoseconds: 120_000_000); onComplete(c) } }
        } label: {
            Text(d).font(.system(size: 30, weight: .medium, design: .rounded)).foregroundStyle(.white)
                .frame(width: 76, height: 76)
                .glass(Circle(), interactive: true)
        }
        .buttonStyle(PressScale(scale: 0.9))
    }
}

struct PinPadView: View {
    @EnvironmentObject var profiles: ProfileManager
    @EnvironmentObject var session: SessionStore
    let profile: Profile
    let done: (Bool) -> Void

    @State private var code = ""
    @State private var shakes = 0
    @State private var message = "Escribe tu PIN para entrar"
    @State private var forgot = false
    @State private var accountPass = ""
    @State private var attempts = 0

    var body: some View {
        ZStack {
            AmbientBackground(color: Avatars.color(profile.avatar))
            VStack(spacing: 26) {
                HStack {
                    Spacer()
                    CircleIconButton(icon: "xmark") { done(false) }
                }
                .padding(.horizontal, 20)
                AvatarView(avatar: profile.avatar, size: 84)
                VStack(spacing: 6) {
                    Text(profile.name).font(.system(size: 22, weight: .heavy)).foregroundStyle(.white)
                    Text(message).font(.system(size: 15)).foregroundStyle(PTV.text2)
                }
                PinKeypad(code: $code, shakes: shakes) { c in check(c) }
                Button("¿Olvidaste el PIN?") { forgot = true }
                    .font(.system(size: 15, weight: .semibold)).foregroundStyle(PTV.text2)
                Spacer(minLength: 0)
            }
            .padding(.top, 10)
        }
        .alert("¿Olvidaste el PIN de \(profile.name)?", isPresented: $forgot) {
            SecureField("Contraseña de la cuenta principal", text: $accountPass)
            Button("Verificar") { recover() }
            Button("Cancelar", role: .cancel) { accountPass = "" }
        } message: {
            Text("Para proteger los perfiles, confirma la contraseña de tu cuenta principal. No necesitas el PIN anterior.")
        }
    }

    private func check(_ c: String) {
        if profiles.verifyPin(profile.index, c) {
            Device.success()
            done(true)
        } else {
            Device.error()
            message = "PIN incorrecto"
            shakes += 1
            code = ""
        }
    }

    private func recover() {
        let ok = accountPass == session.password
        accountPass = ""
        if ok {
            attempts = 0
            profiles.setPin(profile.index, nil)
            Device.success()
            done(true)
        } else {
            attempts += 1
            message = attempts >= 5 ? "Demasiados intentos. Espera un minuto" : "Contraseña incorrecta (\(attempts)/5)"
            Device.error()
        }
    }
}

struct PinSetupView: View {
    @EnvironmentObject var profiles: ProfileManager
    let profile: Profile
    let done: () -> Void

    @State private var first: String?
    @State private var code = ""
    @State private var shakes = 0

    var body: some View {
        ZStack {
            AmbientBackground(color: Avatars.color(profile.avatar))
            VStack(spacing: 26) {
                HStack {
                    if profile.hasPin {
                        Button("Quitar PIN") {
                            profiles.setPin(profile.index, nil)
                            Device.success()
                            done()
                        }
                        .font(.system(size: 15, weight: .semibold)).foregroundStyle(PTV.red)
                    }
                    Spacer()
                    CircleIconButton(icon: "xmark") { done() }
                }
                .padding(.horizontal, 20)
                AvatarView(avatar: profile.avatar, size: 84)
                VStack(spacing: 6) {
                    Text(first == nil ? "Nuevo PIN" : "Confirma el PIN").font(.system(size: 22, weight: .heavy)).foregroundStyle(.white)
                    Text("4 números para proteger a \(profile.name)").font(.system(size: 15)).foregroundStyle(PTV.text2)
                }
                PinKeypad(code: $code, shakes: shakes) { c in
                    if let f = first {
                        if f == c {
                            profiles.setPin(profile.index, c)
                            Device.success()
                            done()
                        } else {
                            first = nil; code = ""; shakes += 1; Device.error()
                        }
                    } else {
                        first = c; code = ""
                    }
                }
                Spacer(minLength: 0)
            }
            .padding(.top, 10)
        }
    }
}

struct ShakeEffect: GeometryEffect {
    var animatableData: CGFloat
    func effectValue(size: CGSize) -> ProjectionTransform {
        ProjectionTransform(CGAffineTransform(translationX: 12 * sin(animatableData * .pi * 4), y: 0))
    }
}
