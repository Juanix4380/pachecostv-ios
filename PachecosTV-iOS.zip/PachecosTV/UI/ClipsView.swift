import SwiftUI

/// "Avances": películas recientes en pantalla completa, deslizando hacia arriba (como Android).
struct ClipsView: View {
    @EnvironmentObject var app: AppModel
    @EnvironmentObject var catalog: CatalogStore
    @EnvironmentObject var library: LibraryStore
    @EnvironmentObject var session: SessionStore
    @EnvironmentObject var router: Router
    @AppStorage("clips_muted") private var muted = true

    @State private var player = PlayerModel()
    @State private var clips: [PosterItem] = []
    @State private var current: String?
    @State private var advanceTask: Task<Void, Never>?

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            if clips.isEmpty {
                VStack(spacing: 14) {
                    if catalog.vods.isEmpty {
                        ProgressView().tint(.white)
                        Text("Cargando avances…").foregroundStyle(PTV.text2)
                    } else {
                        EmptyState(icon: "film", title: "Sin avances", message: "Abre Películas una vez para cargar los avances.")
                    }
                }
            } else {
                ScrollView(.vertical, showsIndicators: false) {
                    LazyVStack(spacing: 0) {
                        ForEach(clips) { c in
                            ClipPage(item: c, player: player, active: current == c.id, muted: $muted,
                                     inList: library.isFavorite(.movie, c.contentId),
                                     onPlay: { app.playMovie(c) },
                                     onList: {
                                         let added = library.toggleFavorite(.movie, c.contentId)
                                         Device.success()
                                         router.show(added ? "Agregado a Mi lista" : "Quitado de Mi lista")
                                     },
                                     onInfo: { router.open(.detail(c)) })
                                .containerRelativeFrame([.horizontal, .vertical])
                                .id(c.id)
                        }
                    }
                    .scrollTargetLayout()
                }
                .scrollTargetBehavior(.paging)
                .scrollPosition(id: $current)
                .ignoresSafeArea()
            }
        }
        .toolbar(.hidden, for: .navigationBar)
        .onAppear {
            player.configure(creds: session.creds, library: library)
            if clips.isEmpty { build() }
            resumeIfVisible()
        }
        .onChange(of: catalog.vods.count) { _, _ in if clips.isEmpty { build(); resumeIfVisible() } }
        .onChange(of: current) { _, _ in playCurrent() }
        .onChange(of: router.tab) { _, _ in resumeIfVisible() }
        .onChange(of: router.clipsPath.count) { _, _ in resumeIfVisible() }
        .onChange(of: router.player?.id) { _, _ in resumeIfVisible() }
        .onChange(of: muted) { _, m in player.muted = m }
    }

    private var visible: Bool { router.tab == .clips && router.clipsPath.isEmpty && router.player == nil }

    private func build() {
        let names = catalog.catNames
        let pool = catalog.vods.filter { (v: Vod) -> Bool in
            v.icon.hasPrefix("http") && !KidsFilter.esAdulto("\(v.name) \(v.genre) \(names["movie:" + v.categoryId] ?? "")")
        }
        let recent = pool.sorted { $0.added > $1.added }.prefix(90).shuffled().prefix(40)
        clips = recent.map { PosterItem($0) }
        current = clips.first?.id
    }

    private func resumeIfVisible() {
        if visible { playCurrent() } else { advanceTask?.cancel(); player.stop() }
    }

    private func playCurrent() {
        guard visible, let id = current, let c = clips.first(where: { $0.id == id }) else { return }
        if session.blocked?.blocks == true { return }
        player.muted = muted
        if player.request?.contentId != c.contentId || player.engine == nil {
            player.start(PlayRequest(kind: .movie, contentId: c.contentId, title: c.title,
                                     candidates: Streams.movie(c.contentId, ext: c.ext, session.creds), startAt: 90))
        } else {
            player.play()
        }
        advanceTask?.cancel()
        advanceTask = Task {
            try? await Task.sleep(nanoseconds: 50_000_000_000)
            if Task.isCancelled { return }
            if let i = clips.firstIndex(where: { $0.id == id }), i + 1 < clips.count {
                withAnimation(.easeInOut(duration: 0.5)) { current = clips[i + 1].id }
            }
        }
    }
}

struct ClipPage: View {
    let item: PosterItem
    let player: PlayerModel
    let active: Bool
    @Binding var muted: Bool
    let inList: Bool
    let onPlay: () -> Void
    let onList: () -> Void
    let onInfo: () -> Void

    var body: some View {
        ZStack(alignment: .bottom) {
            RemoteImage(url: item.image, maxPixel: 900)
                .blur(radius: 30).opacity(0.5)
            ClipVideo(player: player, active: active, poster: item.image)
            LinearGradient(colors: [.black.opacity(0.5), .clear, .clear, .black.opacity(0.92)], startPoint: .top, endPoint: .bottom)
                .allowsHitTesting(false)
            HStack(alignment: .bottom, spacing: 16) {
                VStack(alignment: .leading, spacing: 10) {
                    HStack(spacing: 6) {
                        Image("LogoMark").resizable().scaledToFit().frame(width: 18, height: 18)
                        Text("AVANCE").font(.system(size: 11, weight: .black)).tracking(2).foregroundStyle(.white.opacity(0.85))
                    }
                    Text(item.title).font(.system(size: 26, weight: .heavy)).foregroundStyle(.white).lineLimit(2)
                    HStack(spacing: 8) {
                        if !item.yearText.isEmpty { Text(item.yearText) }
                        if !item.ratingText.isEmpty { Text("★ \(item.ratingText)").foregroundStyle(PTV.gold) }
                        if !item.genre.isEmpty { Text(item.genre).lineLimit(1) }
                    }
                    .font(.system(size: 13, weight: .semibold)).foregroundStyle(.white.opacity(0.8))
                    if !item.plot.isEmpty {
                        Text(item.plot).font(.system(size: 13)).foregroundStyle(.white.opacity(0.75)).lineLimit(2)
                    }
                    Button { Device.haptic(.medium); onPlay() } label: {
                        Label("Ver película", systemImage: "play.fill").font(.system(size: 15, weight: .bold)).foregroundStyle(.black)
                            .padding(.horizontal, 20).frame(height: 44).background(Color.white, in: Capsule())
                    }
                    .buttonStyle(PressScale())
                }
                Spacer(minLength: 0)
                VStack(spacing: 18) {
                    sideButton(muted ? "speaker.slash.fill" : "speaker.wave.2.fill", muted ? "Sonido" : "Silenciar") { muted.toggle() }
                    sideButton(inList ? "checkmark" : "plus", "Mi lista") { onList() }
                    sideButton("info.circle", "Info") { onInfo() }
                }
            }
            .padding(.horizontal, 18)
            .padding(.bottom, 110)
        }
    }

    private func sideButton(_ icon: String, _ label: String, action: @escaping () -> Void) -> some View {
        Button { Device.haptic(); action() } label: {
            VStack(spacing: 5) {
                Image(systemName: icon).font(.system(size: 20, weight: .semibold)).foregroundStyle(.white)
                    .frame(width: 50, height: 50).glass(Circle(), interactive: true)
                    .contentTransition(.symbolEffect(.replace))
                Text(label).font(.system(size: 11, weight: .semibold)).foregroundStyle(.white)
            }
        }
        .buttonStyle(PressScale(scale: 0.9))
    }
}

struct ClipVideo: View {
    @ObservedObject var player: PlayerModel
    let active: Bool
    let poster: String

    var body: some View {
        ZStack {
            if active {
                VideoSurface(model: player, active: true)
                    .opacity(player.started ? 1 : 0)
                    .animation(.easeIn(duration: 0.4), value: player.started)
            }
            if !active || !player.started {
                RemoteImage(url: poster, maxPixel: 900, contentMode: .fit)
                    .padding(.vertical, 80)
                    .overlay {
                        if active && player.failed == nil { ProgressView().tint(.white).controlSize(.large) }
                    }
            }
        }
        .allowsHitTesting(false)
    }
}
