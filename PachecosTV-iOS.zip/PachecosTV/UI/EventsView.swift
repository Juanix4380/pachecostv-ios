import SwiftUI

struct EventsView: View {
    @EnvironmentObject var app: AppModel
    @EnvironmentObject var catalog: CatalogStore
    @State private var day = 0
    @State private var filter = "Todos"
    @State private var matches: [Match] = []
    @State private var loading = true
    @State private var selected: Match?

    private let filters = ["Todos", "En vivo", "Fútbol", "NFL", "NBA", "MLB", "NHL", "UFC"]

    private var shown: [Match] {
        matches.filter { (m: Match) -> Bool in
            switch filter {
            case "En vivo": return m.live
            case "Fútbol": return m.league.sport == "soccer"
            case "NFL": return m.league.slug == "nfl" || m.league.slug == "college-football"
            case "NBA": return m.league.slug == "nba" || m.league.slug == "wnba"
            case "MLB": return m.league.slug == "mlb"
            case "NHL": return m.league.slug == "nhl"
            case "UFC": return m.league.slug == "ufc"
            default: return true
            }
        }
    }

    private func dayTitle(_ offset: Int) -> String {
        switch offset {
        case -1: return "Ayer"
        case 0: return "Hoy"
        case 1: return "Mañana"
        default:
            let d = Calendar.current.date(byAdding: .day, value: offset, to: Date()) ?? Date()
            let f = DateFormatter()
            f.locale = Locale(identifier: "es_MX")
            f.dateFormat = "EEE d"
            return f.string(from: d).capitalized
        }
    }

    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(alignment: .leading, spacing: 14) {
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 8) {
                        ForEach(-1..<6, id: \.self) { d in Chip(title: dayTitle(d), selected: d == day) { day = d } }
                    }
                    .padding(.horizontal, 16)
                }
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 8) {
                        ForEach(filters, id: \.self) { f in
                            Chip(title: f, icon: f == "En vivo" ? "dot.radiowaves.left.and.right" : nil, selected: f == filter) { filter = f }
                        }
                    }
                    .padding(.horizontal, 16)
                }
                if loading && matches.isEmpty {
                    ForEach(0..<5, id: \.self) { _ in
                        RoundedRectangle(cornerRadius: 20).fill(Color.white.opacity(0.06)).frame(height: 120).padding(.horizontal, 16)
                    }
                    .shimmer()
                } else if shown.isEmpty {
                    EmptyState(icon: "sportscourt", title: "Sin partidos", message: "No hay eventos para este día con ese filtro.")
                } else {
                    LazyVStack(spacing: 12) {
                        ForEach(shown) { m in
                            Button { Device.haptic(); selected = m } label: { MatchCard(match: m) }
                                .buttonStyle(PressScale(scale: 0.98))
                        }
                    }
                    .padding(.horizontal, 16)
                }
                Color.clear.frame(height: 100)
            }
            .padding(.top, 8)
        }
        .background(PTV.bg.ignoresSafeArea())
        .navigationTitle("Deportes")
        .navigationBarTitleDisplayMode(.large)
        .refreshable { await load() }
        .task(id: day) { await load() }
        .task(id: "live-\(day)") {
            while !Task.isCancelled {
                try? await Task.sleep(nanoseconds: 60_000_000_000)
                if day == 0 && matches.contains(where: { $0.live }) { await load() }
            }
        }
        .sheet(item: $selected) { m in
            MatchChannelsSheet(match: m).presentationDetents([.medium, .large]).presentationBackground(.ultraThinMaterial)
        }
    }

    private func load() async {
        loading = true
        let d = Calendar.current.date(byAdding: .day, value: day, to: Date()) ?? Date()
        let list = await Sports.matches(day: d)
        if !Task.isCancelled { matches = list }
        loading = false
    }
}

struct MatchCard: View {
    let match: Match

    var body: some View {
        VStack(spacing: 12) {
            HStack(spacing: 8) {
                if !match.leagueLogo.isEmpty { RemoteImage(url: match.leagueLogo, maxPixel: 80, contentMode: .fit).frame(width: 18, height: 18) }
                Text(match.league.name).font(.system(size: 12, weight: .bold)).foregroundStyle(PTV.text2).lineLimit(1)
                Spacer()
                status
            }
            HStack(spacing: 12) {
                team(match.home)
                VStack(spacing: 2) {
                    if match.live || match.finished {
                        Text("\(match.home.score)  -  \(match.away.score)")
                            .font(.system(size: 26, weight: .heavy, design: .rounded)).foregroundStyle(.white).monospacedDigit()
                            .contentTransition(.numericText())
                    } else {
                        Text(Txt.hour(match.start)).font(.system(size: 18, weight: .heavy)).foregroundStyle(.white)
                    }
                    if match.finished { Text("Final").font(.system(size: 11, weight: .semibold)).foregroundStyle(PTV.text3) }
                }
                .frame(minWidth: 96)
                team(match.away)
            }
            if !match.tv.isEmpty {
                HStack(spacing: 6) {
                    Image(systemName: "tv").font(.system(size: 11))
                    Text(match.tv.prefix(3).joined(separator: " · ")).lineLimit(1)
                }
                .font(.system(size: 11, weight: .medium)).foregroundStyle(PTV.text3)
            }
        }
        .padding(16)
        .glass(RoundedRectangle(cornerRadius: 22, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 22, style: .continuous).stroke(match.live ? PTV.red.opacity(0.6) : Color.clear, lineWidth: 1.2))
    }

    @ViewBuilder
    private var status: some View {
        if match.live {
            HStack(spacing: 5) {
                Circle().fill(PTV.red).frame(width: 7, height: 7)
                    .symbolEffect(.pulse)
                Text(match.detail.isEmpty ? "EN VIVO" : match.detail).font(.system(size: 11, weight: .heavy)).foregroundStyle(PTV.red).lineLimit(1)
            }
        } else if !match.finished {
            Text("Por comenzar").font(.system(size: 11, weight: .semibold)).foregroundStyle(PTV.text3)
        }
    }

    private func team(_ t: Team) -> some View {
        VStack(spacing: 6) {
            RemoteImage(url: t.logo, maxPixel: 160, contentMode: .fit).frame(width: 46, height: 46)
            Text(t.short).font(.system(size: 13, weight: .bold)).foregroundStyle(.white).lineLimit(2).multilineTextAlignment(.center)
        }
        .frame(maxWidth: .infinity)
    }
}

struct MatchChannelsSheet: View {
    let match: Match
    @EnvironmentObject var app: AppModel
    @EnvironmentObject var catalog: CatalogStore
    @EnvironmentObject var router: Router
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        let byName = Sports.channels(for: match, in: catalog.live)
        let nets = Sports.networkChannels(for: match, in: catalog.live).filter { c in !byName.contains(c) }
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 16) {
                    MatchCard(match: match).padding(.horizontal, 16)
                    if byName.isEmpty && nets.isEmpty {
                        EmptyState(icon: "tv.slash", title: "Sin canal por ahora",
                                   message: match.finished ? "Este partido ya terminó." : "Cuando el canal del partido esté disponible aparecerá aquí. También puedes buscarlo en TV en vivo.")
                        GlassButton(title: "Ir a TV en vivo", icon: "dot.radiowaves.left.and.right") {
                            dismiss()
                            router.tab = .live
                        }
                        .frame(maxWidth: .infinity)
                    }
                    if !byName.isEmpty { section("Canales del partido", byName) }
                    if !nets.isEmpty { section("Cadenas que lo transmiten", nets) }
                }
                .padding(.vertical, 16)
            }
            .navigationTitle(match.title)
            .navigationBarTitleDisplayMode(.inline)
        }
    }

    private func section(_ title: String, _ list: [Channel]) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(title).font(.system(size: 17, weight: .bold)).foregroundStyle(.white).padding(.horizontal, 16)
            ForEach(list) { ch in
                Button {
                    Device.haptic()
                    var req = app.channelRequest(ch, in: list, landscape: true)
                    req.subtitle = match.title
                    dismiss()
                    Task { @MainActor in
                        try? await Task.sleep(nanoseconds: 450_000_000)
                        app.play(req)
                    }
                } label: {
                    HStack(spacing: 12) {
                        ChannelLogo(url: ch.icon, name: ch.name, size: 46)
                        Text(ch.name).font(.system(size: 15, weight: .semibold)).foregroundStyle(.white).lineLimit(2)
                        Spacer()
                        Image(systemName: "play.circle.fill").font(.system(size: 28)).foregroundStyle(PTV.red)
                    }
                    .padding(12)
                    .glass(RoundedRectangle(cornerRadius: 16, style: .continuous), interactive: true)
                }
                .buttonStyle(PressScale(scale: 0.98))
                .padding(.horizontal, 16)
            }
        }
    }
}
