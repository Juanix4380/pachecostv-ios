import SwiftUI

enum SortMode: String, CaseIterable {
    case recent, az, rating, year
    var title: String {
        switch self {
        case .recent: return "Recién agregadas"
        case .az: return "A - Z"
        case .rating: return "Mejor calificadas"
        case .year: return "Año"
        }
    }
}

struct CatalogView: View {
    let kind: Kind
    @EnvironmentObject var app: AppModel
    @EnvironmentObject var catalog: CatalogStore
    @EnvironmentObject var library: LibraryStore
    @EnvironmentObject var session: SessionStore

    @State private var category = "all"
    @State private var query = ""
    @State private var sort: SortMode = .recent
    @State private var results: [PosterItem] = []
    @State private var working = true
    @State private var unlockedAdult = false
    @State private var askAdult: Category?
    @State private var adultPass = ""

    private let columns = [GridItem(.adaptive(minimum: 106, maximum: 140), spacing: 10)]

    private var cats: [Category] { catalog.cats(kind) }

    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(alignment: .leading, spacing: 14) {
                searchField
                chips
                if working && results.isEmpty {
                    LazyVGrid(columns: columns, spacing: 12) {
                        ForEach(0..<12, id: \.self) { _ in
                            RoundedRectangle(cornerRadius: 12).fill(Color.white.opacity(0.07)).aspectRatio(2 / 3, contentMode: .fit)
                        }
                    }
                    .padding(.horizontal, 14)
                    .shimmer()
                } else if results.isEmpty {
                    EmptyState(icon: "magnifyingglass", title: "Sin resultados",
                               message: query.isEmpty ? "Esta categoría no tiene contenido por ahora." : "No encontramos “\(query)”.")
                } else {
                    Text("\(results.count) títulos").font(.system(size: 13, weight: .medium)).foregroundStyle(PTV.text3).padding(.horizontal, 16)
                    LazyVGrid(columns: columns, spacing: 14) {
                        ForEach(results) { p in
                            NavigationLink(value: Route.detail(p)) {
                                GridPoster(item: p)
                            }
                            .buttonStyle(PressScale(scale: 0.96))
                        }
                    }
                    .padding(.horizontal, 14)
                }
                Color.clear.frame(height: 100)
            }
            .padding(.top, 8)
        }
        .background(PTV.bg.ignoresSafeArea())
        .navigationTitle(kind == .movie ? "Películas" : "Series")
        .navigationBarTitleDisplayMode(.large)
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Menu {
                    Picker("Ordenar", selection: $sort) {
                        ForEach(SortMode.allCases, id: \.self) { s in Text(s.title).tag(s) }
                    }
                } label: {
                    Image(systemName: "arrow.up.arrow.down.circle.fill").font(.system(size: 20)).foregroundStyle(.white)
                }
            }
        }
        .task(id: "\(category)|\(query)|\(sort.rawValue)|\(catalog.vods.count)|\(catalog.series.count)|\(library.version)") { await filter() }
        .alert("Contenido para adultos", isPresented: Binding(get: { askAdult != nil }, set: { if !$0 { askAdult = nil } })) {
            SecureField("Contraseña de la cuenta", text: $adultPass)
            Button("Desbloquear") {
                if adultPass == session.password, let c = askAdult { unlockedAdult = true; category = c.id; Device.success() } else { Device.error() }
                adultPass = ""
            }
            Button("Cancelar", role: .cancel) { adultPass = "" }
        } message: { Text("Escribe la contraseña de tu cuenta para ver esta categoría.") }
    }

    private var searchField: some View {
        HStack(spacing: 10) {
            Image(systemName: "magnifyingglass").foregroundStyle(PTV.text3)
            TextField("", text: $query, prompt: Text(kind == .movie ? "Buscar películas" : "Buscar series").foregroundColor(PTV.text3))
                .textInputAutocapitalization(.never).autocorrectionDisabled().foregroundStyle(.white)
            if !query.isEmpty {
                Button { query = "" } label: { Image(systemName: "xmark.circle.fill").foregroundStyle(PTV.text3) }
            }
        }
        .padding(.horizontal, 14).frame(height: 46)
        .background(Color.white.opacity(0.08), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
        .padding(.horizontal, 16)
    }

    private var chips: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 8) {
                Chip(title: "Todas", selected: category == "all") { category = "all" }
                Chip(title: "Mi lista", icon: "plus", selected: category == "fav") { category = "fav" }
                Chip(title: "Vistas", icon: "clock.arrow.circlepath", selected: category == "hist") { category = "hist" }
                ForEach(cats) { c in
                    let adult = KidsFilter.esAdulto(c.name)
                    Chip(title: c.name, icon: adult && !unlockedAdult ? "lock.fill" : nil, selected: category == c.id) {
                        if adult && !unlockedAdult { askAdult = c } else { category = c.id }
                    }
                }
            }
            .padding(.horizontal, 16)
        }
    }

    private func filter() async {
        working = true
        let source: [PosterItem]
        switch category {
        case "fav": source = library.favorites(kind).compactMap { catalog.poster(kind, $0) }
        case "hist": source = library.history(kind).compactMap { catalog.poster(kind, $0.key) }
        default: source = catalog.items(kind)
        }
        let cat = category, q = Txt.norm(query.trimmed), s = sort
        let names = catalog.catNames
        let k = kind
        let adultUnlocked = unlockedAdult || catalog.kids
        let out = await Task.detached(priority: .userInitiated) { () -> [PosterItem] in
            var list = source
            if cat != "all" && cat != "fav" && cat != "hist" { list = list.filter { $0.categoryId == cat } }
            else if cat == "all" && !adultUnlocked {
                list = list.filter { !KidsFilter.esAdulto(names["\(k.rawValue):\($0.categoryId)"] ?? "") }
            }
            if !q.isEmpty {
                let words = q.split(separator: " ").map { String($0) }
                list = list.filter { (p: PosterItem) -> Bool in
                    let t = Txt.norm(p.title)
                    return words.allSatisfy { t.contains($0) }
                }
            }
            if cat == "fav" || cat == "hist" { return list }
            switch s {
            case .recent: list.sort { $0.added > $1.added }
            case .az: list.sort { $0.title.localizedCaseInsensitiveCompare($1.title) == .orderedAscending }
            case .rating: list.sort { $0.rating > $1.rating }
            case .year: list.sort { (Txt.year($0.year) ?? 0) > (Txt.year($1.year) ?? 0) }
            }
            return list
        }.value
        if Task.isCancelled { return }
        results = out
        working = false
    }
}

struct GridPoster: View {
    let item: PosterItem
    var body: some View {
        VStack(alignment: .leading, spacing: 5) {
            Color.clear
                .aspectRatio(2 / 3, contentMode: .fit)
                .overlay(RemoteImage(url: item.image, maxPixel: 380, placeholder: item.title))
                .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
                .overlay(alignment: .topTrailing) {
                    if item.rating >= 7 {
                        Text("★ \(item.ratingText)").font(.system(size: 9, weight: .heavy)).foregroundStyle(.black)
                            .padding(.horizontal, 5).padding(.vertical, 2).background(PTV.gold, in: Capsule()).padding(5)
                    }
                }
            Text(item.title).font(.system(size: 11, weight: .semibold)).foregroundStyle(PTV.text2).lineLimit(1)
        }
    }
}

// MARK: - Detalle de película o serie

struct DetailView: View {
    let item: PosterItem
    @EnvironmentObject var app: AppModel
    @EnvironmentObject var catalog: CatalogStore
    @EnvironmentObject var library: LibraryStore
    @EnvironmentObject var session: SessionStore
    @EnvironmentObject var router: Router

    @State private var tmdb: TmdbInfo?
    @State private var logo = ""
    @State private var vod = VodInfo()
    @State private var series = SeriesInfo()
    @State private var loadingSeries = true
    @State private var season = 1
    @State private var expanded = false
    @State private var trailerKey: String?

    private var isSeries: Bool { item.kind == .series }

    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(alignment: .leading, spacing: 18) {
                header
                VStack(alignment: .leading, spacing: 18) {
                    actions
                    synopsis
                    if let t = tmdb, !t.cast.isEmpty { castRow(t.cast) }
                    if isSeries { episodesSection }
                    similar
                }
                .padding(.top, -40)
                Color.clear.frame(height: 100)
            }
        }
        .background(PTV.bg.ignoresSafeArea())
        .ignoresSafeArea(edges: .top)
        .navigationBarTitleDisplayMode(.inline)
        .toolbarBackground(.hidden, for: .navigationBar)
        .task { await load() }
    }

    private var backdrop: String {
        if let b = tmdb?.backdrop, !b.isEmpty { return b }
        if !series.backdrop.isEmpty { return series.backdrop }
        if !vod.backdrop.isEmpty { return vod.backdrop }
        if !item.backdrop.isEmpty { return item.backdrop }
        return item.image
    }

    private var header: some View {
        GeometryReader { g in
            let minY = g.frame(in: .global).minY
            ZStack(alignment: .bottom) {
                RemoteImage(url: backdrop, maxPixel: 1400)
                    .frame(width: g.size.width, height: 460 + max(0, minY))
                    .clipped()
                    .offset(y: -max(0, minY))
                LinearGradient(colors: [.black.opacity(0.35), .clear, PTV.bg.opacity(0.85), PTV.bg], startPoint: .top, endPoint: .bottom)
                VStack(spacing: 12) {
                    if !logo.isEmpty {
                        RemoteImage(url: logo, maxPixel: 800, contentMode: .fit)
                            .frame(maxWidth: 260, maxHeight: 110)
                            .shadow(color: .black.opacity(0.6), radius: 10)
                    } else {
                        Text(tmdb?.title.nilIfEmpty ?? item.title).font(.system(size: 32, weight: .heavy)).foregroundStyle(.white)
                            .multilineTextAlignment(.center).lineLimit(3).minimumScaleFactor(0.6)
                    }
                    metaLine
                }
                .padding(.horizontal, 24)
                .padding(.bottom, 56)
            }
        }
        .frame(height: 460)
    }

    private var metaLine: some View {
        let year = tmdb?.year.nilIfEmpty ?? item.yearText
        let rating = (tmdb?.rating ?? 0) > 0 ? String(format: "%.1f", tmdb?.rating ?? 0) : item.ratingText
        let genres = tmdb?.genres.nilIfEmpty ?? (isSeries ? series.genre : vod.genre).nilIfEmpty ?? item.genre
        var runtime = ""
        if let r = tmdb?.runtime, r > 0 { runtime = r >= 60 ? "\(r / 60) h \(r % 60) min" : "\(r) min" }
        else if !vod.duration.isEmpty { runtime = vod.duration }
        return VStack(spacing: 6) {
            HStack(spacing: 10) {
                if !year.isEmpty { Text(year) }
                if !rating.isEmpty { Label(rating, systemImage: "star.fill").foregroundStyle(PTV.gold) }
                if !runtime.isEmpty { Text(runtime) }
                if isSeries && series.seasons.count > 0 { Text("\(series.seasons.count) temporada\(series.seasons.count == 1 ? "" : "s")") }
            }
            .font(.system(size: 14, weight: .semibold)).foregroundStyle(.white.opacity(0.85))
            if !genres.isEmpty {
                Text(genres).font(.system(size: 13, weight: .medium)).foregroundStyle(PTV.text2).lineLimit(1)
            }
        }
    }

    private var watch: WatchItem? {
        _ = library.version
        return library.find(item.kind, item.contentId)
    }

    private var resumeEpisode: Episode? {
        guard isSeries, let w = watch else { return nil }
        return series.seasons.values.flatMap { $0 }.first { $0.id == w.episodeId }
    }

    private var actions: some View {
        let w = watch
        let inList = { () -> Bool in _ = library.version; return library.isFavorite(item.kind, item.contentId) }()
        var title = "Reproducir"
        if let w = w, w.canResume {
            if isSeries, let ep = resumeEpisode { title = "Continuar T\(ep.season) E\(ep.number)" }
            else { title = "Continuar · \(Txt.time(Double(w.position) / 1000))" }
        } else if isSeries, let w = w, !w.episodeId.isEmpty {
            title = "Siguiente episodio"
        }
        return VStack(spacing: 12) {
            PrimaryButton(title: title.uppercased(), icon: "play.fill", loading: isSeries && loadingSeries) { play(fromStart: false) }
            if let w = w, w.canResume {
                VStack(spacing: 6) {
                    GeometryReader { g in
                        ZStack(alignment: .leading) {
                            Capsule().fill(Color.white.opacity(0.18))
                            Capsule().fill(PTV.red).frame(width: g.size.width * w.progress)
                        }
                    }
                    .frame(height: 4)
                    HStack {
                        Text(w.remainingText).font(.system(size: 12, weight: .medium)).foregroundStyle(PTV.text2)
                        Spacer()
                        Button("Desde el inicio") { play(fromStart: true) }.font(.system(size: 13, weight: .bold)).foregroundStyle(.white)
                    }
                }
            }
            HStack(spacing: 10) {
                actionButton(inList ? "En Mi lista" : "Mi lista", inList ? "checkmark" : "plus") {
                    let added = library.toggleFavorite(item.kind, item.contentId)
                    Device.success()
                    router.show(added ? "Agregado a Mi lista" : "Quitado de Mi lista")
                }
                if trailerKey != nil || !(isSeries ? series.trailer : vod.trailer).isEmpty {
                    actionButton("Tráiler", "play.rectangle") { openTrailer() }
                }
                if let w = w, w.position > 0 {
                    actionButton("Quitar vista", "eye.slash") { library.remove(item.kind, item.contentId) }
                }
            }
        }
        .padding(.horizontal, 18)
    }

    private func actionButton(_ t: String, _ icon: String, action: @escaping () -> Void) -> some View {
        Button { Device.haptic(); action() } label: {
            VStack(spacing: 6) {
                Image(systemName: icon).font(.system(size: 20, weight: .semibold)).contentTransition(.symbolEffect(.replace))
                Text(t).font(.system(size: 12, weight: .semibold))
            }
            .foregroundStyle(.white)
            .frame(maxWidth: .infinity).frame(height: 64)
            .glass(RoundedRectangle(cornerRadius: 16, style: .continuous), interactive: true)
        }
        .buttonStyle(PressScale())
    }

    private var synopsis: some View {
        let text = tmdb?.overview.nilIfEmpty ?? (isSeries ? series.plot : vod.plot).nilIfEmpty ?? item.plot
        let cast = isSeries ? series.cast : vod.cast
        return VStack(alignment: .leading, spacing: 8) {
            if !text.isEmpty {
                Text(text).font(.system(size: 15)).foregroundStyle(.white.opacity(0.85))
                    .lineLimit(expanded ? nil : 4)
                    .onTapGesture { withAnimation { expanded.toggle() } }
            }
            if tmdb?.cast.isEmpty ?? true, !cast.isEmpty {
                Text("Reparto: \(cast)").font(.system(size: 13)).foregroundStyle(PTV.text3).lineLimit(2)
            }
            if !vod.director.isEmpty {
                Text("Dirección: \(vod.director)").font(.system(size: 13)).foregroundStyle(PTV.text3).lineLimit(1)
            }
        }
        .padding(.horizontal, 18)
    }

    private func castRow(_ cast: [TmdbCast]) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            SectionTitle(title: "Reparto")
            ScrollView(.horizontal, showsIndicators: false) {
                LazyHStack(alignment: .top, spacing: 14) {
                    ForEach(cast) { c in
                        VStack(spacing: 6) {
                            RemoteImage(url: c.photo, maxPixel: 220, placeholder: String(c.name.prefix(1)))
                                .frame(width: 72, height: 72).clipShape(Circle())
                                .overlay(Circle().stroke(Color.white.opacity(0.12), lineWidth: 0.8))
                            Text(c.name).font(.system(size: 11, weight: .semibold)).foregroundStyle(.white).lineLimit(2)
                                .multilineTextAlignment(.center)
                            Text(c.character).font(.system(size: 10)).foregroundStyle(PTV.text3).lineLimit(1)
                        }
                        .frame(width: 84)
                    }
                }
                .padding(.horizontal, 16)
            }
        }
    }

    @ViewBuilder
    private var episodesSection: some View {
        let seasons = series.seasons.keys.sorted()
        VStack(alignment: .leading, spacing: 12) {
            Text("Episodios").font(.system(size: 20, weight: .bold)).foregroundStyle(.white).padding(.horizontal, 16)
            if loadingSeries {
                ProgressView().tint(.white).frame(maxWidth: .infinity).padding(30)
            } else if seasons.isEmpty {
                EmptyState(icon: "tv", title: "Sin episodios", message: "Esta serie aún no tiene capítulos disponibles.")
            } else {
                if seasons.count > 1 {
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 8) {
                            ForEach(seasons, id: \.self) { s in Chip(title: "Temporada \(s)", selected: s == season) { season = s } }
                        }
                        .padding(.horizontal, 16)
                    }
                }
                LazyVStack(spacing: 12) {
                    ForEach(series.seasons[season] ?? []) { ep in episodeRow(ep) }
                }
                .padding(.horizontal, 16)
            }
        }
    }

    private func episodeRow(_ ep: Episode) -> some View {
        let w = watch
        let isCurrent = w?.episodeId == ep.id
        return Button {
            Device.haptic()
            Task { await app.playSeries(item, info: series, episodeId: ep.id) }
        } label: {
            HStack(alignment: .top, spacing: 12) {
                ZStack {
                    RemoteImage(url: ep.image.isEmpty ? backdrop : ep.image, maxPixel: 400)
                    Image(systemName: "play.fill").font(.system(size: 14, weight: .bold)).foregroundStyle(.white)
                        .frame(width: 32, height: 32).glass(Circle())
                    if isCurrent, let w = w, w.duration > 0 {
                        VStack {
                            Spacer()
                            GeometryReader { g in
                                ZStack(alignment: .leading) {
                                    Rectangle().fill(Color.white.opacity(0.25))
                                    Rectangle().fill(PTV.red).frame(width: g.size.width * w.progress)
                                }
                            }
                            .frame(height: 3)
                        }
                    }
                }
                .frame(width: 136, height: 77)
                .clipShape(RoundedRectangle(cornerRadius: 10, style: .continuous))
                VStack(alignment: .leading, spacing: 4) {
                    Text("\(ep.number). \(ep.title)").font(.system(size: 14, weight: .bold)).foregroundStyle(.white).lineLimit(2)
                        .multilineTextAlignment(.leading)
                    if !ep.duration.isEmpty { Text(ep.duration).font(.system(size: 12)).foregroundStyle(PTV.text3) }
                    if !ep.plot.isEmpty {
                        Text(ep.plot).font(.system(size: 12)).foregroundStyle(PTV.text2).lineLimit(2).multilineTextAlignment(.leading)
                    }
                }
                Spacer(minLength: 0)
            }
        }
        .buttonStyle(PressScale(scale: 0.98))
    }

    private var similar: some View {
        let cat = item.categoryId, own = item.contentId
        let list: [PosterItem]
        if item.kind == .movie {
            list = Array(catalog.vods.lazy.filter { $0.categoryId == cat && $0.id != own }.prefix(18).map { PosterItem($0) })
        } else {
            list = Array(catalog.series.lazy.filter { $0.categoryId == cat && $0.id != own }.prefix(18).map { PosterItem($0) })
        }
        return Group {
            if !list.isEmpty {
                PosterRow(title: "Más como esto", items: list) { p in router.open(.detail(p)) }
            }
        }
    }

    private func load() async {
        let c = session.creds
        let title = item.title
        let ser = isSeries
        async let t = Tmdb.info(title: title, series: ser)
        if ser {
            let s = await Xtream.seriesInfo(c, item.contentId)
            series = s
            loadingSeries = false
            if let w = watch, let ep = s.seasons.values.flatMap({ $0 }).first(where: { $0.id == w.episodeId }) { season = ep.season }
            else { season = s.seasons.keys.sorted().first ?? 1 }
        } else {
            vod = await Xtream.vodInfo(c, item.contentId)
        }
        let info = await t
        tmdb = info
        if let i = info {
            logo = await Tmdb.logo(id: i.id, series: ser)
            trailerKey = await Tmdb.trailerKey(id: i.id, series: ser)
        }
    }

    private func play(fromStart: Bool) {
        if isSeries {
            Task { await app.playSeries(item, info: series, episodeId: nil, fromStart: fromStart) }
        } else {
            app.playMovie(item, fromStart: fromStart, ext: vod.ext.nilIfEmpty)
        }
    }

    private func openTrailer() {
        let key = trailerKey ?? (isSeries ? series.trailer : vod.trailer)
        guard !key.isEmpty else { return }
        let url = key.hasPrefix("http") ? key : "https://www.youtube.com/watch?v=\(key)"
        if let u = URL(string: url) { UIApplication.shared.open(u) }
    }
}

struct MyListView: View {
    @EnvironmentObject var app: AppModel
    @EnvironmentObject var catalog: CatalogStore
    @EnvironmentObject var library: LibraryStore
    private let columns = [GridItem(.adaptive(minimum: 106, maximum: 140), spacing: 10)]

    var body: some View {
        let _ = library.version
        let items = library.favorites(.movie).compactMap { catalog.poster(.movie, $0) } + library.favorites(.series).compactMap { catalog.poster(.series, $0) }
        ScrollView {
            if items.isEmpty {
                EmptyState(icon: "plus.rectangle.on.rectangle", title: "Tu lista está vacía", message: "Toca “Mi lista” en cualquier película o serie para guardarla aquí.")
                    .padding(.top, 80)
            } else {
                LazyVGrid(columns: columns, spacing: 14) {
                    ForEach(items) { p in
                        NavigationLink(value: Route.detail(p)) { GridPoster(item: p) }.buttonStyle(PressScale(scale: 0.96))
                    }
                }
                .padding(14)
            }
            Color.clear.frame(height: 100)
        }
        .background(PTV.bg.ignoresSafeArea())
        .navigationTitle("Mi lista")
    }
}
