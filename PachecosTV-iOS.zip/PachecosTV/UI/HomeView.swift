import SwiftUI

private struct ScrollOffsetKey: PreferenceKey {
    static var defaultValue: CGFloat = 0
    static func reduce(value: inout CGFloat, nextValue: () -> CGFloat) { value = nextValue() }
}

struct HomeView: View {
    @EnvironmentObject var app: AppModel
    @EnvironmentObject var catalog: CatalogStore
    @EnvironmentObject var library: LibraryStore
    @EnvironmentObject var router: Router
    @EnvironmentObject var profiles: ProfileManager

    @State private var heroIndex = 0
    @State private var tint = Color(red: 0.35, green: 0.04, blue: 0.08)
    @State private var offset: CGFloat = 0
    @State private var upcoming: [TmdbUpcoming] = []
    @State private var matches: [Match] = []
    @State private var refreshing = false

    private let rotate = Timer.publish(every: 7, on: .main, in: .common).autoconnect()

    var body: some View {
        GeometryReader { geo in
            ZStack(alignment: .top) {
                LinearGradient(colors: [tint, tint.opacity(0.35), PTV.bg], startPoint: .top, endPoint: .center)
                    .frame(height: geo.size.height * 0.95)
                    .ignoresSafeArea()
                    .animation(.easeInOut(duration: 0.8), value: tint)
                PTV.bg.opacity(min(1, max(0, -offset / 500))).ignoresSafeArea()

                ScrollView(showsIndicators: false) {
                    VStack(spacing: 26) {
                        GeometryReader { g in
                            Color.clear.preference(key: ScrollOffsetKey.self, value: g.frame(in: .named("home")).minY)
                        }
                        .frame(height: 0)
                        if catalog.home.hero.isEmpty {
                            RoundedRectangle(cornerRadius: 26, style: .continuous).fill(Color.white.opacity(0.06))
                                .frame(height: heroHeight(geo.size)).padding(.horizontal, 14).shimmer()
                            LoadingRow()
                            LoadingRow()
                        } else {
                            hero(geo.size)
                        }
                        rows
                        Color.clear.frame(height: 100)
                    }
                    .padding(.top, 66)
                }
                .coordinateSpace(name: "home")
                .onPreferenceChange(ScrollOffsetKey.self) { offset = $0 }
                .refreshable { await refresh() }

                topBar
            }
        }
        .toolbar(.hidden, for: .navigationBar)
        .task {
            if upcoming.isEmpty, !catalog.kids { upcoming = await Tmdb.upcoming() }
            if matches.isEmpty, !catalog.kids { matches = await Sports.matches(day: Date()).filter { $0.live || $0.start.timeIntervalSinceNow < 5400 && !$0.finished } }
        }
        .onReceive(rotate) { _ in
            guard !catalog.home.hero.isEmpty, router.tab == .home, router.homePath.isEmpty, router.player == nil else { return }
            withAnimation(.spring(response: 0.6, dampingFraction: 0.9)) { heroIndex = (heroIndex + 1) % catalog.home.hero.count }
        }
        .onChange(of: heroIndex) { _, _ in updateTint() }
        .onChange(of: catalog.home.hero.count) { _, _ in heroIndex = 0; updateTint() }
        .onAppear { updateTint() }
    }

    private func heroHeight(_ s: CGSize) -> CGFloat { max(300, min((s.width - 28) * 1.3, s.height * 0.68)) }

    private func updateTint() {
        guard catalog.home.hero.indices.contains(heroIndex) else { return }
        let url = catalog.home.hero[heroIndex].image
        Task {
            if let c = await DominantColor.of(url) { tint = Color(uiColor: c) }
        }
    }

    private func refresh() async {
        let ok = await catalog.refreshNow()
        router.show(ok ? "Lista actualizada" : "No se pudo actualizar. Revisa tu conexión.")
        await library.pull()
    }

    // MARK: Barra superior (logo, Películas, Series, Deportes, Más)

    private var topBar: some View {
        let solid = min(1, max(0, -offset / 160))
        return HStack(spacing: 4) {
            Image("LogoMark").resizable().scaledToFit().frame(width: 34, height: 34)
                .padding(.trailing, 6)
            navPill("Películas") { router.open(.catalog(.movie)) }
            navPill("Series") { router.open(.catalog(.series)) }
            if !catalog.kids { navPill("Deportes") { router.open(.events) } }
            navPill("Más") { router.moreMenu = true }
            Spacer(minLength: 0)
        }
        .padding(.horizontal, 14)
        .frame(height: 56)
        .background {
            ZStack {
                Rectangle().fill(.ultraThinMaterial).opacity(solid)
                LinearGradient(colors: [Color.black.opacity(0.55 + 0.35 * solid), .clear], startPoint: .top, endPoint: .bottom)
            }
            .ignoresSafeArea(edges: .top)
        }
    }

    private func navPill(_ t: String, action: @escaping () -> Void) -> some View {
        Button { Device.haptic(); action() } label: {
            Text(t).font(.system(size: 14, weight: .semibold)).foregroundStyle(.white)
                .padding(.horizontal, 12).frame(height: 34)
                .overlay(Capsule().stroke(Color.white.opacity(0.28), lineWidth: 0.8))
        }
        .buttonStyle(PressScale())
    }

    // MARK: Banner

    private func hero(_ size: CGSize) -> some View {
        let items = catalog.home.hero
        let h = heroHeight(size)
        return VStack(spacing: 12) {
            TabView(selection: $heroIndex) {
                ForEach(Array(items.enumerated()), id: \.element.id) { i, item in
                    HeroCard(item: item, inList: library.isFavorite(item.kind, item.contentId), onPlay: { playHero(item) },
                             onList: { toggleList(item) }, onInfo: { app.open(item) })
                        .padding(.horizontal, 14)
                        .tag(i)
                }
            }
            .tabViewStyle(.page(indexDisplayMode: .never))
            .frame(height: h)
            HStack(spacing: 6) {
                ForEach(0..<items.count, id: \.self) { i in
                    Capsule().fill(i == heroIndex ? Color.white : Color.white.opacity(0.3))
                        .frame(width: i == heroIndex ? 18 : 6, height: 6)
                }
            }
            .animation(.spring(response: 0.35, dampingFraction: 0.8), value: heroIndex)
        }
    }

    private func playHero(_ item: PosterItem) {
        if item.kind == .movie { app.playMovie(item) } else { Task { await app.playSeries(item) } }
    }

    private func toggleList(_ item: PosterItem) {
        let added = library.toggleFavorite(item.kind, item.contentId)
        Device.success()
        router.show(added ? "Agregado a Mi lista" : "Quitado de Mi lista")
    }

    // MARK: Filas

    private var continueItems: [ContinueEntry] {
        _ = library.version
        var out: [ContinueEntry] = []
        let all = (library.history(.movie) + library.history(.series)).sorted { $0.date > $1.date }
        for w in all {
            let kind: Kind = w.type == "series" ? .series : .movie
            guard let p = catalog.poster(kind, w.key) else { continue }
            if kind == .movie && !w.canResume { continue }
            out.append(ContinueEntry(poster: p, watch: w))
            if out.count >= 20 { break }
        }
        return out
    }

    private var myList: [PosterItem] {
        _ = library.version
        var out: [PosterItem] = []
        for id in library.favorites(.movie) { if let p = catalog.poster(.movie, id) { out.append(p) } }
        for id in library.favorites(.series) { if let p = catalog.poster(.series, id) { out.append(p) } }
        return Array(out.prefix(40))
    }

    @ViewBuilder
    private var rows: some View {
        let cont = continueItems
        if !cont.isEmpty {
            VStack(alignment: .leading, spacing: 10) {
                SectionTitle(title: "Continuar viendo")
                ScrollView(.horizontal, showsIndicators: false) {
                    LazyHStack(spacing: 10) {
                        ForEach(cont) { pair in
                            Button { resume(pair.poster, pair.watch) } label: {
                                PosterCard(item: pair.poster, progress: pair.watch.progress,
                                           caption: pair.watch.season > 0 ? "T\(pair.watch.season) E\(pair.watch.episode)" : pair.watch.remainingText)
                            }
                            .buttonStyle(PressScale(scale: 0.96))
                            .contextMenu {
                                Button { app.open(pair.poster) } label: { Label("Ver detalles", systemImage: "info.circle") }
                                Button(role: .destructive) {
                                    library.remove(pair.poster.kind, pair.poster.contentId)
                                } label: { Label("Quitar de Continuar viendo", systemImage: "xmark.circle") }
                            }
                        }
                    }
                    .padding(.horizontal, 16)
                }
            }
        }
        let list = myList
        if !list.isEmpty {
            PosterRow(title: "Mi lista", items: list, onSeeAll: { router.open(.myList) }) { app.open($0) }
        }
        if catalog.home.top10.count >= 5 {
            PosterRow(title: "Top 10 de hoy", items: catalog.home.top10, style: .top10) { app.open($0) }
        }
        if !matches.isEmpty {
            VStack(alignment: .leading, spacing: 10) {
                SectionTitle(title: "Eventos en vivo") { router.open(.events) }
                ScrollView(.horizontal, showsIndicators: false) {
                    LazyHStack(spacing: 10) {
                        ForEach(matches.prefix(15)) { m in
                            Button { router.open(.events) } label: { MatchMiniCard(match: m) }
                                .buttonStyle(PressScale())
                        }
                    }
                    .padding(.horizontal, 16)
                }
            }
        }
        if !upcoming.isEmpty {
            VStack(alignment: .leading, spacing: 10) {
                SectionTitle(title: "Próximamente")
                ScrollView(.horizontal, showsIndicators: false) {
                    LazyHStack(spacing: 10) {
                        ForEach(upcoming.prefix(20)) { u in
                            Button { router.upcoming = u } label: {
                                VStack(alignment: .leading, spacing: 6) {
                                    RemoteImage(url: u.poster, maxPixel: 420).frame(width: 116, height: 174)
                                        .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
                                        .overlay(alignment: .topLeading) {
                                            Text(Tmdb.shortDate(u.date).uppercased()).font(.system(size: 10, weight: .black))
                                                .foregroundStyle(.white).padding(.horizontal, 7).padding(.vertical, 4)
                                                .background(PTV.red, in: Capsule()).padding(6)
                                        }
                                    Text(u.title).font(.system(size: 11, weight: .medium)).foregroundStyle(PTV.text2)
                                        .lineLimit(1).frame(width: 116, alignment: .leading)
                                }
                            }
                            .buttonStyle(PressScale(scale: 0.96))
                        }
                    }
                    .padding(.horizontal, 16)
                }
            }
        }
        if !catalog.home.newMovies.isEmpty {
            PosterRow(title: "Películas nuevas", items: catalog.home.newMovies, style: .wide, onSeeAll: { router.open(.catalog(.movie)) }) { app.open($0) }
        }
        if !catalog.home.newSeries.isEmpty {
            PosterRow(title: "Series nuevas", items: catalog.home.newSeries, onSeeAll: { router.open(.catalog(.series)) }) { app.open($0) }
        }
        ForEach(catalog.home.genreRows) { r in
            PosterRow(title: r.title, items: r.items, style: r.style) { app.open($0) }
        }
        if catalog.ready && catalog.home.hero.isEmpty && catalog.vods.isEmpty && catalog.series.isEmpty {
            EmptyState(icon: "film.stack", title: "Aún no hay contenido", message: "Desliza hacia abajo para actualizar tus listas.")
        }
    }

    private func resume(_ p: PosterItem, _ w: WatchItem) {
        Device.haptic()
        if p.kind == .movie { app.playMovie(p) }
        else { Task { await app.playSeries(p, episodeId: w.episodeId.isEmpty ? nil : w.episodeId) } }
    }
}

struct ContinueEntry: Identifiable {
    let poster: PosterItem
    let watch: WatchItem
    var id: String { poster.id }
}

struct HeroCard: View {
    let item: PosterItem
    let inList: Bool
    let onPlay: () -> Void
    let onList: () -> Void
    let onInfo: () -> Void

    var body: some View {
        ZStack(alignment: .bottom) {
            RemoteImage(url: item.image, maxPixel: 1100, placeholder: item.title)
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .clipped()
                .onTapGesture { onInfo() }
            LinearGradient(colors: [.clear, .clear, .black.opacity(0.55), .black.opacity(0.95)], startPoint: .top, endPoint: .bottom)
                .allowsHitTesting(false)
            VStack(spacing: 10) {
                HStack(spacing: 6) {
                    Image("LogoMark").resizable().scaledToFit().frame(width: 16, height: 16)
                    Text(item.kind == .series ? "SERIE" : "PELÍCULA").font(.system(size: 11, weight: .black)).tracking(2)
                        .foregroundStyle(.white.opacity(0.9))
                }
                Text(item.title).font(.system(size: 30, weight: .heavy)).foregroundStyle(.white)
                    .multilineTextAlignment(.center).lineLimit(2).minimumScaleFactor(0.7)
                    .shadow(color: .black.opacity(0.5), radius: 8)
                HStack(spacing: 8) {
                    if !item.yearText.isEmpty { Text(item.yearText) }
                    if !item.ratingText.isEmpty { Text("★ \(item.ratingText)").foregroundStyle(PTV.gold) }
                    if !item.genre.isEmpty { Text(item.genre.components(separatedBy: CharacterSet(charactersIn: ",/")).prefix(2).joined(separator: " · ")).lineLimit(1) }
                }
                .font(.system(size: 13, weight: .semibold)).foregroundStyle(.white.opacity(0.8))
                HStack(spacing: 10) {
                    Button { Device.haptic(.medium); onPlay() } label: {
                        Label("Ver ahora", systemImage: "play.fill").font(.system(size: 16, weight: .bold))
                            .foregroundStyle(.black).frame(maxWidth: .infinity).frame(height: 48)
                            .background(Color.white, in: RoundedRectangle(cornerRadius: 12, style: .continuous))
                    }
                    .buttonStyle(PressScale())
                    Button { Device.haptic(); onList() } label: {
                        Label("Mi lista", systemImage: inList ? "checkmark" : "plus").font(.system(size: 16, weight: .bold))
                            .foregroundStyle(.white).frame(maxWidth: .infinity).frame(height: 48)
                            .glass(RoundedRectangle(cornerRadius: 12, style: .continuous), interactive: true)
                            .contentTransition(.symbolEffect(.replace))
                    }
                    .buttonStyle(PressScale())
                }
            }
            .padding(18)
        }
        .clipShape(RoundedRectangle(cornerRadius: 26, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 26, style: .continuous).stroke(Color.white.opacity(0.12), lineWidth: 0.8))
        .shadow(color: .black.opacity(0.55), radius: 24, y: 14)
    }
}

struct MatchMiniCard: View {
    let match: Match
    var body: some View {
        VStack(spacing: 8) {
            HStack {
                Text(match.league.name).font(.system(size: 10, weight: .bold)).foregroundStyle(PTV.text2).lineLimit(1)
                Spacer()
                if match.live {
                    HStack(spacing: 4) {
                        Circle().fill(PTV.red).frame(width: 6, height: 6)
                        Text(match.clock.isEmpty ? "EN VIVO" : match.clock).font(.system(size: 10, weight: .heavy)).foregroundStyle(PTV.red)
                    }
                } else {
                    Text(Txt.hour(match.start)).font(.system(size: 10, weight: .bold)).foregroundStyle(.white)
                }
            }
            HStack(spacing: 10) {
                teamColumn(match.home)
                Text(match.live || match.finished ? "\(match.home.score) - \(match.away.score)" : "vs")
                    .font(.system(size: match.live ? 18 : 14, weight: .heavy, design: .rounded)).foregroundStyle(.white).monospacedDigit()
                teamColumn(match.away)
            }
        }
        .padding(12)
        .frame(width: 210, height: 112)
        .glass(RoundedRectangle(cornerRadius: 18, style: .continuous))
    }

    private func teamColumn(_ t: Team) -> some View {
        VStack(spacing: 5) {
            RemoteImage(url: t.logo, maxPixel: 120, contentMode: .fit).frame(width: 34, height: 34)
            Text(t.short).font(.system(size: 11, weight: .semibold)).foregroundStyle(.white).lineLimit(1)
        }
        .frame(maxWidth: .infinity)
    }
}

struct UpcomingSheet: View {
    let item: TmdbUpcoming
    @State private var trailer: String?
    @State private var loading = true

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                ZStack(alignment: .bottomLeading) {
                    RemoteImage(url: item.backdrop.isEmpty ? item.poster : item.backdrop, maxPixel: 1200)
                        .frame(height: 240).clipped()
                    LinearGradient(colors: [.clear, .black.opacity(0.9)], startPoint: .center, endPoint: .bottom)
                    Text(item.title).font(.system(size: 26, weight: .heavy)).foregroundStyle(.white).padding(18)
                }
                .frame(height: 240)
                HStack(spacing: 8) {
                    Image(systemName: "calendar")
                    Text("Estreno: \(Tmdb.shortDate(item.date))")
                }
                .font(.system(size: 15, weight: .bold)).foregroundStyle(PTV.red).padding(.horizontal, 18)
                Text(item.overview.isEmpty ? "Muy pronto en Pacheco's TV." : item.overview)
                    .font(.system(size: 15)).foregroundStyle(PTV.text2).padding(.horizontal, 18)
                if let t = trailer {
                    PrimaryButton(title: "VER TRÁILER", icon: "play.rectangle.fill") {
                        if let u = URL(string: "https://www.youtube.com/watch?v=\(t)") { UIApplication.shared.open(u) }
                    }
                    .padding(.horizontal, 18)
                } else if loading {
                    ProgressView().tint(.white).frame(maxWidth: .infinity)
                }
            }
            .padding(.bottom, 30)
        }
        .ignoresSafeArea(edges: .top)
        .task {
            trailer = await Tmdb.trailerKey(id: item.id, series: false)
            loading = false
        }
    }
}
