import SwiftUI

struct SearchView: View {
    @EnvironmentObject var app: AppModel
    @EnvironmentObject var catalog: CatalogStore
    @EnvironmentObject var router: Router
    @State private var query = ""
    @State private var channels: [Channel] = []
    @State private var movies: [PosterItem] = []
    @State private var series: [PosterItem] = []
    @State private var searching = false
    @FocusState private var focused: Bool

    private let columns = [GridItem(.adaptive(minimum: 106, maximum: 140), spacing: 10)]

    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(alignment: .leading, spacing: 20) {
                HStack(spacing: 10) {
                    Image(systemName: "magnifyingglass").font(.system(size: 17, weight: .semibold)).foregroundStyle(PTV.text2)
                    TextField("", text: $query, prompt: Text("Películas, series o canales").foregroundColor(PTV.text3))
                        .focused($focused)
                        .textInputAutocapitalization(.never).autocorrectionDisabled()
                        .font(.system(size: 17, weight: .medium)).foregroundStyle(.white)
                        .submitLabel(.search)
                    if !query.isEmpty {
                        Button { query = "" } label: { Image(systemName: "xmark.circle.fill").foregroundStyle(PTV.text3) }
                    }
                }
                .padding(.horizontal, 16).frame(height: 52)
                .glass(RoundedRectangle(cornerRadius: 18, style: .continuous))
                .padding(.horizontal, 16)

                if query.trimmed.isEmpty {
                    popular
                } else if searching && channels.isEmpty && movies.isEmpty && series.isEmpty {
                    ProgressView().tint(.white).frame(maxWidth: .infinity).padding(40)
                } else if channels.isEmpty && movies.isEmpty && series.isEmpty {
                    EmptyState(icon: "magnifyingglass", title: "Sin resultados", message: "No encontramos “\(query)”. Prueba con otro nombre.")
                } else {
                    if !channels.isEmpty {
                        VStack(alignment: .leading, spacing: 10) {
                            SectionTitle(title: "Canales")
                            ScrollView(.horizontal, showsIndicators: false) {
                                LazyHStack(spacing: 12) {
                                    ForEach(channels) { ch in
                                        Button { Device.haptic(); app.playChannel(ch, in: channels) } label: {
                                            VStack(spacing: 6) {
                                                ChannelLogo(url: ch.icon, name: ch.name, size: 78)
                                                Text(ch.name).font(.system(size: 11, weight: .semibold)).foregroundStyle(PTV.text2)
                                                    .lineLimit(2).multilineTextAlignment(.center).frame(width: 84)
                                            }
                                        }
                                        .buttonStyle(PressScale())
                                    }
                                }
                                .padding(.horizontal, 16)
                            }
                        }
                    }
                    if !movies.isEmpty { grid("Películas", movies) }
                    if !series.isEmpty { grid("Series", series) }
                }
                Color.clear.frame(height: 100)
            }
            .padding(.top, 10)
        }
        .scrollDismissesKeyboard(.immediately)
        .background(PTV.bg.ignoresSafeArea())
        .navigationTitle("Buscar")
        .navigationBarTitleDisplayMode(.large)
        .task(id: query) { await search() }
    }

    private var popular: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Búsquedas populares").font(.system(size: 20, weight: .bold)).foregroundStyle(.white).padding(.horizontal, 16)
            LazyVStack(spacing: 12) {
                ForEach(catalog.home.top10) { p in
                    NavigationLink(value: Route.detail(p)) {
                        HStack(spacing: 12) {
                            RemoteImage(url: p.backdrop.isEmpty ? p.image : p.backdrop, maxPixel: 500)
                                .frame(width: 150, height: 84).clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
                            VStack(alignment: .leading, spacing: 4) {
                                Text(p.title).font(.system(size: 15, weight: .bold)).foregroundStyle(.white).lineLimit(2)
                                    .multilineTextAlignment(.leading)
                                Text(p.genre.isEmpty ? (p.kind == .series ? "Serie" : "Película") : p.genre)
                                    .font(.system(size: 12)).foregroundStyle(PTV.text3).lineLimit(1)
                            }
                            Spacer()
                            Image(systemName: "play.circle").font(.system(size: 26, weight: .light)).foregroundStyle(.white)
                        }
                    }
                    .buttonStyle(PressScale(scale: 0.98))
                }
            }
            .padding(.horizontal, 16)
        }
    }

    private func grid(_ title: String, _ list: [PosterItem]) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            SectionTitle(title: title)
            LazyVGrid(columns: columns, spacing: 14) {
                ForEach(list) { p in
                    NavigationLink(value: Route.detail(p)) { GridPoster(item: p) }.buttonStyle(PressScale(scale: 0.96))
                }
            }
            .padding(.horizontal, 14)
        }
    }

    private func search() async {
        let q = Txt.norm(query.trimmed)
        guard q.count >= 2 else { channels = []; movies = []; series = []; return }
        searching = true
        try? await Task.sleep(nanoseconds: 250_000_000)
        if Task.isCancelled { return }
        let live = catalog.live, vods = catalog.vods, sers = catalog.series
        let names = catalog.catNames
        let kids = catalog.kids
        let result = await Task.detached(priority: .userInitiated) { () -> ([Channel], [PosterItem], [PosterItem]) in
            let words = q.split(separator: " ").map { String($0) }
            func match(_ name: String) -> Bool {
                let n = Txt.norm(name)
                return words.allSatisfy { n.contains($0) }
            }
            func adult(_ k: String, _ cat: String) -> Bool { !kids && KidsFilter.esAdulto(names[k + ":" + cat] ?? "") }
            let ch = Array(live.lazy.filter { match($0.name) && !adult("tv", $0.categoryId) }.prefix(30))
            let mv = Array(vods.lazy.filter { match($0.name) && !adult("movie", $0.categoryId) }.prefix(60).map { PosterItem($0) })
            let sr = Array(sers.lazy.filter { match($0.name) && !adult("series", $0.categoryId) }.prefix(60).map { PosterItem($0) })
            return (ch, mv, sr)
        }.value
        if Task.isCancelled { return }
        channels = result.0
        movies = result.1
        series = result.2
        searching = false
    }
}
