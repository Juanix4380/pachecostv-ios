import SwiftUI
import UIKit
import ImageIO

enum PTV {
    static let red = Color(red: 0xE3 / 255, green: 0x1B / 255, blue: 0x23 / 255)
    static let redDark = Color(red: 0.55, green: 0.03, blue: 0.07)
    static let bg = Color(red: 0.027, green: 0.027, blue: 0.035)
    static let surface = Color(white: 0.10)
    static let surface2 = Color(white: 0.15)
    static let text2 = Color.white.opacity(0.66)
    static let text3 = Color.white.opacity(0.42)
    static let gold = Color(red: 1, green: 0.80, blue: 0.30)
    static let green = Color(red: 34 / 255, green: 160 / 255, blue: 72 / 255)

    static let redGradient = LinearGradient(colors: [Color(red: 0.96, green: 0.16, blue: 0.20), Color(red: 0.72, green: 0.04, blue: 0.10)],
                                            startPoint: .topLeading, endPoint: .bottomTrailing)
}

// MARK: - Liquid Glass (iOS 26) con respaldo de material

struct GlassModifier<S: Shape>: ViewModifier {
    let shape: S
    var interactive: Bool = false
    var tint: Color? = nil

    func body(content: Content) -> some View {
        #if compiler(>=6.2)
        if #available(iOS 26.0, *) {
            return AnyView(content.glassEffect(glassStyle, in: shape))
        }
        #endif
        return AnyView(
            content
                .background(.ultraThinMaterial, in: shape)
                .background((tint ?? .clear).opacity(0.25), in: shape)
                .overlay(shape.stroke(Color.white.opacity(0.14), lineWidth: 0.6))
        )
    }

    #if compiler(>=6.2)
    @available(iOS 26.0, *)
    private var glassStyle: Glass {
        var g = Glass.regular
        if let t = tint { g = g.tint(t.opacity(0.35)) }
        if interactive { g = g.interactive() }
        return g
    }
    #endif
}

extension View {
    func glass<S: Shape>(_ shape: S, interactive: Bool = false, tint: Color? = nil) -> some View {
        modifier(GlassModifier(shape: shape, interactive: interactive, tint: tint))
    }

    func glassCapsule(interactive: Bool = true, tint: Color? = nil) -> some View {
        glass(Capsule(), interactive: interactive, tint: tint)
    }

    func cardShadow() -> some View { shadow(color: .black.opacity(0.45), radius: 14, x: 0, y: 8) }

    @ViewBuilder
    func `if`<V: View>(_ condition: Bool, transform: (Self) -> V) -> some View {
        if condition { transform(self) } else { self }
    }
}

// MARK: - Botones

struct PressScale: ButtonStyle {
    var scale: CGFloat = 0.95
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .scaleEffect(configuration.isPressed ? scale : 1)
            .opacity(configuration.isPressed ? 0.88 : 1)
            .animation(.spring(response: 0.25, dampingFraction: 0.7), value: configuration.isPressed)
    }
}

struct PrimaryButton: View {
    let title: String
    var icon: String? = nil
    var loading = false
    let action: () -> Void

    var body: some View {
        Button(action: { Device.haptic(.medium); action() }) {
            HStack(spacing: 10) {
                if loading { ProgressView().tint(.white) }
                else if let i = icon { Image(systemName: i).font(.system(size: 17, weight: .bold)) }
                Text(title).font(.system(size: 16, weight: .heavy)).tracking(0.4)
            }
            .foregroundStyle(.white)
            .frame(maxWidth: .infinity)
            .frame(height: 54)
            .background(PTV.redGradient, in: RoundedRectangle(cornerRadius: 16, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 16, style: .continuous).stroke(Color.white.opacity(0.18), lineWidth: 0.8))
            .shadow(color: PTV.red.opacity(0.45), radius: 18, x: 0, y: 8)
        }
        .buttonStyle(PressScale())
    }
}

struct GlassButton: View {
    let title: String
    var icon: String? = nil
    var active = false
    let action: () -> Void

    var body: some View {
        Button(action: { Device.haptic(); action() }) {
            HStack(spacing: 8) {
                if let i = icon { Image(systemName: i).font(.system(size: 15, weight: .semibold)) }
                if !title.isEmpty { Text(title).font(.system(size: 14, weight: .semibold)) }
            }
            .foregroundStyle(active ? PTV.red : .white)
            .padding(.horizontal, title.isEmpty ? 12 : 16)
            .frame(height: 44)
            .glassCapsule()
        }
        .buttonStyle(PressScale())
    }
}

struct CircleIconButton: View {
    let icon: String
    var size: CGFloat = 44
    var action: () -> Void

    var body: some View {
        Button(action: { Device.haptic(); action() }) {
            Image(systemName: icon)
                .font(.system(size: size * 0.38, weight: .semibold))
                .foregroundStyle(.white)
                .frame(width: size, height: size)
                .glass(Circle(), interactive: true)
        }
        .buttonStyle(PressScale(scale: 0.9))
    }
}

struct Chip: View {
    let title: String
    var icon: String? = nil
    let selected: Bool
    let action: () -> Void

    var body: some View {
        Button(action: { Device.haptic(); action() }) {
            HStack(spacing: 6) {
                if let i = icon { Image(systemName: i).font(.system(size: 12, weight: .bold)) }
                Text(title).font(.system(size: 14, weight: selected ? .bold : .medium)).lineLimit(1)
            }
            .foregroundStyle(selected ? .black : .white)
            .padding(.horizontal, 14)
            .frame(height: 34)
            .background {
                if selected { Capsule().fill(Color.white) } else { Capsule().fill(Color.white.opacity(0.10)) }
            }
            .overlay(Capsule().stroke(Color.white.opacity(selected ? 0 : 0.12), lineWidth: 0.6))
        }
        .buttonStyle(PressScale())
    }
}

struct SectionTitle: View {
    let title: String
    var action: (() -> Void)? = nil

    var body: some View {
        HStack(alignment: .firstTextBaseline) {
            Text(title).font(.system(size: 20, weight: .bold)).foregroundStyle(.white)
            Spacer()
            if let a = action {
                Button(action: a) {
                    HStack(spacing: 3) {
                        Text("Ver todo").font(.system(size: 13, weight: .semibold))
                        Image(systemName: "chevron.right").font(.system(size: 11, weight: .bold))
                    }
                    .foregroundStyle(PTV.text2)
                }
            }
        }
        .padding(.horizontal, 16)
    }
}

struct Shimmer: ViewModifier {
    @State private var phase: CGFloat = -1
    func body(content: Content) -> some View {
        content.overlay(
            GeometryReader { g in
                LinearGradient(colors: [.clear, Color.white.opacity(0.10), .clear], startPoint: .leading, endPoint: .trailing)
                    .frame(width: g.size.width * 0.6)
                    .offset(x: phase * g.size.width * 1.6)
            }
            .clipped()
        )
        .onAppear {
            withAnimation(.linear(duration: 1.3).repeatForever(autoreverses: false)) { phase = 1 }
        }
    }
}

extension View {
    func shimmer() -> some View { modifier(Shimmer()) }
}

// MARK: - Imágenes remotas con caché y reducción

final class ImagePipeline {
    static let shared = ImagePipeline()
    private let cache = NSCache<NSString, UIImage>()
    private let session: URLSession

    init() {
        let c = URLSessionConfiguration.default
        let dir = FileManager.default.urls(for: .cachesDirectory, in: .userDomainMask)[0].appendingPathComponent("imagenes")
        c.urlCache = URLCache(memoryCapacity: 20 << 20, diskCapacity: 500 << 20, directory: dir)
        c.requestCachePolicy = .returnCacheDataElseLoad
        c.timeoutIntervalForRequest = 20
        c.httpMaximumConnectionsPerHost = 6
        session = URLSession(configuration: c)
        cache.totalCostLimit = 140 << 20
    }

    func cached(_ key: String) -> UIImage? { cache.object(forKey: key as NSString) }

    func load(_ url: String, maxPixel: CGFloat) async -> UIImage? {
        let key = "\(url)#\(Int(maxPixel))"
        if let c = cached(key) { return c }
        guard let u = URL(string: url), url.hasPrefix("http") else { return nil }
        guard let result = try? await session.data(from: u) else { return nil }
        let data = result.0
        let img = await Task.detached(priority: .utility) { ImagePipeline.downsample(data, maxPixel) }.value
        if let i = img {
            let cost = Int(i.size.width * i.size.height * i.scale * i.scale * 4)
            cache.setObject(i, forKey: key as NSString, cost: cost)
        }
        return img
    }

    static func downsample(_ data: Data, _ maxPixel: CGFloat) -> UIImage? {
        let opts = [kCGImageSourceShouldCache: false] as CFDictionary
        guard let src = CGImageSourceCreateWithData(data as CFData, opts) else { return UIImage(data: data) }
        let o2 = [kCGImageSourceCreateThumbnailFromImageAlways: true,
                  kCGImageSourceShouldCacheImmediately: true,
                  kCGImageSourceCreateThumbnailWithTransform: true,
                  kCGImageSourceThumbnailMaxPixelSize: maxPixel] as CFDictionary
        guard let cg = CGImageSourceCreateThumbnailAtIndex(src, 0, o2) else { return UIImage(data: data) }
        return UIImage(cgImage: cg)
    }

    func clear() {
        cache.removeAllObjects()
        session.configuration.urlCache?.removeAllCachedResponses()
    }
}

struct RemoteImage: View {
    let url: String
    var maxPixel: CGFloat = 600
    var contentMode: ContentMode = .fill
    var placeholder: String? = nil

    @State private var image: UIImage?

    var body: some View {
        // Color.clear toma el tamaño que le dan; la imagen se ajusta adentro sin agrandar el diseño.
        Color.clear
            .overlay { content }
            .clipped()
            .task(id: url) {
                let i = await ImagePipeline.shared.load(url, maxPixel: maxPixel)
                if !Task.isCancelled { withAnimation(.easeOut(duration: 0.2)) { image = i } }
            }
    }

    @ViewBuilder
    private var content: some View {
        ZStack {
            if let i = image ?? ImagePipeline.shared.cached("\(url)#\(Int(maxPixel))") {
                Image(uiImage: i).resizable().aspectRatio(contentMode: contentMode)
                    .transition(.opacity)
            } else {
                ZStack {
                    LinearGradient(colors: [Color(white: 0.16), Color(white: 0.09)], startPoint: .top, endPoint: .bottom)
                    if let p = placeholder {
                        Text(p).font(.system(size: 13, weight: .semibold)).foregroundStyle(PTV.text3)
                            .multilineTextAlignment(.center).padding(8).lineLimit(3)
                    }
                }
            }
        }
    }
}

// MARK: - Color dominante (fondo del Inicio como en Android)

@MainActor
enum DominantColor {
    private static var cache: [String: UIColor] = [:]

    static func of(_ url: String) async -> UIColor? {
        if let c = cache[url] { return c }
        guard let img = await ImagePipeline.shared.load(url, maxPixel: 600) else { return nil }
        let color = await Task.detached(priority: .utility) { DominantColor.average(img) }.value
        if let c = color { cache[url] = c }
        return color
    }

    nonisolated private static func average(_ image: UIImage) -> UIColor? {
        guard let cg = image.cgImage else { return nil }
        let w = 12, h = 12
        var px = [UInt8](repeating: 0, count: w * h * 4)
        let drawn: Bool = px.withUnsafeMutableBytes { buf -> Bool in
            guard let ctx = CGContext(data: buf.baseAddress, width: w, height: h, bitsPerComponent: 8, bytesPerRow: w * 4,
                                      space: CGColorSpaceCreateDeviceRGB(), bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue) else { return false }
            ctx.draw(cg, in: CGRect(x: 0, y: 0, width: w, height: h))
            return true
        }
        guard drawn else { return nil }
        var r = 0.0, g = 0.0, b = 0.0, total = 0.0
        for i in stride(from: 0, to: px.count, by: 4) {
            let R = Double(px[i]) / 255, G = Double(px[i + 1]) / 255, B = Double(px[i + 2]) / 255
            let mx = max(R, G, B), mn = min(R, G, B)
            let weight = 0.25 + (mx - mn) * 2.5
            r += R * weight; g += G * weight; b += B * weight; total += weight
        }
        guard total > 0 else { return nil }
        var hue: CGFloat = 0, sat: CGFloat = 0, bri: CGFloat = 0, alpha: CGFloat = 0
        UIColor(red: r / total, green: g / total, blue: b / total, alpha: 1).getHue(&hue, saturation: &sat, brightness: &bri, alpha: &alpha)
        return UIColor(hue: hue, saturation: min(1, sat * 1.25 + 0.08), brightness: min(0.62, max(0.30, bri * 0.85)), alpha: 1)
    }
}

// MARK: - Toast

struct ToastView: View {
    let text: String
    var body: some View {
        HStack(spacing: 10) {
            Image("LogoMark").resizable().scaledToFit().frame(width: 20, height: 20)
            Text(text).font(.system(size: 14, weight: .semibold)).foregroundStyle(.white).lineLimit(2)
        }
        .padding(.horizontal, 18).padding(.vertical, 12)
        .glassCapsule(interactive: false)
        .shadow(color: .black.opacity(0.4), radius: 16, y: 6)
    }
}
