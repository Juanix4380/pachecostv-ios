import Foundation
import Network

/// Puente local para películas y series (como hace ExoPlayer en Android):
/// cada vez que el reproductor pide un tramo del video, se vuelve a pedir la dirección
/// ORIGINAL del panel. Así la redirección del balanceador entrega un token nuevo en cada
/// petición, y nunca hay más de una conexión abierta al servidor por video.
final class StreamProxy: NSObject, URLSessionDataDelegate {
    static let shared = StreamProxy()

    private final class Client {
        let conn: NWConnection
        let route: String
        let isHead: Bool
        var task: URLSessionDataTask?
        var pending = 0
        var suspended = false
        var headerSent = false
        var closed = false

        init(conn: NWConnection, route: String, isHead: Bool) {
            self.conn = conn
            self.route = route
            self.isHead = isHead
        }
    }

    private let queue = DispatchQueue(label: "ptv.stream.proxy")
    private let lock = NSLock()
    private var listener: NWListener?
    private var readyPort: UInt16 = 0
    private var portIndex = 0
    private let ports: [UInt16] = [47821, 47833, 47845, 47857, 47869]
    private var routes: [String: URL] = [:]
    private var routeOrder: [String] = []
    private var clients: [Int: Client] = [:]
    private var activeByRoute: [String: Client] = [:]
    private var session: URLSession!

    override init() {
        super.init()
        let cfg = URLSessionConfiguration.default
        cfg.timeoutIntervalForRequest = 30
        cfg.timeoutIntervalForResource = 24 * 3600
        cfg.requestCachePolicy = .reloadIgnoringLocalCacheData
        cfg.urlCache = nil
        cfg.httpMaximumConnectionsPerHost = 4
        let q = OperationQueue()
        q.maxConcurrentOperationCount = 1
        q.underlyingQueue = queue
        session = URLSession(configuration: cfg, delegate: self, delegateQueue: q)
    }

    // MARK: Servidor local

    func start() {
        queue.async { self.startOnQueue() }
    }

    private func startOnQueue() {
        if listener == nil && portIndex >= ports.count { portIndex = 0 }
        guard listener == nil, portIndex < ports.count, let p = NWEndpoint.Port(rawValue: ports[portIndex]) else { return }
        let params = NWParameters.tcp
        params.requiredInterfaceType = .loopback
        params.allowLocalEndpointReuse = true
        let l: NWListener
        do {
            l = try NWListener(using: params, on: p)
        } catch {
            portIndex += 1
            if portIndex < ports.count { startOnQueue() }
            return
        }
        let chosen = ports[portIndex]
        l.newConnectionHandler = { [weak self] c in self?.accept(c) }
        l.stateUpdateHandler = { [weak self] st in
            guard let self = self else { return }
            switch st {
            case .ready:
                self.lock.lock(); self.readyPort = chosen; self.lock.unlock()
            case .failed:
                l.cancel()
                if self.listener === l { self.listener = nil }
                self.lock.lock(); self.readyPort = 0; self.lock.unlock()
                self.portIndex += 1
                if self.portIndex < self.ports.count { self.startOnQueue() }
            case .cancelled:
                if self.listener === l {
                    self.listener = nil
                    self.lock.lock(); self.readyPort = 0; self.lock.unlock()
                }
            default:
                break
            }
        }
        listener = l
        l.start(queue: queue)
    }

    /// Dirección local para el reproductor, o nil si el puente aún no está listo.
    func local(for original: String) -> String? {
        guard let url = URL(string: original), url.scheme?.hasPrefix("http") == true else { return nil }
        lock.lock()
        let port = readyPort
        if port == 0 {
            lock.unlock()
            start()
            return nil
        }
        let token = UUID().uuidString.replacingOccurrences(of: "-", with: "").lowercased()
        routes[token] = url
        routeOrder.append(token)
        while routeOrder.count > 40 { routes.removeValue(forKey: routeOrder.removeFirst()) }
        lock.unlock()
        var ext = url.pathExtension.lowercased()
        if ext.isEmpty { ext = "mp4" }
        return "http://127.0.0.1:\(port)/s/\(token).\(ext)"
    }

    // MARK: Peticiones del reproductor

    private func accept(_ c: NWConnection) {
        c.start(queue: queue)
        readHeader(c, buffer: Data())
    }

    private func readHeader(_ c: NWConnection, buffer: Data) {
        c.receive(minimumIncompleteLength: 1, maximumLength: 16_384) { [weak self] data, _, isComplete, error in
            guard let self = self else { return }
            var buf = buffer
            if let d = data { buf.append(d) }
            if let end = buf.range(of: Data("\r\n\r\n".utf8)) {
                let head = String(decoding: buf[buf.startIndex..<end.lowerBound], as: UTF8.self)
                self.handle(c, head)
            } else if error != nil || isComplete || buf.count > 65_536 {
                c.cancel()
            } else {
                self.readHeader(c, buffer: buf)
            }
        }
    }

    private func handle(_ c: NWConnection, _ head: String) {
        let lines = head.components(separatedBy: "\r\n")
        let first = (lines.first ?? "").split(separator: " ")
        guard first.count >= 2 else { c.cancel(); return }
        let method = String(first[0]).uppercased()
        let path = String(first[1])
        let name = path.split(separator: "/").last.map { String($0) } ?? ""
        let token = name.split(separator: ".").first.map { String($0) } ?? ""
        lock.lock()
        let target = routes[token]
        lock.unlock()
        guard let url = target else {
            sendSimple(c, "HTTP/1.1 404 Not Found\r\nContent-Length: 0\r\nConnection: close\r\n\r\n")
            return
        }
        var range: String?
        for l in lines.dropFirst() {
            let parts = l.split(separator: ":", maxSplits: 1)
            if parts.count == 2, parts[0].trimmingCharacters(in: .whitespaces).lowercased() == "range" {
                range = parts[1].trimmingCharacters(in: .whitespaces)
            }
        }
        // Una sola conexión al servidor por video: la petición nueva reemplaza a la anterior.
        if let old = activeByRoute[token] {
            old.task?.cancel()
            finish(old)
        }
        let client = Client(conn: c, route: token, isHead: method == "HEAD")
        var req = URLRequest(url: url, cachePolicy: .reloadIgnoringLocalCacheData, timeoutInterval: 30)
        req.httpMethod = method == "HEAD" ? "HEAD" : "GET"
        for (k, v) in PlayerHeaders.all { req.setValue(v, forHTTPHeaderField: k) }
        req.setValue("identity", forHTTPHeaderField: "Accept-Encoding")
        req.setValue("keep-alive", forHTTPHeaderField: "Connection")
        if let r = range { req.setValue(r, forHTTPHeaderField: "Range") }
        let task = session.dataTask(with: req)
        client.task = task
        clients[task.taskIdentifier] = client
        activeByRoute[token] = client
        c.stateUpdateHandler = { [weak self, weak client] st in
            guard let self = self, let cl = client else { return }
            switch st {
            case .failed, .cancelled:
                if !cl.closed {
                    cl.closed = true
                    cl.task?.cancel()
                    if self.activeByRoute[cl.route] === cl { self.activeByRoute.removeValue(forKey: cl.route) }
                }
            default:
                break
            }
        }
        task.resume()
    }

    private func sendSimple(_ c: NWConnection, _ text: String) {
        c.send(content: Data(text.utf8), contentContext: .finalMessage, isComplete: true, completion: .contentProcessed { _ in
            c.cancel()
        })
    }

    private func headerData(_ response: URLResponse?) -> Data {
        guard let http = response as? HTTPURLResponse else {
            return Data("HTTP/1.1 502 Bad Gateway\r\nContent-Length: 0\r\nConnection: close\r\n\r\n".utf8)
        }
        let code = http.statusCode
        let reason = code == 206 ? "Partial Content" : (code == 200 ? "OK" : "Status")
        var head = "HTTP/1.1 \(code) \(reason)\r\n"
        for key in ["Content-Type", "Content-Length", "Content-Range", "Accept-Ranges", "Last-Modified", "ETag"] {
            if let v = http.value(forHTTPHeaderField: key) { head += "\(key): \(v)\r\n" }
        }
        if http.value(forHTTPHeaderField: "Accept-Ranges") == nil { head += "Accept-Ranges: bytes\r\n" }
        head += "Connection: close\r\n\r\n"
        return Data(head.utf8)
    }

    private func sendHeaderIfNeeded(_ c: Client, _ task: URLSessionTask) {
        guard !c.headerSent else { return }
        c.headerSent = true
        if let code = (task.response as? HTTPURLResponse)?.statusCode, code != 200 && code != 206 {
            Diag.log("Puente: el servidor respondió \(code)")
        }
        c.conn.send(content: headerData(task.response), completion: .contentProcessed { _ in })
    }

    private func finish(_ c: Client) {
        guard !c.closed else { return }
        c.closed = true
        if activeByRoute[c.route] === c { activeByRoute.removeValue(forKey: c.route) }
        c.conn.send(content: nil, contentContext: .finalMessage, isComplete: true, completion: .contentProcessed { _ in
            c.conn.cancel()
        })
    }

    // MARK: Datos del servidor

    func urlSession(_ session: URLSession, dataTask: URLSessionDataTask, didReceive data: Data) {
        guard let c = clients[dataTask.taskIdentifier], !c.closed else {
            dataTask.cancel()
            return
        }
        if c.isHead {
            sendHeaderIfNeeded(c, dataTask)
            dataTask.cancel()
            return
        }
        sendHeaderIfNeeded(c, dataTask)
        c.pending += data.count
        if c.pending > 6_000_000 && !c.suspended {
            c.suspended = true
            dataTask.suspend()
        }
        let size = data.count
        c.conn.send(content: data, completion: .contentProcessed { [weak c] error in
            guard let cl = c else { return }
            cl.pending -= size
            if error != nil {
                cl.task?.cancel()
                return
            }
            if cl.suspended && cl.pending < 1_500_000 && !cl.closed {
                cl.suspended = false
                cl.task?.resume()
            }
        })
    }

    func urlSession(_ session: URLSession, task: URLSessionTask, didCompleteWithError error: Error?) {
        guard let c = clients.removeValue(forKey: task.taskIdentifier) else { return }
        if let e = error, (e as? URLError)?.code != .cancelled, !c.closed {
            Diag.log("Puente: \(Diag.describe(e))")
        }
        if c.closed { return }
        if !c.headerSent {
            if task.response == nil {
                c.headerSent = true
                c.conn.send(content: Data("HTTP/1.1 502 Bad Gateway\r\nContent-Length: 0\r\nConnection: close\r\n\r\n".utf8),
                            completion: .contentProcessed { _ in })
            } else {
                sendHeaderIfNeeded(c, task)
            }
        }
        finish(c)
    }
}
