import Foundation
import SwiftUI
import AVFoundation
import MediaPlayer

/// Controla la reproducción: elige motor, prueba servidores/formatos y guarda el avance.
@MainActor
final class PlayerModel: ObservableObject {
    @Published private(set) var request: PlayRequest?
    @Published private(set) var isPlaying = false
    @Published private(set) var buffering = true
    @Published private(set) var position: Double = 0
    @Published private(set) var duration: Double = 0
    @Published private(set) var failed: String? = nil
    @Published private(set) var engineKind: EngineKind = .native
    @Published private(set) var surfaceVersion = 0
    @Published private(set) var started = false
    @Published var fill: FillMode = .fit { didSet { engine?.setFill(fill) } }
    @Published var rate: Float = 1 { didSet { engine?.setRate(rate) } }
    @Published var muted = false { didSet { engine?.setMuted(muted) } }

    private(set) var engine: VideoEngine?
    private var candidates: [String] = []
    private var candidateIndex = 0
    private var triedOther = false
    private var wantPlay = true
    private var lastAdvance = Date()
    private var lastProgressPos: Double = -1
    private var lastRecovery = Date.distantPast
    private var recoveries: [Date] = []
    private var retryTask: Task<Void, Never>?
    private var ticker: Timer?
    private var loadWatchdog: Task<Void, Never>?
    private var lastSave = Date.distantPast
    private var creds: Creds?
    weak var library: LibraryStore?
    var onEnded: (() -> Void)?
    var isLive: Bool { request?.isLive ?? false }

    static weak var current: PlayerModel?

    func configure(creds: Creds, library: LibraryStore) {
        self.creds = creds
        self.library = library
    }

    func start(_ r: PlayRequest) {
        saveProgress(force: true)
        request = r
        candidates = r.candidates
        candidateIndex = 0
        triedOther = false
        failed = nil
        started = false
        position = r.startAt
        duration = 0
        PlayerModel.current = self
        RemoteCommands.install()
        if r.kind == .tv, let ch = r.channel {
            library?.addRecentChannel(ch.id, title: ch.name, url: r.candidates.first ?? "")
        }
        playCurrent(startAt: r.startAt)
        updateNowPlaying()
    }

    private func ext(_ url: String) -> String {
        ((URL(string: url)?.path ?? url).lowercased() as NSString).pathExtension
    }

    /// El reproductor del iPhone solo abre HLS y MP4; VLC abre todo.
    private func nativeCan(_ url: String) -> Bool {
        ["m3u8", "mp4", "m4v", "mov", "m4a", "mp3"].contains(ext(url)) || url.lowercased().contains("m3u8")
    }

    /// Automático: VLC para todo (una sola conexión, como Android); HLS con el del iPhone.
    private func preferredKind(_ url: String) -> EngineKind {
        switch AppSettings.player {
        case .native: return nativeCan(url) ? .native : .vlc
        case .vlc: return .vlc
        case .auto: return ext(url) == "m3u8" ? .native : .vlc
        }
    }

    private func makeEngine(_ k: EngineKind) {
        if let e = engine, e.kind == k { return }
        engine?.stop()
        engine?.container.removeFromSuperview()
        let e: VideoEngine = k == .native ? NativeEngine() : VLCEngine()
        e.onEvent = { [weak self] ev in self?.handle(ev) }
        engine = e
        engineKind = k
        e.setFill(fill)
        e.setMuted(muted)
        surfaceVersion += 1
    }

    private func playCurrent(startAt: Double, force: EngineKind? = nil) {
        guard candidates.indices.contains(candidateIndex), let direct = URL(string: candidates[candidateIndex]) else {
            fail()
            return
        }
        let k = force ?? preferredKind(candidates[candidateIndex])
        // Películas y series con VLC pasan por el puente local (pide de nuevo la dirección original
        // en cada tramo, como Android). TV en vivo va directo.
        var url = direct
        if k == .vlc && !isLive, let local = StreamProxy.shared.local(for: candidates[candidateIndex]), let lu = URL(string: local) {
            url = lu
        }
        makeEngine(k)
        buffering = true
        wantPlay = true
        lastAdvance = Date()
        lastProgressPos = -1
        engine?.live = isLive
        engine?.load(url, start: startAt)
        engine?.setRate(rate)
        startTicker()
        loadWatchdog?.cancel()
        let token = candidateIndex
        let kindNow = k
        loadWatchdog = Task { [weak self] in
            try? await Task.sleep(nanoseconds: 22_000_000_000)
            guard let self = self, !Task.isCancelled else { return }
            if !self.started && self.candidateIndex == token && self.engineKind == kindNow { self.handle(.failed) }
        }
    }

    private func handle(_ e: EngineEvent) {
        switch e {
        case .ready:
            started = true
            failed = nil
            buffering = false
            loadWatchdog?.cancel()
        case .ended:
            if isLive { retryLive(); return }
            saveProgress(force: true, finished: true)
            onEnded?()
        case .failed:
            loadWatchdog?.cancel()
            let url = candidates.indices.contains(candidateIndex) ? candidates[candidateIndex] : ""
            Diag.log("Reproducción: \(engineKind == .native ? "nativo" : "VLC") no abrió .\(ext(url)) (opción \(candidateIndex + 1)/\(candidates.count))")
            let resume = started ? position : (request?.startAt ?? 0)
            // Se libera la conexión anterior antes de abrir otra (cuentas de 1 conexión).
            engine?.stop()
            buffering = true
            var next: (() -> Void)?
            if !triedOther && (engineKind == .native || nativeCan(url)) {
                triedOther = true
                let other: EngineKind = engineKind == .native ? .vlc : .native
                next = { [weak self] in self?.playCurrent(startAt: resume, force: other) }
            } else if candidateIndex + 1 < candidates.count {
                candidateIndex += 1
                triedOther = false
                next = { [weak self] in self?.playCurrent(startAt: resume) }
            }
            guard let go = next else { fail(); return }
            retryTask?.cancel()
            retryTask = Task { [weak self] in
                try? await Task.sleep(nanoseconds: 1_200_000_000)
                guard self != nil, !Task.isCancelled else { return }
                go()
            }
        }
    }

    private func retryLive() {
        triedOther = false
        playCurrent(startAt: 0)
    }

    /// Video congelado: se reconecta en el mismo punto (como la vigilancia de búfer de Android).
    private func checkStall() {
        guard started, wantPlay, failed == nil, let e = engine else { return }
        let p = e.position
        if abs(p - lastProgressPos) > 0.3 {
            lastProgressPos = p
            lastAdvance = Date()
            return
        }
        let limit: TimeInterval = isLive ? 12 : 20
        guard Date().timeIntervalSince(lastAdvance) > limit, Date().timeIntervalSince(lastRecovery) > 25 else { return }
        lastRecovery = Date()
        recoveries = recoveries.filter { Date().timeIntervalSince($0) < 120 } + [Date()]
        Diag.log("Reproducción: video detenido \(Int(limit)) s, reconectando")
        if recoveries.count >= 3 && candidateIndex + 1 < candidates.count {
            recoveries = []
            candidateIndex += 1
            triedOther = false
        }
        let resume = isLive ? 0 : position
        let kind = engineKind
        engine?.stop()
        playCurrent(startAt: resume, force: kind)
    }

    private func fail() {
        buffering = false
        isPlaying = false
        failed = isLive ? "Este canal no responde en este momento. Prueba otro canal o vuelve a intentar."
                        : "No se pudo reproducir este contenido. Intenta de nuevo en unos minutos."
    }

    func retry() {
        guard request != nil else { return }
        recoveries = []
        candidateIndex = 0
        triedOther = false
        failed = nil
        playCurrent(startAt: position)
    }

    private func startTicker() {
        ticker?.invalidate()
        let t = Timer(timeInterval: 0.5, repeats: true) { [weak self] _ in
            Task { @MainActor in self?.tick() }
        }
        RunLoop.main.add(t, forMode: .common)
        ticker = t
    }

    private func tick() {
        guard let e = engine else { return }
        let playing = e.isPlaying
        if playing != isPlaying { isPlaying = playing }
        let b = e.isBuffering && failed == nil
        if b != buffering { buffering = b }
        if started {
            let p = e.position
            if abs(p - position) >= 0.25 { position = p }
            let d = e.duration
            if abs(d - duration) > 0.5 { duration = d }
        }
        checkStall()
        if Date().timeIntervalSince(lastSave) > 15 { saveProgress() }
        if Int(position) % 5 == 0 { updateNowPlaying() }
    }

    // MARK: Controles

    func togglePlay() {
        guard let e = engine else { return }
        if e.isPlaying { e.pause(); isPlaying = false; wantPlay = false; saveProgress(force: true) }
        else { e.play(); isPlaying = true; wantPlay = true; lastAdvance = Date() }
        updateNowPlaying()
    }

    func play() { engine?.play(); isPlaying = true; wantPlay = true; lastAdvance = Date() }
    func pause() { engine?.pause(); isPlaying = false; wantPlay = false }

    func seek(to t: Double) {
        guard duration > 0 else { return }
        let target = min(max(0, t), duration - 1)
        engine?.seek(target)
        position = target
        lastAdvance = Date()
        updateNowPlaying()
    }

    func seek(by delta: Double) { seek(to: position + delta) }

    func stop() {
        saveProgress(force: true)
        retryTask?.cancel()
        wantPlay = false
        ticker?.invalidate()
        ticker = nil
        loadWatchdog?.cancel()
        engine?.stop()
        engine?.container.removeFromSuperview()
        engine = nil
        isPlaying = false
        if PlayerModel.current === self {
            PlayerModel.current = nil
            MPNowPlayingInfoCenter.default().nowPlayingInfo = nil
        }
    }

    func audioOptions() -> [TrackOption] { engine?.audioOptions() ?? [] }
    func subtitleOptions() -> [TrackOption] { engine?.subtitleOptions() ?? [] }
    func selectAudio(_ id: String) { engine?.selectAudio(id) }
    func selectSubtitle(_ id: String) { engine?.selectSubtitle(id) }
    var supportsPiP: Bool { engine?.supportsPiP ?? false }
    func togglePiP() { engine?.togglePiP() }

    // MARK: Series y canales

    var nextEpisode: Episode? {
        guard let r = request, r.kind == .series, r.episodeIndex + 1 < r.episodes.count else { return nil }
        return r.episodes[r.episodeIndex + 1]
    }

    func playEpisode(_ index: Int) {
        guard var r = request, let c = creds, r.episodes.indices.contains(index) else { return }
        saveProgress(force: true)
        let ep = r.episodes[index]
        r.episodeIndex = index
        r.candidates = Streams.episode(ep, c)
        r.subtitle = "T\(ep.season) E\(ep.number) · \(ep.title)"
        var startPos: Double = 0
        if let w = library?.find(.series, r.contentId), w.episodeId == ep.id, w.canResume { startPos = Double(w.position) / 1000 }
        r.startAt = startPos
        start(r)
    }

    func stepChannel(_ delta: Int) {
        guard let r = request, r.kind == .tv, !r.channels.isEmpty, let c = creds else { return }
        var i = r.channelIndex + delta
        if i < 0 { i = r.channels.count - 1 }
        if i >= r.channels.count { i = 0 }
        playChannel(i, creds: c, base: r)
    }

    func playChannel(at index: Int) {
        guard let r = request, let c = creds, r.channels.indices.contains(index) else { return }
        playChannel(index, creds: c, base: r)
    }

    private func playChannel(_ i: Int, creds c: Creds, base: PlayRequest) {
        var r = base
        let ch = r.channels[i]
        r.channelIndex = i
        r.contentId = ch.id
        r.title = ch.name
        r.subtitle = ""
        r.artwork = ch.icon
        r.candidates = Streams.live(ch, c, format: AppSettings.liveFormat)
        r.startAt = 0
        Device.haptic()
        start(r)
    }

    func replaceChannels(_ list: [Channel], current id: String) {
        guard var r = request, r.kind == .tv else { return }
        r.channels = list
        r.channelIndex = list.firstIndex { $0.id == id } ?? 0
        request = r
    }

    // MARK: Avance del perfil

    func saveProgress(force: Bool = false, finished: Bool = false) {
        guard let r = request, r.kind != .tv, started, let lib = library else { return }
        if !force && Date().timeIntervalSince(lastSave) < 15 { return }
        lastSave = Date()
        let d = duration
        var p = position
        if finished && d > 0 { p = d }
        guard p > 3 || finished else { return }
        let posMs = Int64(p * 1000), durMs = Int64(d * 1000)
        if r.kind == .series, let ep = r.episode {
            lib.record(.series, id: r.contentId, title: r.seriesTitle.isEmpty ? r.title : r.seriesTitle,
                       url: r.candidates.first ?? "", position: posMs, duration: durMs,
                       episodeId: ep.id, season: ep.season, episode: ep.number)
        } else {
            lib.record(.movie, id: r.contentId, title: r.title, url: r.candidates.first ?? "", position: posMs, duration: durMs)
        }
    }

    // MARK: Pantalla de bloqueo y Centro de control

    func updateNowPlaying() {
        guard let r = request else { return }
        var info: [String: Any] = [
            MPMediaItemPropertyTitle: r.kind == .series ? (r.seriesTitle.isEmpty ? r.title : r.seriesTitle) : r.title,
            MPNowPlayingInfoPropertyPlaybackRate: isPlaying ? Double(rate) : 0.0,
            MPNowPlayingInfoPropertyIsLiveStream: r.isLive
        ]
        if !r.subtitle.isEmpty { info[MPMediaItemPropertyArtist] = r.subtitle } else { info[MPMediaItemPropertyArtist] = "Pacheco's TV" }
        if duration > 0 {
            info[MPMediaItemPropertyPlaybackDuration] = duration
            info[MPNowPlayingInfoPropertyElapsedPlaybackTime] = position
        }
        MPNowPlayingInfoCenter.default().nowPlayingInfo = info
    }
}

enum RemoteCommands {
    private static var installed = false

    @MainActor
    static func install() {
        guard !installed else { return }
        installed = true
        let c = MPRemoteCommandCenter.shared()
        c.playCommand.addTarget { _ in
            Task { @MainActor in PlayerModel.current?.play() }
            return .success
        }
        c.pauseCommand.addTarget { _ in
            Task { @MainActor in PlayerModel.current?.pause() }
            return .success
        }
        c.togglePlayPauseCommand.addTarget { _ in
            Task { @MainActor in PlayerModel.current?.togglePlay() }
            return .success
        }
        c.skipForwardCommand.preferredIntervals = [10]
        c.skipForwardCommand.addTarget { _ in
            Task { @MainActor in PlayerModel.current?.seek(by: 10) }
            return .success
        }
        c.skipBackwardCommand.preferredIntervals = [10]
        c.skipBackwardCommand.addTarget { _ in
            Task { @MainActor in PlayerModel.current?.seek(by: -10) }
            return .success
        }
        c.changePlaybackPositionCommand.addTarget { ev in
            if let e = ev as? MPChangePlaybackPositionCommandEvent {
                let t = e.positionTime
                Task { @MainActor in PlayerModel.current?.seek(to: t) }
            }
            return .success
        }
    }
}
