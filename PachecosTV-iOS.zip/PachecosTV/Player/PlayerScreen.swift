import SwiftUI
import AVKit
import MediaPlayer

/// Superficie de video: coloca la vista del motor activo.
struct VideoSurface: UIViewRepresentable {
    @ObservedObject var model: PlayerModel
    var active: Bool = true

    func makeUIView(context: Context) -> UIView {
        let v = UIView()
        v.backgroundColor = .black
        v.clipsToBounds = true
        attach(v)
        return v
    }

    func updateUIView(_ v: UIView, context: Context) {
        _ = model.surfaceVersion
        attach(v)
    }

    private func attach(_ host: UIView) {
        guard active, let c = model.engine?.container else { return }
        if c.superview !== host {
            c.removeFromSuperview()
            c.frame = host.bounds
            c.autoresizingMask = [.flexibleWidth, .flexibleHeight]
            host.addSubview(c)
        }
    }
}

struct RoutePicker: UIViewRepresentable {
    func makeUIView(context: Context) -> AVRoutePickerView {
        let v = AVRoutePickerView()
        v.tintColor = .white
        v.activeTintColor = UIColor(red: 0.89, green: 0.11, blue: 0.14, alpha: 1)
        v.prioritizesVideoDevices = true
        return v
    }
    func updateUIView(_ uiView: AVRoutePickerView, context: Context) {}
}

/// Volumen del sistema sin mostrar el aviso de iOS.
final class SystemVolume {
    static let shared = SystemVolume()
    let view: MPVolumeView = {
        let v = MPVolumeView(frame: CGRect(x: 0, y: 0, width: 2, height: 2))
        v.alpha = 0.011
        v.isUserInteractionEnabled = false
        return v
    }()
    private var slider: UISlider? { view.subviews.compactMap { $0 as? UISlider }.first }
    var value: Float { AVAudioSession.sharedInstance().outputVolume }
    func set(_ v: Float) { slider?.value = min(1, max(0, v)) }
}

struct VolumeHost: UIViewRepresentable {
    func makeUIView(context: Context) -> UIView {
        let v = UIView(frame: CGRect(x: 0, y: 0, width: 2, height: 2))
        v.isUserInteractionEnabled = false
        return v
    }
    func updateUIView(_ uiView: UIView, context: Context) {
        let vol = SystemVolume.shared.view
        if vol.superview !== uiView { uiView.addSubview(vol) }
    }
}

struct GestureLevel: Equatable {
    var isVolume: Bool
    var value: Double
}

/// Reproductor premium: gestos (brillo a la izquierda, volumen a la derecha, doble toque ±10 s,
/// deslizar para cambiar de canal, pellizcar para llenar), controles de vidrio y bloqueo.
struct PlayerScreen: View {
    @ObservedObject var model: PlayerModel
    var compact = false
    var onClose: () -> Void = {}
    var onExpand: (() -> Void)? = nil
    var onShowChannels: (() -> Void)? = nil

    @State private var controls = true
    @State private var locked = false
    @State private var hideTask: Task<Void, Never>?
    @State private var level: GestureLevel?
    @State private var dragMode = 0
    @State private var dragStartValue: Double = 0
    @State private var seekFlash: (left: Bool, id: Int)? = nil
    @State private var scrub: Double?
    @State private var sheet: PlayerSheet?
    @State private var channelHint: String?
    @State private var nextCancelled = false
    @State private var introShownAt: Date?
    @State private var introDismissedFor: String = ""

    enum PlayerSheet: String, Identifiable {
        case tracks, speed, episodes, fill
        var id: String { rawValue }
    }

    var body: some View {
        GeometryReader { geo in
            ZStack {
                Color.black.ignoresSafeArea(.all, edges: compact ? [] : .all)
                VideoSurface(model: model).ignoresSafeArea(.all, edges: compact ? [] : .all)
                gestureLayer(geo.size).ignoresSafeArea(.all, edges: compact ? [] : .all)
                if model.buffering && model.failed == nil {
                    ProgressView().controlSize(.large).tint(.white)
                        .padding(18).glass(Circle())
                        .allowsHitTesting(false)
                }
                if let f = model.failed { failureView(f) }
                if let l = level { levelIndicator(l, size: geo.size) }
                if let s = seekFlash { seekBubble(left: s.left, size: geo.size) }
                if let h = channelHint { channelToast(h) }
                if !locked && controls && model.failed == nil { controlsLayer(geo.size).transition(.opacity) }
                if locked { lockLayer }
                if !compact { overlays(geo.size) }
                VolumeHost().frame(width: 2, height: 2).allowsHitTesting(false)
            }
        }
        .if(compact) { $0.clipped() }
        .animation(.easeInOut(duration: 0.2), value: controls)
        .animation(.easeInOut(duration: 0.2), value: locked)
        .sheet(item: $sheet) { s in sheetView(s).presentationDetents([.medium, .large]).presentationBackground(.ultraThinMaterial) }
        .onAppear { scheduleHide() }
        .onChange(of: model.isPlaying) { _, playing in if playing { scheduleHide() } }
        .onChange(of: model.request?.id) { _, _ in nextCancelled = false; introShownAt = nil }
    }

    // MARK: Gestos

    private func gestureLayer(_ size: CGSize) -> some View {
        Color.clear
            .contentShape(Rectangle())
            .onTapGesture(count: 2, coordinateSpace: .local) { p in
                guard !locked, !compact, !model.isLive, model.duration > 0 else { return }
                let left = p.x < size.width / 2
                model.seek(by: left ? -10 : 10)
                Device.haptic()
                let id = (seekFlash?.id ?? 0) + 1
                withAnimation(.easeOut(duration: 0.15)) { seekFlash = (left: left, id: id) }
                Task { @MainActor in try? await Task.sleep(nanoseconds: 700_000_000); if seekFlash?.id == id { withAnimation { seekFlash = nil } } }
            }
            .onTapGesture(count: 1) {
                if locked { withAnimation { controls.toggle() }; scheduleHide(); return }
                controls.toggle()
                if controls { scheduleHide() }
            }
            .gesture(locked ? nil : drag(size))
            .simultaneousGesture(compact || locked ? nil : MagnifyGesture().onEnded { v in
                model.fill = v.magnification > 1.05 ? .fill : .fit
                Device.haptic()
            })
    }

    private func drag(_ size: CGSize) -> some Gesture {
        DragGesture(minimumDistance: 14)
            .onChanged { v in
                if dragMode == 0 {
                    let dx = abs(v.translation.width), dy = abs(v.translation.height)
                    if !compact && (v.startLocation.y < 60 || v.startLocation.y > size.height - 40) { dragMode = 3; return }
                    if dy > dx {
                        if compact { dragMode = 3; return }
                        dragMode = v.startLocation.x > size.width / 2 ? 1 : 2
                        dragStartValue = dragMode == 1 ? Double(SystemVolume.shared.value) : Double(Device.screen?.brightness ?? 0.5)
                    } else {
                        dragMode = model.isLive ? 4 : (compact ? 3 : 5)
                    }
                }
                switch dragMode {
                case 1, 2:
                    let delta = -Double(v.translation.height) / Double(size.height * 0.8)
                    let value = min(1, max(0, dragStartValue + delta))
                    if dragMode == 1 { SystemVolume.shared.set(Float(value)) } else { Device.screen?.brightness = CGFloat(value) }
                    level = GestureLevel(isVolume: dragMode == 1, value: value)
                case 5:
                    if model.duration > 0 {
                        let target = min(model.duration, max(0, model.position + Double(v.translation.width) / Double(size.width) * 120))
                        scrub = target
                        controls = true
                    }
                default: break
                }
            }
            .onEnded { v in
                switch dragMode {
                case 4:
                    if abs(v.translation.width) > 60 {
                        let delta = v.translation.width < 0 ? 1 : -1
                        model.stepChannel(delta)
                        showChannelHint()
                    }
                case 5:
                    if let s = scrub { model.seek(to: s) }
                    scrub = nil
                    scheduleHide()
                default: break
                }
                dragMode = 0
                Task { @MainActor in try? await Task.sleep(nanoseconds: 600_000_000); if dragMode == 0 { withAnimation { level = nil } } }
            }
    }

    private func showChannelHint() {
        guard let name = model.request?.title else { return }
        withAnimation(.spring(response: 0.3, dampingFraction: 0.8)) { channelHint = name }
        Task { @MainActor in try? await Task.sleep(nanoseconds: 1_600_000_000); if channelHint == name { withAnimation { channelHint = nil } } }
    }

    private func scheduleHide() {
        hideTask?.cancel()
        hideTask = Task {
            try? await Task.sleep(nanoseconds: 4_200_000_000)
            if Task.isCancelled { return }
            if model.isPlaying && scrub == nil && sheet == nil { withAnimation { controls = false } }
        }
    }

    // MARK: Indicadores

    private func levelIndicator(_ l: GestureLevel, size: CGSize) -> some View {
        HStack {
            if l.isVolume { Spacer() }
            VStack(spacing: 12) {
                Image(systemName: l.isVolume ? (l.value < 0.01 ? "speaker.slash.fill" : "speaker.wave.2.fill") : "sun.max.fill")
                    .font(.system(size: 18, weight: .semibold)).foregroundStyle(.white)
                ZStack(alignment: .bottom) {
                    Capsule().fill(Color.white.opacity(0.18))
                    Capsule().fill(PTV.redGradient).frame(height: max(8, 150 * l.value))
                }
                .frame(width: 8, height: 150)
                Text("\(Int(l.value * 100))%").font(.system(size: 13, weight: .bold, design: .rounded)).foregroundStyle(.white)
                    .monospacedDigit()
            }
            .padding(.vertical, 18).padding(.horizontal, 14)
            .glass(Capsule())
            if !l.isVolume { Spacer() }
        }
        .padding(.horizontal, compact ? 16 : 48)
        .allowsHitTesting(false)
        .transition(.opacity)
    }

    private func seekBubble(left: Bool, size: CGSize) -> some View {
        HStack {
            if !left { Spacer() }
            VStack(spacing: 6) {
                Image(systemName: left ? "gobackward.10" : "goforward.10").font(.system(size: 30, weight: .semibold))
                Text(left ? "-10 s" : "+10 s").font(.system(size: 13, weight: .bold))
            }
            .foregroundStyle(.white)
            .frame(width: size.width * 0.32, height: size.height * 0.6)
            .background(Circle().fill(Color.white.opacity(0.10)).scaleEffect(1.6))
            if left { Spacer() }
        }
        .allowsHitTesting(false)
        .transition(.opacity)
    }

    private func channelToast(_ name: String) -> some View {
        VStack {
            HStack(spacing: 10) {
                Image(systemName: "tv").foregroundStyle(PTV.red)
                Text(name).font(.system(size: 16, weight: .bold)).foregroundStyle(.white).lineLimit(1)
            }
            .padding(.horizontal, 18).padding(.vertical, 12)
            .glassCapsule(interactive: false)
            .padding(.top, compact ? 10 : 30)
            Spacer()
        }
        .allowsHitTesting(false)
        .transition(.move(edge: .top).combined(with: .opacity))
    }

    private func failureView(_ text: String) -> some View {
        VStack(spacing: 14) {
            Image(systemName: "wifi.exclamationmark").font(.system(size: compact ? 26 : 36, weight: .semibold)).foregroundStyle(PTV.red)
            Text(text).font(.system(size: compact ? 13 : 15, weight: .semibold)).foregroundStyle(.white)
                .multilineTextAlignment(.center).padding(.horizontal, 24)
            HStack(spacing: 10) {
                if !compact {
                    GlassButton(title: "Regresar", icon: "chevron.left") { onClose() }
                }
                GlassButton(title: "Reintentar", icon: "arrow.clockwise") { model.retry() }
                if model.isLive {
                    GlassButton(title: "Siguiente", icon: "forward.end.fill") { model.stepChannel(1); showChannelHint() }
                }
            }
        }
        .padding(compact ? 14 : 26)
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(Color.black.opacity(0.55).ignoresSafeArea(.all, edges: compact ? [] : .all))
    }

    // MARK: Controles

    @ViewBuilder
    private func controlsLayer(_ size: CGSize) -> some View {
        if compact { compactControls } else { fullControls(size) }
    }

    private var compactControls: some View {
        ZStack {
            LinearGradient(colors: [.black.opacity(0.55), .clear, .clear, .black.opacity(0.6)], startPoint: .top, endPoint: .bottom)
                .allowsHitTesting(false)
            VStack {
                HStack(spacing: 8) {
                    liveBadge
                    Text(model.request?.title ?? "").font(.system(size: 14, weight: .bold)).foregroundStyle(.white).lineLimit(1)
                    Spacer()
                    RoutePicker().frame(width: 34, height: 34)
                }
                Spacer()
                HStack(spacing: 14) {
                    smallButton(model.isPlaying ? "pause.fill" : "play.fill") { model.togglePlay() }
                    smallButton(model.muted ? "speaker.slash.fill" : "speaker.wave.2.fill") { model.muted.toggle() }
                    Spacer()
                    if model.supportsPiP { smallButton("pip.enter") { model.togglePiP() } }
                    if let e = onExpand { smallButton("arrow.up.left.and.arrow.down.right") { e() } }
                }
            }
            .padding(10)
        }
    }

    private func smallButton(_ icon: String, action: @escaping () -> Void) -> some View {
        Button { Device.haptic(); action(); scheduleHide() } label: {
            Image(systemName: icon).font(.system(size: 15, weight: .bold)).foregroundStyle(.white)
                .frame(width: 38, height: 38).glass(Circle(), interactive: true)
        }
        .buttonStyle(PressScale(scale: 0.9))
    }

    private var liveBadge: some View {
        HStack(spacing: 5) {
            Circle().fill(Color.white).frame(width: 6, height: 6)
            Text("EN VIVO").font(.system(size: 10, weight: .black))
        }
        .foregroundStyle(.white)
        .padding(.horizontal, 8).padding(.vertical, 4)
        .background(PTV.red, in: Capsule())
    }

    private func fullControls(_ size: CGSize) -> some View {
        ZStack {
            LinearGradient(colors: [.black.opacity(0.7), .clear, .clear, .black.opacity(0.8)], startPoint: .top, endPoint: .bottom)
                .ignoresSafeArea()
                .allowsHitTesting(false)
            VStack(spacing: 0) {
                topBar
                Spacer()
                bottomBar
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 12)
            centerButtons
        }
    }

    private var topBar: some View {
        HStack(spacing: 14) {
            Button { Device.haptic(); onClose() } label: {
                HStack(spacing: 6) {
                    Image(systemName: "chevron.left").font(.system(size: 17, weight: .bold))
                    Text("Regresar").font(.system(size: 15, weight: .semibold))
                }
                .foregroundStyle(.white)
                .padding(.horizontal, 14).frame(height: 42)
                .glassCapsule()
            }
            .buttonStyle(PressScale())
            VStack(alignment: .leading, spacing: 2) {
                Text(model.request?.kind == .series ? (model.request?.seriesTitle ?? "") : (model.request?.title ?? ""))
                    .font(.system(size: 17, weight: .bold)).foregroundStyle(.white).lineLimit(1)
                if let s = model.request?.subtitle, !s.isEmpty {
                    Text(s).font(.system(size: 13, weight: .medium)).foregroundStyle(PTV.text2).lineLimit(1)
                }
            }
            Spacer()
            RoutePicker().frame(width: 42, height: 42).glass(Circle())
            if model.supportsPiP { CircleIconButton(icon: "pip.enter", size: 42) { model.togglePiP() } }
            CircleIconButton(icon: "lock.open.fill", size: 42) {
                withAnimation { locked = true; controls = false }
            }
        }
    }

    private var centerButtons: some View {
        HStack(spacing: 46) {
            if model.isLive {
                centerSmall("backward.end.fill") { model.stepChannel(-1); showChannelHint() }
            } else {
                centerSmall("gobackward.10") { model.seek(by: -10) }
            }
            Button { Device.haptic(.medium); model.togglePlay(); scheduleHide() } label: {
                Image(systemName: model.isPlaying ? "pause.fill" : "play.fill")
                    .font(.system(size: 34, weight: .bold)).foregroundStyle(.white)
                    .frame(width: 82, height: 82)
                    .glass(Circle(), interactive: true)
                    .contentTransition(.symbolEffect(.replace))
            }
            .buttonStyle(PressScale(scale: 0.9))
            .opacity(model.buffering ? 0 : 1)
            if model.isLive {
                centerSmall("forward.end.fill") { model.stepChannel(1); showChannelHint() }
            } else {
                centerSmall("goforward.10") { model.seek(by: 10) }
            }
        }
    }

    private func centerSmall(_ icon: String, action: @escaping () -> Void) -> some View {
        Button { Device.haptic(); action(); scheduleHide() } label: {
            Image(systemName: icon).font(.system(size: 24, weight: .semibold)).foregroundStyle(.white)
                .frame(width: 58, height: 58).glass(Circle(), interactive: true)
        }
        .buttonStyle(PressScale(scale: 0.9))
    }

    private var bottomBar: some View {
        VStack(spacing: 14) {
            if model.isLive {
                HStack(spacing: 10) {
                    liveBadge
                    if let n = model.request?.subtitle, !n.isEmpty {
                        Text(n).font(.system(size: 14, weight: .semibold)).foregroundStyle(.white).lineLimit(1)
                    }
                    Spacer()
                }
            } else if model.duration > 0 {
                Scrubber(value: Binding(get: { scrub ?? model.position }, set: { scrub = $0 }),
                         total: model.duration,
                         onEnd: { v in model.seek(to: v); scrub = nil; scheduleHide() },
                         onBegin: { hideTask?.cancel() })
                HStack {
                    Text(Txt.time(scrub ?? model.position)).monospacedDigit()
                    Spacer()
                    Text("-" + Txt.time(max(0, model.duration - (scrub ?? model.position)))).monospacedDigit()
                }
                .font(.system(size: 12, weight: .semibold)).foregroundStyle(PTV.text2)
            }
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 10) {
                    pill("Audio y subtítulos", "captions.bubble.fill") { sheet = .tracks }
                    pill(model.fill.title, model.fill.icon) { cycleFill() }
                    if !model.isLive { pill(model.rate == 1 ? "Velocidad" : String(format: "%.2gx", model.rate), "speedometer") { sheet = .speed } }
                    if model.request?.kind == .series {
                        pill("Episodios", "list.bullet.rectangle.portrait.fill") { sheet = .episodes }
                        if model.nextEpisode != nil { pill("Siguiente", "forward.end.fill") { model.playEpisode((model.request?.episodeIndex ?? 0) + 1) } }
                    }
                    if model.isLive, let s = onShowChannels { pill("Canales", "list.bullet") { s() } }
                }
            }
        }
    }

    private func pill(_ t: String, _ icon: String, action: @escaping () -> Void) -> some View {
        Button { Device.haptic(); action(); scheduleHide() } label: {
            HStack(spacing: 7) {
                Image(systemName: icon).font(.system(size: 13, weight: .bold))
                Text(t).font(.system(size: 13, weight: .semibold))
            }
            .foregroundStyle(.white)
            .padding(.horizontal, 14).frame(height: 38)
            .glassCapsule()
        }
        .buttonStyle(PressScale())
    }

    private func cycleFill() {
        let all = FillMode.allCases
        let i = all.firstIndex(of: model.fill) ?? 0
        model.fill = all[(i + 1) % all.count]
    }

    private var lockLayer: some View {
        VStack {
            Spacer()
            if controls {
                Button {
                    Device.haptic(.medium)
                    withAnimation { locked = false; controls = true }
                    scheduleHide()
                } label: {
                    HStack(spacing: 8) {
                        Image(systemName: "lock.fill")
                        Text("Toca para desbloquear").font(.system(size: 14, weight: .bold))
                    }
                    .foregroundStyle(.white).padding(.horizontal, 18).frame(height: 46).glassCapsule()
                }
                .padding(.bottom, 40)
                .transition(.opacity)
            }
        }
    }

    // MARK: Siguiente episodio y saltar intro

    @ViewBuilder
    private func overlays(_ size: CGSize) -> some View {
        let remaining = model.duration - model.position
        if let next = model.nextEpisode, model.duration > 0, remaining < 25, remaining > 0, !nextCancelled, AppSettings.autoNext {
            NextEpisodeCard(episode: next, seconds: Int(remaining), onPlay: {
                model.playEpisode((model.request?.episodeIndex ?? 0) + 1)
            }, onCancel: { nextCancelled = true })
            .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .bottomTrailing)
            .padding(.horizontal, 40).padding(.bottom, 90)
            .transition(.move(edge: .trailing).combined(with: .opacity))
        } else if showSkipIntro {
            Button {
                Device.haptic()
                var target = model.position + 85
                if model.duration > 0 { target = min(target, model.duration - 5) }
                model.seek(to: target)
                introDismissedFor = model.request?.episode?.id ?? ""
            } label: {
                HStack(spacing: 8) {
                    Text("Saltar intro").font(.system(size: 15, weight: .bold))
                    Image(systemName: "forward.fill")
                }
                .foregroundStyle(.black).padding(.horizontal, 20).frame(height: 46)
                .background(Color.white, in: Capsule())
            }
            .buttonStyle(PressScale())
            .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .bottomTrailing)
            .padding(.horizontal, 44).padding(.bottom, controls ? 120 : 50)
            .transition(.opacity)
            .onAppear { if introShownAt == nil { introShownAt = Date() } }
        }
    }

    private var showSkipIntro: Bool {
        guard let r = model.request, r.kind == .series, let ep = r.episode, model.started, !locked else { return false }
        guard ep.id != introDismissedFor else { return false }
        let inIntro = model.position >= 5 && model.position <= 150 && (model.duration == 0 || model.duration > 360)
        if let t = introShownAt, Date().timeIntervalSince(t) > 12 { return false }
        return inIntro
    }

    // MARK: Hojas

    @ViewBuilder
    private func sheetView(_ s: PlayerSheet) -> some View {
        switch s {
        case .tracks: TracksSheet(model: model)
        case .speed: SpeedSheet(model: model)
        case .episodes: EpisodesSheet(model: model)
        case .fill: EmptyView()
        }
    }
}

struct Scrubber: View {
    @Binding var value: Double
    let total: Double
    var onEnd: (Double) -> Void
    var onBegin: () -> Void
    @State private var dragging = false

    var body: some View {
        GeometryReader { g in
            let frac = total > 0 ? min(1, max(0, value / total)) : 0
            ZStack(alignment: .leading) {
                Capsule().fill(Color.white.opacity(0.22)).frame(height: dragging ? 8 : 5)
                Capsule().fill(PTV.redGradient).frame(width: max(0, g.size.width * frac), height: dragging ? 8 : 5)
                Circle().fill(Color.white).frame(width: dragging ? 20 : 14, height: dragging ? 20 : 14)
                    .shadow(color: .black.opacity(0.4), radius: 4)
                    .offset(x: max(0, g.size.width * frac - (dragging ? 10 : 7)))
            }
            .frame(height: 24)
            .contentShape(Rectangle())
            .gesture(DragGesture(minimumDistance: 0)
                .onChanged { v in
                    if !dragging { dragging = true; onBegin() }
                    value = min(total, max(0, Double(v.location.x / g.size.width) * total))
                }
                .onEnded { _ in
                    dragging = false
                    onEnd(value)
                })
            .animation(.spring(response: 0.25, dampingFraction: 0.8), value: dragging)
        }
        .frame(height: 24)
    }
}

struct NextEpisodeCard: View {
    let episode: Episode
    let seconds: Int
    let onPlay: () -> Void
    let onCancel: () -> Void

    var body: some View {
        HStack(spacing: 12) {
            RemoteImage(url: episode.image, maxPixel: 300)
                .frame(width: 110, height: 62).clipShape(RoundedRectangle(cornerRadius: 10, style: .continuous))
            VStack(alignment: .leading, spacing: 4) {
                Text("Siguiente episodio en \(max(0, seconds)) s").font(.system(size: 12, weight: .bold)).foregroundStyle(PTV.red)
                Text("T\(episode.season) E\(episode.number) · \(episode.title)").font(.system(size: 14, weight: .bold)).foregroundStyle(.white).lineLimit(2)
                HStack(spacing: 8) {
                    Button(action: onPlay) {
                        Label("Ver ahora", systemImage: "play.fill").font(.system(size: 13, weight: .bold)).foregroundStyle(.black)
                            .padding(.horizontal, 12).frame(height: 32).background(Color.white, in: Capsule())
                    }
                    Button("Ver créditos", action: onCancel).font(.system(size: 13, weight: .semibold)).foregroundStyle(PTV.text2)
                }
            }
        }
        .padding(12)
        .frame(maxWidth: 380)
        .glass(RoundedRectangle(cornerRadius: 20, style: .continuous))
    }
}

struct TracksSheet: View {
    @ObservedObject var model: PlayerModel
    @State private var audio: [TrackOption] = []
    @State private var subs: [TrackOption] = []

    var body: some View {
        NavigationStack {
            List {
                Section("Audio") {
                    if audio.isEmpty { Text("Pista predeterminada").foregroundStyle(PTV.text2) }
                    ForEach(audio) { t in row(t) { model.selectAudio(t.id); reload() } }
                }
                Section("Subtítulos") {
                    if subs.isEmpty { Text("Sin subtítulos").foregroundStyle(PTV.text2) }
                    ForEach(subs) { t in row(t) { model.selectSubtitle(t.id); reload() } }
                }
            }
            .scrollContentBackground(.hidden)
            .navigationTitle("Audio y subtítulos")
            .navigationBarTitleDisplayMode(.inline)
        }
        .onAppear { reload() }
    }

    private func row(_ t: TrackOption, action: @escaping () -> Void) -> some View {
        Button { Device.haptic(); action() } label: {
            HStack {
                Text(t.name).foregroundStyle(.white)
                Spacer()
                if t.selected { Image(systemName: "checkmark").foregroundStyle(PTV.red).fontWeight(.bold) }
            }
        }
    }

    private func reload() {
        audio = model.audioOptions()
        subs = model.subtitleOptions()
    }
}

struct SpeedSheet: View {
    @ObservedObject var model: PlayerModel
    @Environment(\.dismiss) private var dismiss
    private let speeds: [Float] = [0.5, 0.75, 1, 1.25, 1.5, 2]

    var body: some View {
        VStack(spacing: 20) {
            Text("Velocidad").font(.system(size: 20, weight: .bold)).foregroundStyle(.white).padding(.top, 24)
            HStack(spacing: 10) {
                ForEach(speeds, id: \.self) { s in
                    Button {
                        Device.haptic(); model.rate = s; dismiss()
                    } label: {
                        Text(s == 1 ? "Normal" : String(format: "%.2gx", s))
                            .font(.system(size: 14, weight: .bold))
                            .foregroundStyle(model.rate == s ? .black : .white)
                            .frame(maxWidth: .infinity).frame(height: 44)
                            .background(model.rate == s ? Color.white : Color.white.opacity(0.1), in: Capsule())
                    }
                }
            }
            .padding(.horizontal, 16)
            Spacer()
        }
    }
}

struct EpisodesSheet: View {
    @ObservedObject var model: PlayerModel
    @Environment(\.dismiss) private var dismiss
    @State private var season = 1

    var body: some View {
        let eps = model.request?.episodes ?? []
        let seasons = Array(Set(eps.map { $0.season })).sorted()
        NavigationStack {
            VStack(spacing: 0) {
                if seasons.count > 1 {
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 8) {
                            ForEach(seasons, id: \.self) { s in Chip(title: "Temporada \(s)", selected: s == season) { season = s } }
                        }
                        .padding(.horizontal, 16).padding(.vertical, 10)
                    }
                }
                List {
                    ForEach(Array(eps.enumerated()).filter { $0.element.season == season }, id: \.element.id) { idx, ep in
                        Button {
                            Device.haptic(); dismiss(); model.playEpisode(idx)
                        } label: {
                            HStack(spacing: 12) {
                                RemoteImage(url: ep.image, maxPixel: 260).frame(width: 96, height: 54)
                                    .clipShape(RoundedRectangle(cornerRadius: 8, style: .continuous))
                                VStack(alignment: .leading, spacing: 3) {
                                    Text("E\(ep.number) · \(ep.title)").font(.system(size: 14, weight: .bold)).foregroundStyle(.white).lineLimit(2)
                                    if !ep.duration.isEmpty { Text(ep.duration).font(.system(size: 12)).foregroundStyle(PTV.text2) }
                                }
                                Spacer()
                                if idx == model.request?.episodeIndex { Image(systemName: "speaker.wave.2.fill").foregroundStyle(PTV.red) }
                            }
                        }
                        .listRowBackground(Color.clear)
                    }
                }
                .listStyle(.plain)
                .scrollContentBackground(.hidden)
            }
            .navigationTitle("Episodios")
            .navigationBarTitleDisplayMode(.inline)
        }
        .onAppear { season = model.request?.episode?.season ?? seasons.first ?? 1 }
    }
}

/// Reproductor a pantalla completa (películas, series, eventos y TV).
struct PlayerContainer: View {
    let request: PlayRequest
    @EnvironmentObject var app: AppModel
    @EnvironmentObject var session: SessionStore
    @EnvironmentObject var library: LibraryStore
    @EnvironmentObject var catalog: CatalogStore
    @StateObject private var model = PlayerModel()
    @State private var showChannels = false

    var body: some View {
        ZStack(alignment: .trailing) {
            PlayerScreen(model: model, compact: false, onClose: close,
                         onShowChannels: request.isLive ? { withAnimation(.spring(response: 0.35, dampingFraction: 0.85)) { showChannels = true } } : nil)
            if showChannels { channelPanel.transition(.move(edge: .trailing)) }
        }
        .background(Color.black.ignoresSafeArea())
        .statusBarHidden(true)
        .persistentSystemOverlays(.hidden)
        .onAppear {
            let m = model
            let router = app.router
            m.configure(creds: session.creds, library: library)
            m.onEnded = { [weak m, weak router] in
                guard let m = m else { return }
                if m.nextEpisode != nil && AppSettings.autoNext {
                    m.playEpisode((m.request?.episodeIndex ?? 0) + 1)
                } else {
                    m.stop()
                    router?.player = nil
                }
            }
            m.start(request)
            if request.landscape { Orientation.set(.landscape, rotate: .landscapeRight) } else { Orientation.set(.allButUpsideDown) }
        }
        .onDisappear {
            model.stop()
            Orientation.set(.portrait, rotate: .portrait)
        }
        .onChange(of: session.blocked) { _, b in if let b = b, b.blocks { close() } }
    }

    private func close() {
        model.stop()
        app.router.player = nil
    }

    private var channelPanel: some View {
        ZStack(alignment: .trailing) {
            Color.black.opacity(0.35).ignoresSafeArea().onTapGesture { withAnimation { showChannels = false } }
            VStack(alignment: .leading, spacing: 0) {
                HStack {
                    Text("Canales").font(.system(size: 18, weight: .bold)).foregroundStyle(.white)
                    Spacer()
                    CircleIconButton(icon: "xmark", size: 34) { withAnimation { showChannels = false } }
                }
                .padding(16)
                ScrollViewReader { proxy in
                    ScrollView {
                        LazyVStack(spacing: 4) {
                            ForEach(Array((model.request?.channels ?? []).enumerated()), id: \.element.id) { i, ch in
                                Button {
                                    model.playChannel(at: i)
                                    withAnimation { showChannels = false }
                                } label: {
                                    HStack(spacing: 12) {
                                        ChannelLogo(url: ch.icon, name: ch.name, size: 40)
                                        Text(ch.name).font(.system(size: 14, weight: .semibold)).foregroundStyle(.white).lineLimit(1)
                                        Spacer()
                                        if i == model.request?.channelIndex { Image(systemName: "dot.radiowaves.left.and.right").foregroundStyle(PTV.red) }
                                    }
                                    .padding(.horizontal, 14).padding(.vertical, 8)
                                    .background(i == model.request?.channelIndex ? Color.white.opacity(0.10) : Color.clear,
                                                in: RoundedRectangle(cornerRadius: 12, style: .continuous))
                                }
                                .id(i)
                            }
                        }
                        .padding(.horizontal, 8).padding(.bottom, 20)
                    }
                    .onAppear { proxy.scrollTo(model.request?.channelIndex ?? 0, anchor: .center) }
                }
            }
            .frame(width: 340)
            .glass(Rectangle())
            .ignoresSafeArea()
        }
    }
}
