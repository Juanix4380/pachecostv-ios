import Foundation
import UIKit
import AVFoundation
import AVKit
import MobileVLCKit

enum EngineKind { case native, vlc }
enum FillMode: CaseIterable {
    case fit, fill, stretch
    var title: String {
        switch self {
        case .fit: return "Original"
        case .fill: return "Llenar pantalla"
        case .stretch: return "Estirar"
        }
    }
    var icon: String {
        switch self {
        case .fit: return "rectangle.arrowtriangle.2.inward"
        case .fill: return "rectangle.arrowtriangle.2.outward"
        case .stretch: return "arrow.left.and.right.square"
        }
    }
}

enum EngineEvent { case ready, ended, failed }

struct TrackOption: Identifiable, Hashable {
    let id: String
    let name: String
    let selected: Bool
}

/// Mismos encabezados que usa la app Android al reproducir.
enum PlayerHeaders {
    static let userAgent = "IPTVSmartersPro/1.1 PachecosTV-Mobile"
    static let all: [String: String] = ["User-Agent": userAgent, "Accept": "*/*", "Icy-MetaData": "1"]
}

/// Base común: cada motor entrega su vista de video en `container`.
class VideoEngine: NSObject {
    let container = UIView()
    var onEvent: ((EngineEvent) -> Void)?
    var live = false
    var kind: EngineKind { .native }

    override init() {
        super.init()
        container.backgroundColor = .black
        container.clipsToBounds = true
    }

    func load(_ url: URL, start: Double) {}
    func play() {}
    func pause() {}
    func stop() {}
    var isPlaying: Bool { false }
    var isBuffering: Bool { false }
    var position: Double { 0 }
    var duration: Double { 0 }
    var hasVideo: Bool { true }
    func seek(_ t: Double) {}
    func setRate(_ r: Float) {}
    func setMuted(_ m: Bool) {}
    func setFill(_ m: FillMode) {}
    func audioOptions() -> [TrackOption] { [] }
    func subtitleOptions() -> [TrackOption] { [] }
    func selectAudio(_ id: String) {}
    func selectSubtitle(_ id: String) {}
    var supportsPiP: Bool { false }
    func togglePiP() {}
}

// MARK: - Motor nativo (AVPlayer): HLS, MP4, PiP y AirPlay

final class PlayerLayerView: UIView {
    override class var layerClass: AnyClass { AVPlayerLayer.self }
    var playerLayer: AVPlayerLayer { layer as! AVPlayerLayer }
}

final class NativeEngine: VideoEngine, AVPictureInPictureControllerDelegate {
    let player = AVPlayer()
    private let layerView = PlayerLayerView()
    private var pip: AVPictureInPictureController?
    private var asset: AVURLAsset?
    private var statusObs: NSKeyValueObservation?
    private var tokens: [NSObjectProtocol] = []
    private var audible: AVMediaSelectionGroup?
    private var legible: AVMediaSelectionGroup?
    private var startAt: Double = 0
    private var reported = false

    override var kind: EngineKind { .native }

    override init() {
        super.init()
        layerView.frame = container.bounds
        layerView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        layerView.playerLayer.player = player
        layerView.playerLayer.videoGravity = .resizeAspect
        layerView.backgroundColor = .black
        container.addSubview(layerView)
        player.allowsExternalPlayback = true
        player.usesExternalPlaybackWhileExternalScreenIsActive = true
        player.automaticallyWaitsToMinimizeStalling = true
        if AVPictureInPictureController.isPictureInPictureSupported() {
            let p = AVPictureInPictureController(playerLayer: layerView.playerLayer)
            p?.canStartPictureInPictureAutomaticallyFromInline = true
            p?.delegate = self
            pip = p
        }
    }

    override func load(_ url: URL, start: Double) {
        clearItem()
        startAt = start
        reported = false
        let a = AVURLAsset(url: url, options: ["AVURLAssetHTTPHeaderFieldsKey": PlayerHeaders.all])
        asset = a
        let item = AVPlayerItem(asset: a)
        // Igual que Android: VOD guarda hasta 60 s; en vivo lo decide iOS.
        item.preferredForwardBufferDuration = live ? 0 : 60
        statusObs = item.observe(\.status, options: [.new]) { [weak self] it, _ in
            DispatchQueue.main.async { self?.itemStatus(it) }
        }
        let nc = NotificationCenter.default
        tokens.append(nc.addObserver(forName: AVPlayerItem.didPlayToEndTimeNotification, object: item, queue: .main) { [weak self] _ in
            self?.onEvent?(.ended)
        })
        tokens.append(nc.addObserver(forName: AVPlayerItem.failedToPlayToEndTimeNotification, object: item, queue: .main) { [weak self] _ in
            self?.onEvent?(.failed)
        })
        player.replaceCurrentItem(with: item)
        player.play()
    }

    private func itemStatus(_ it: AVPlayerItem) {
        switch it.status {
        case .readyToPlay:
            guard !reported else { return }
            reported = true
            if startAt > 1 {
                player.seek(to: CMTime(seconds: startAt, preferredTimescale: 600))
            }
            loadGroups()
            onEvent?(.ready)
        case .failed:
            onEvent?(.failed)
        default: break
        }
    }

    private func loadGroups() {
        guard let a = asset else { return }
        Task { @MainActor [weak self] in
            let au = try? await a.loadMediaSelectionGroup(for: .audible)
            let le = try? await a.loadMediaSelectionGroup(for: .legible)
            self?.audible = au
            self?.legible = le
        }
    }

    private func clearItem() {
        statusObs?.invalidate()
        statusObs = nil
        tokens.forEach { NotificationCenter.default.removeObserver($0) }
        tokens.removeAll()
        audible = nil
        legible = nil
    }

    override func play() { player.play() }
    override func pause() { player.pause() }
    override func stop() {
        clearItem()
        player.pause()
        player.replaceCurrentItem(with: nil)
    }

    override var isPlaying: Bool { player.timeControlStatus == .playing || (player.rate > 0 && player.timeControlStatus != .paused) }
    override var isBuffering: Bool {
        player.timeControlStatus == .waitingToPlayAtSpecifiedRate || player.currentItem?.status == .unknown
    }
    override var position: Double {
        let t = player.currentTime().seconds
        return t.isFinite ? max(0, t) : 0
    }
    override var duration: Double {
        guard let d = player.currentItem?.duration.seconds, d.isFinite, d > 0 else { return 0 }
        return d
    }
    override func seek(_ t: Double) {
        player.seek(to: CMTime(seconds: max(0, t), preferredTimescale: 600), toleranceBefore: CMTime(seconds: 1, preferredTimescale: 600),
                    toleranceAfter: CMTime(seconds: 1, preferredTimescale: 600))
    }
    override func setRate(_ r: Float) {
        player.defaultRate = r
        if player.timeControlStatus != .paused { player.rate = r }
    }
    override func setMuted(_ m: Bool) { player.isMuted = m }
    override func setFill(_ m: FillMode) {
        switch m {
        case .fit: layerView.playerLayer.videoGravity = .resizeAspect
        case .fill: layerView.playerLayer.videoGravity = .resizeAspectFill
        case .stretch: layerView.playerLayer.videoGravity = .resize
        }
    }

    override func audioOptions() -> [TrackOption] {
        guard let g = audible, let item = player.currentItem else { return [] }
        let sel = item.currentMediaSelection.selectedMediaOption(in: g)
        return g.options.enumerated().map { TrackOption(id: "\($0.offset)", name: $0.element.displayName, selected: $0.element == sel) }
    }

    override func subtitleOptions() -> [TrackOption] {
        guard let g = legible, let item = player.currentItem else { return [] }
        let sel = item.currentMediaSelection.selectedMediaOption(in: g)
        var out = [TrackOption(id: "off", name: "Desactivados", selected: sel == nil)]
        out += g.options.enumerated().map { TrackOption(id: "\($0.offset)", name: $0.element.displayName, selected: $0.element == sel) }
        return out
    }

    override func selectAudio(_ id: String) {
        guard let g = audible, let i = Int(id), g.options.indices.contains(i) else { return }
        player.currentItem?.select(g.options[i], in: g)
    }

    override func selectSubtitle(_ id: String) {
        guard let g = legible else { return }
        if let i = Int(id), g.options.indices.contains(i) { player.currentItem?.select(g.options[i], in: g) }
        else { player.currentItem?.select(nil, in: g) }
    }

    override var supportsPiP: Bool { pip != nil }
    override func togglePiP() {
        guard let p = pip else { return }
        if p.isPictureInPictureActive { p.stopPictureInPicture() } else { p.startPictureInPicture() }
    }
}

// MARK: - Motor VLC: .ts, .mkv, .avi y todo lo que AVPlayer no abre

final class VLCHostView: UIView {
    let videoView = UIView()
    var videoSize: CGSize = .zero { didSet { if videoSize != oldValue { setNeedsLayout() } } }
    var mode: FillMode = .fit { didSet { setNeedsLayout() } }

    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = .black
        clipsToBounds = true
        videoView.backgroundColor = .black
        addSubview(videoView)
    }

    required init?(coder: NSCoder) { fatalError() }

    override func layoutSubviews() {
        super.layoutSubviews()
        videoView.transform = .identity
        videoView.frame = bounds
        guard videoSize.width > 0, videoSize.height > 0, bounds.width > 0, bounds.height > 0, mode != .fit else { return }
        let fit = min(bounds.width / videoSize.width, bounds.height / videoSize.height)
        let shownW = videoSize.width * fit, shownH = videoSize.height * fit
        let sx = bounds.width / shownW, sy = bounds.height / shownH
        if mode == .fill {
            let s = max(sx, sy)
            videoView.transform = CGAffineTransform(scaleX: s, y: s)
        } else {
            videoView.transform = CGAffineTransform(scaleX: sx, y: sy)
        }
    }
}

final class VLCEngine: VideoEngine {
    private let player = VLCMediaPlayer()
    private let host = VLCHostView(frame: .zero)
    private var timer: Timer?
    private var startAt: Double = 0
    private var didStartSeek = true
    private var reported = false
    private var ended = false
    private var openedAt = Date()

    override var kind: EngineKind { .vlc }

    override init() {
        super.init()
        host.frame = container.bounds
        host.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        container.addSubview(host)
        player.drawable = host.videoView
    }

    override func load(_ url: URL, start: Double) {
        timer?.invalidate()
        startAt = start
        didStartSeek = start <= 1
        reported = false
        ended = false
        openedAt = Date()
        if player.state != .stopped { player.stop() }
        let media = VLCMedia(url: url)
        let cache = live ? 4000 : 6000
        var options: [AnyHashable: Any] = ["network-caching": cache, "live-caching": cache, "file-caching": cache,
                                           "http-user-agent": PlayerHeaders.userAgent, "http-reconnect": true]
        if live {
            options["clock-jitter"] = 0
            options["clock-synchro"] = 0
        }
        media.addOptions(options)
        player.media = media
        player.play()
        let t = Timer(timeInterval: 0.4, repeats: true) { [weak self] _ in self?.tick() }
        RunLoop.main.add(t, forMode: .common)
        timer = t
    }

    private func tick() {
        let st = player.state
        host.videoSize = player.videoSize
        switch st {
        case .playing, .esAdded:
            if !reported, player.isPlaying || timeMs > 0 {
                reported = true
                onEvent?(.ready)
            }
            if !didStartSeek, player.isSeekable {
                didStartSeek = true
                seek(startAt)
            }
        case .error:
            timer?.invalidate()
            onEvent?(.failed)
        case .ended:
            if !ended {
                ended = true
                if reported && duration > 0 { onEvent?(.ended) } else { timer?.invalidate(); onEvent?(.failed) }
            }
        case .stopped:
            if !reported && Date().timeIntervalSince(openedAt) > 3 {
                timer?.invalidate()
                onEvent?(.failed)
            }
        default:
            break
        }
    }

    private var timeMs: Int32 { (player.time as VLCTime?)?.intValue ?? 0 }

    override func play() { player.play() }
    override func pause() { player.pause() }
    override func stop() {
        timer?.invalidate()
        timer = nil
        player.stop()
    }

    override var isPlaying: Bool { player.isPlaying }
    override var isBuffering: Bool {
        let st = player.state
        return st == .opening || st == .buffering && !player.isPlaying
    }
    override var position: Double { Double(timeMs) / 1000 }
    override var duration: Double {
        let m = player.media as VLCMedia?
        let len = (m?.length as VLCTime?)?.intValue ?? 0
        return len > 0 ? Double(len) / 1000 : 0
    }
    override func seek(_ t: Double) {
        guard player.isSeekable else { return }
        player.time = VLCTime(int: Int32(max(0, t) * 1000))
    }
    override func setRate(_ r: Float) { player.rate = r }
    override func setMuted(_ m: Bool) {
        if let a = player.audio as VLCAudio? { a.isMuted = m }
    }
    override func setFill(_ m: FillMode) { host.mode = m }

    override func audioOptions() -> [TrackOption] {
        let names = (player.audioTrackNames as [Any]?) ?? []
        let idx = (player.audioTrackIndexes as [Any]?) ?? []
        let cur = player.currentAudioTrackIndex
        var out: [TrackOption] = []
        for (i, n) in names.enumerated() where i < idx.count {
            guard let id = (idx[i] as? NSNumber)?.int32Value, id >= 0 else { continue }
            out.append(TrackOption(id: "\(id)", name: (n as? String) ?? "Pista \(i)", selected: id == cur))
        }
        return out
    }

    override func subtitleOptions() -> [TrackOption] {
        let names = (player.videoSubTitlesNames as [Any]?) ?? []
        let idx = (player.videoSubTitlesIndexes as [Any]?) ?? []
        let cur = player.currentVideoSubTitleIndex
        var out = [TrackOption(id: "-1", name: "Desactivados", selected: cur < 0)]
        for (i, n) in names.enumerated() where i < idx.count {
            guard let id = (idx[i] as? NSNumber)?.int32Value, id >= 0 else { continue }
            out.append(TrackOption(id: "\(id)", name: (n as? String) ?? "Subtítulo \(i)", selected: id == cur))
        }
        return out
    }

    override func selectAudio(_ id: String) { if let i = Int32(id) { player.currentAudioTrackIndex = i } }
    override func selectSubtitle(_ id: String) { if let i = Int32(id) { player.currentVideoSubTitleIndex = i } }

    deinit {
        timer?.invalidate()
        player.stop()
    }
}
