import Foundation

enum Kind: String, Hashable, Codable {
    case movie, series, tv
}

struct Creds: Hashable {
    var server: String
    var user: String
    var pass: String
    var extraServers: [String] = []

    var base: String { server.trimmingCharacters(in: CharacterSet(charactersIn: "/ ")) }

    func api(_ action: String = "") -> String {
        var u = "\(base)/player_api.php?username=\(Txt.query(user))&password=\(Txt.query(pass))"
        if !action.isEmpty { u += "&action=\(action)" }
        return u
    }
}

struct Category: Identifiable, Hashable {
    let id: String
    let name: String
}

struct Channel: Identifiable, Hashable {
    let id: String
    let num: Int
    let name: String
    let icon: String
    let categoryId: String
    let epgId: String
    let archive: Bool
    let direct: String
    let norm: String
}

struct Vod: Identifiable, Hashable {
    let id: String
    let name: String
    let icon: String
    let categoryId: String
    let rating: Double
    let year: String
    let genre: String
    let plot: String
    let ext: String
    let added: Int64
    let duration: String
}

struct SeriesItem: Identifiable, Hashable {
    let id: String
    let name: String
    let cover: String
    let categoryId: String
    let rating: Double
    let year: String
    let genre: String
    let plot: String
    let backdrop: String
    let added: Int64
}

struct Episode: Identifiable, Hashable {
    let id: String
    let season: Int
    let number: Int
    let title: String
    let image: String
    let plot: String
    let duration: String
    let ext: String
}

struct EpgItem: Identifiable, Hashable {
    let id: String
    let title: String
    let desc: String
    let start: Date
    let end: Date

    var progress: Double {
        let total = end.timeIntervalSince(start)
        guard total > 0 else { return 0 }
        return min(1, max(0, Date().timeIntervalSince(start) / total))
    }
    var isNow: Bool { let n = Date(); return start <= n && n < end }
}

struct VodInfo {
    var plot = ""
    var cast = ""
    var director = ""
    var genre = ""
    var year = ""
    var rating = 0.0
    var duration = ""
    var backdrop = ""
    var cover = ""
    var trailer = ""
    var ext = ""
}

struct SeriesInfo {
    var plot = ""
    var cast = ""
    var genre = ""
    var year = ""
    var rating = 0.0
    var backdrop = ""
    var cover = ""
    var trailer = ""
    var seasons: [Int: [Episode]] = [:]
}

// MARK: - Interpretación de listas Xtream (fuera del hilo principal)

enum XtreamParse {
    static func rating(_ o: JObj) -> Double {
        var r = o.dbl("rating", 0)
        if r == 0 { r = o.dbl("rating_5based", 0) * 2 }
        return min(10, max(0, r))
    }

    static func categories(_ data: Data?) -> [Category] {
        guard let d = data, let arr = JSON.parse(d) as? [Any] else { return [] }
        return arr.compactMap { $0 as? JObj }.compactMap { (o: JObj) -> Category? in
            let id = o.str("category_id")
            guard !id.isEmpty else { return nil }
            return Category(id: id, name: o.str("category_name", "Categoría").trimmed)
        }
    }

    static func live(_ data: Data?) -> [Channel] {
        guard let d = data, let arr = JSON.parse(d) as? [Any] else { return [] }
        var out: [Channel] = []
        out.reserveCapacity(arr.count)
        for case let o as JObj in arr {
            let id = o.str("stream_id")
            if id.isEmpty { continue }
            let name = o.str("name", "Canal").trimmed
            out.append(Channel(id: id, num: o.int("num", out.count + 1), name: name, icon: o.str("stream_icon"),
                               categoryId: o.str("category_id"), epgId: o.str("epg_channel_id"),
                               archive: o.int("tv_archive") == 1, direct: o.str("direct_source"), norm: Txt.norm(name)))
        }
        return out
    }

    static func vods(_ data: Data?) -> [Vod] {
        guard let d = data, let arr = JSON.parse(d) as? [Any] else { return [] }
        var out: [Vod] = []
        out.reserveCapacity(arr.count)
        for case let o as JObj in arr {
            let id = o.str("stream_id")
            if id.isEmpty { continue }
            var year = o.str("year")
            if year.isEmpty { year = o.str("releaseDate", o.str("releasedate")) }
            out.append(Vod(id: id, name: o.str("name", "Película").trimmed, icon: o.str("stream_icon"),
                           categoryId: o.str("category_id"), rating: rating(o), year: year,
                           genre: o.str("genre"), plot: o.str("plot"),
                           ext: o.str("container_extension", "mp4").nilIfEmpty ?? "mp4",
                           added: o.int64("added"), duration: o.str("duration")))
        }
        return out
    }

    static func series(_ data: Data?) -> [SeriesItem] {
        guard let d = data, let arr = JSON.parse(d) as? [Any] else { return [] }
        var out: [SeriesItem] = []
        out.reserveCapacity(arr.count)
        for case let o as JObj in arr {
            let id = o.str("series_id")
            if id.isEmpty { continue }
            var backdrop = ""
            if let b = o["backdrop_path"] as? [Any], let first = b.first as? String { backdrop = first }
            else { backdrop = o.str("backdrop_path") }
            var year = o.str("year")
            if year.isEmpty { year = o.str("releaseDate", o.str("release_date")) }
            out.append(SeriesItem(id: id, name: o.str("name", "Serie").trimmed, cover: o.str("cover"),
                                  categoryId: o.str("category_id"), rating: rating(o), year: year,
                                  genre: o.str("genre"), plot: o.str("plot"), backdrop: backdrop,
                                  added: o.int64("last_modified")))
        }
        return out
    }

    static func vodInfo(_ any: Any?) -> VodInfo {
        var v = VodInfo()
        guard let root = any as? JObj else { return v }
        let i = root.obj("info") ?? [:]
        v.plot = i.str("plot", i.str("description"))
        v.cast = i.str("cast", i.str("actors"))
        v.director = i.str("director")
        v.genre = i.str("genre")
        v.year = i.str("releasedate", i.str("release_date", i.str("year")))
        v.rating = i.dbl("rating", 0)
        v.duration = i.str("duration")
        if let b = i["backdrop_path"] as? [Any], let f = b.first as? String { v.backdrop = f } else { v.backdrop = i.str("backdrop_path") }
        v.cover = i.str("movie_image", i.str("cover_big"))
        v.trailer = i.str("youtube_trailer")
        v.ext = root.obj("movie_data")?.str("container_extension") ?? ""
        return v
    }

    static func seriesInfo(_ any: Any?) -> SeriesInfo {
        var s = SeriesInfo()
        guard let root = any as? JObj else { return s }
        let i = root.obj("info") ?? [:]
        s.plot = i.str("plot")
        s.cast = i.str("cast")
        s.genre = i.str("genre")
        s.year = i.str("releaseDate", i.str("release_date", i.str("year")))
        s.rating = i.dbl("rating", 0)
        if let b = i["backdrop_path"] as? [Any], let f = b.first as? String { s.backdrop = f } else { s.backdrop = i.str("backdrop_path") }
        s.cover = i.str("cover")
        s.trailer = i.str("youtube_trailer")
        var lists: [(String, [Any])] = []
        if let eps = root["episodes"] as? JObj {
            for (k, v) in eps { if let a = v as? [Any] { lists.append((k, a)) } }
        } else if let eps = root["episodes"] as? [Any] {
            for (n, v) in eps.enumerated() { if let a = v as? [Any] { lists.append(("\(n + 1)", a)) } }
        }
        for (key, list) in lists {
            for (n, any) in list.enumerated() {
                guard let e = any as? JObj else { continue }
                let id = e.str("id")
                if id.isEmpty { continue }
                let season = e.int("season", Int(key) ?? 1)
                let info = e.obj("info") ?? [:]
                let ep = Episode(id: id, season: season, number: e.int("episode_num", n + 1),
                                 title: e.str("title", "Episodio \(n + 1)"), image: info.str("movie_image", info.str("cover_big")),
                                 plot: info.str("plot"), duration: info.str("duration"),
                                 ext: e.str("container_extension", "mp4").nilIfEmpty ?? "mp4")
                s.seasons[season, default: []].append(ep)
            }
        }
        for k in s.seasons.keys { s.seasons[k]?.sort { $0.number < $1.number } }
        return s
    }

    static func epg(_ any: Any?) -> [EpgItem] {
        guard let root = any as? JObj else { return [] }
        let list = root.objs("epg_listings")
        let fmt = DateFormatter()
        fmt.locale = Locale(identifier: "en_US_POSIX")
        fmt.timeZone = TimeZone(identifier: "UTC")
        fmt.dateFormat = "yyyy-MM-dd HH:mm:ss"
        var out: [EpgItem] = []
        for (n, o) in list.enumerated() {
            var start = Date(timeIntervalSince1970: TimeInterval(o.int64("start_timestamp")))
            var end = Date(timeIntervalSince1970: TimeInterval(o.int64("stop_timestamp", o.int64("end_timestamp"))))
            if o.int64("start_timestamp") == 0, let d = fmt.date(from: o.str("start")) { start = d }
            if o.int64("stop_timestamp", o.int64("end_timestamp")) == 0, let d = fmt.date(from: o.str("end", o.str("stop"))) { end = d }
            let title = Txt.decodeBase64(o.str("title")).trimmed
            if title.isEmpty { continue }
            out.append(EpgItem(id: "\(o.str("id", "\(n)"))-\(Int(start.timeIntervalSince1970))", title: title,
                               desc: Txt.decodeBase64(o.str("description")).trimmed, start: start, end: end))
        }
        return out.filter { $0.end > Date() }.sorted { $0.start < $1.start }
    }
}

// MARK: - Peticiones Xtream

enum Xtream {
    static func fetch(_ creds: Creds, _ action: String, timeout: TimeInterval = 60) async throws -> Data {
        var lastError: Error = Http.Fail(code: -2)
        for wait in [0, 2, 5] {
            if wait > 0 { try? await Task.sleep(nanoseconds: UInt64(wait) * 1_000_000_000) }
            do {
                let url = creds.api(action) + "&_refresh=\(Int(Date().timeIntervalSince1970 * 1000))"
                let (raw, code) = try await Http.get(url, timeout: timeout,
                                                     headers: ["User-Agent": "PachecosTV/2.0", "Cache-Control": "no-cache, no-store", "Pragma": "no-cache"])
                if code == 429 || (500...599).contains(code) { lastError = Http.Fail(code: code); continue }
                guard (200..<300).contains(code) else { throw Http.Fail(code: code) }
                let d = JSON.stripBOM(raw)
                guard let first = d.first(where: { $0 > 32 }), first == UInt8(ascii: "[") || first == UInt8(ascii: "{") else {
                    throw Http.Fail(code: -3)
                }
                return d
            } catch let f as Http.Fail {
                if f.code >= 400 && f.code < 500 && f.code != 429 { throw f }
                lastError = f
            } catch {
                if (error as? URLError)?.code == .cancelled { throw error }
                lastError = error
            }
        }
        throw lastError
    }

    static func accountInfo(_ creds: Creds) async -> JObj? {
        guard let o = try? await Http.json(creds.api(), timeout: 15) as? JObj else { return nil }
        return o.obj("user_info")
    }

    static func vodInfo(_ creds: Creds, _ id: String) async -> VodInfo {
        let any = try? await Http.json(creds.api("get_vod_info&vod_id=\(Txt.query(id))"), timeout: 20)
        return XtreamParse.vodInfo(any)
    }

    static func seriesInfo(_ creds: Creds, _ id: String) async -> SeriesInfo {
        var servers = [creds.base]
        for s in creds.extraServers where !servers.contains(s) { servers.append(s) }
        for s in servers.prefix(3) {
            var c = creds
            c.server = s
            if let any = try? await Http.json(c.api("get_series_info&series_id=\(Txt.query(id))"), timeout: 20) {
                let info = XtreamParse.seriesInfo(any)
                if !info.seasons.isEmpty { return info }
            }
        }
        return SeriesInfo()
    }

    static func shortEpg(_ creds: Creds, _ streamId: String, limit: Int = 4) async -> [EpgItem] {
        let any = try? await Http.json(creds.api("get_short_epg&stream_id=\(Txt.query(streamId))&limit=\(limit)"), timeout: 12)
        return XtreamParse.epg(any)
    }
}

// MARK: - Direcciones de reproducción

enum LiveFormat: String, CaseIterable {
    case auto, hls, ts
    var title: String {
        switch self {
        case .auto: return "Automático"
        case .hls: return "HLS (.m3u8)"
        case .ts: return "MPEG-TS (.ts)"
        }
    }
}

enum Streams {
    static func servers(_ c: Creds) -> [String] {
        var out = [c.base]
        for s in c.extraServers {
            let b = s.trimmingCharacters(in: CharacterSet(charactersIn: "/ "))
            if !b.isEmpty && !out.contains(b) { out.append(b) }
        }
        return Array(out.prefix(3))
    }

    static func live(_ ch: Channel, _ c: Creds, format: LiveFormat) -> [String] {
        var out: [String] = []
        if !ch.direct.isEmpty && (ch.direct.hasPrefix("http://") || ch.direct.hasPrefix("https://")) && Endpoints.isOwnServer(c.base) {
            out.append(ch.direct)
        }
        let exts: [String]
        switch format {
        case .auto: exts = ["m3u8", "ts"]
        case .hls: exts = ["m3u8", "ts"]
        case .ts: exts = ["ts", "m3u8"]
        }
        for s in servers(c) {
            for e in exts {
                let u = "\(s)/live/\(Txt.path(c.user))/\(Txt.path(c.pass))/\(ch.id).\(e)"
                if !out.contains(u) { out.append(u) }
            }
        }
        return out
    }

    static func movie(_ id: String, ext: String, _ c: Creds) -> [String] {
        let e = ext.isEmpty ? "mp4" : ext
        return servers(c).map { "\($0)/movie/\(Txt.path(c.user))/\(Txt.path(c.pass))/\(id).\(e)" }
    }

    static func episode(_ ep: Episode, _ c: Creds) -> [String] {
        servers(c).map { "\($0)/series/\(Txt.path(c.user))/\(Txt.path(c.pass))/\(ep.id).\(ep.ext)" }
    }
}
