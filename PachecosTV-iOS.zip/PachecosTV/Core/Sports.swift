import Foundation

struct League: Hashable {
    let slug: String
    let sport: String
    let name: String
    let region: String
}

struct Team: Hashable {
    let id: String
    let name: String
    let short: String
    let logo: String
    let score: String
}

struct Match: Identifiable, Hashable {
    let id: String
    let league: League
    let leagueLogo: String
    let start: Date
    let state: String
    let detail: String
    let clock: String
    let home: Team
    let away: Team
    let tv: [String]

    var live: Bool { state == "in" }
    var finished: Bool { state == "post" }
    var title: String { "\(home.name) vs \(away.name)" }
}

enum Sports {
    static let leagues: [League] = [
        League(slug: "mex.1", sport: "soccer", name: "Liga MX", region: "México"),
        League(slug: "mex.2", sport: "soccer", name: "Liga de Expansión MX", region: "México"),
        League(slug: "concacaf.champions", sport: "soccer", name: "Concacaf Champions Cup", region: "Norteamérica"),
        League(slug: "usa.1", sport: "soccer", name: "MLS", region: "Norteamérica"),
        League(slug: "uefa.champions", sport: "soccer", name: "UEFA Champions League", region: "Europa"),
        League(slug: "uefa.europa", sport: "soccer", name: "UEFA Europa League", region: "Europa"),
        League(slug: "uefa.europa.conf", sport: "soccer", name: "UEFA Conference League", region: "Europa"),
        League(slug: "eng.1", sport: "soccer", name: "Premier League", region: "Europa"),
        League(slug: "esp.1", sport: "soccer", name: "LaLiga", region: "Europa"),
        League(slug: "ita.1", sport: "soccer", name: "Serie A", region: "Europa"),
        League(slug: "ger.1", sport: "soccer", name: "Bundesliga", region: "Europa"),
        League(slug: "fra.1", sport: "soccer", name: "Ligue 1", region: "Europa"),
        League(slug: "por.1", sport: "soccer", name: "Liga Portugal", region: "Europa"),
        League(slug: "conmebol.libertadores", sport: "soccer", name: "Copa Libertadores", region: "Sudamérica"),
        League(slug: "conmebol.sudamericana", sport: "soccer", name: "Copa Sudamericana", region: "Sudamérica"),
        League(slug: "arg.1", sport: "soccer", name: "Liga Profesional Argentina", region: "Sudamérica"),
        League(slug: "bra.1", sport: "soccer", name: "Brasileirão", region: "Sudamérica"),
        League(slug: "col.1", sport: "soccer", name: "Liga BetPlay", region: "Sudamérica"),
        League(slug: "fifa.friendly", sport: "soccer", name: "Amistosos internacionales", region: "Internacional"),
        League(slug: "concacaf.nations.league", sport: "soccer", name: "Concacaf Nations League", region: "Norteamérica"),
        League(slug: "concacaf.gold", sport: "soccer", name: "Copa Oro Concacaf", region: "Norteamérica"),
        League(slug: "concacaf.leagues.cup", sport: "soccer", name: "Leagues Cup", region: "Norteamérica"),
        League(slug: "fifa.worldq.concacaf", sport: "soccer", name: "Eliminatorias Concacaf", region: "Norteamérica"),
        League(slug: "uefa.nations", sport: "soccer", name: "UEFA Nations League", region: "Europa"),
        League(slug: "fifa.worldq.uefa", sport: "soccer", name: "Eliminatorias UEFA", region: "Europa"),
        League(slug: "conmebol.america", sport: "soccer", name: "Copa América", region: "Sudamérica"),
        League(slug: "fifa.worldq.conmebol", sport: "soccer", name: "Eliminatorias Conmebol", region: "Sudamérica"),
        League(slug: "fifa.world", sport: "soccer", name: "Copa Mundial FIFA", region: "Internacional"),
        League(slug: "fifa.cwc", sport: "soccer", name: "Mundial de Clubes FIFA", region: "Internacional"),
        League(slug: "esp.copa_del_rey", sport: "soccer", name: "Copa del Rey", region: "Europa"),
        League(slug: "eng.fa", sport: "soccer", name: "FA Cup", region: "Europa"),
        League(slug: "eng.league_cup", sport: "soccer", name: "Carabao Cup", region: "Europa"),
        League(slug: "ita.coppa_italia", sport: "soccer", name: "Coppa Italia", region: "Europa"),
        League(slug: "ger.dfb_pokal", sport: "soccer", name: "DFB Pokal", region: "Europa"),
        League(slug: "eng.2", sport: "soccer", name: "Championship", region: "Europa"),
        League(slug: "ned.1", sport: "soccer", name: "Eredivisie", region: "Europa"),
        League(slug: "sau.1", sport: "soccer", name: "Liga Saudí", region: "Internacional"),
        League(slug: "chi.1", sport: "soccer", name: "Primera Chile", region: "Sudamérica"),
        League(slug: "per.1", sport: "soccer", name: "Liga 1 Perú", region: "Sudamérica"),
        League(slug: "ecu.1", sport: "soccer", name: "LigaPro Ecuador", region: "Sudamérica"),
        League(slug: "uru.1", sport: "soccer", name: "Primera Uruguay", region: "Sudamérica"),
        League(slug: "wnba", sport: "basketball", name: "WNBA", region: "Norteamérica"),
        League(slug: "nfl", sport: "football", name: "NFL", region: "Norteamérica"),
        League(slug: "nba", sport: "basketball", name: "NBA", region: "Norteamérica"),
        League(slug: "mlb", sport: "baseball", name: "MLB", region: "Norteamérica"),
        League(slug: "nhl", sport: "hockey", name: "NHL", region: "Norteamérica"),
        League(slug: "college-football", sport: "football", name: "NCAA Football", region: "Norteamérica"),
        League(slug: "ufc", sport: "mma", name: "UFC", region: "Internacional")
    ]

    private static let base = "https://site.api.espn.com/apis/site/v2/sports"

    static func dayKey(_ d: Date) -> String {
        let f = DateFormatter()
        f.locale = Locale(identifier: "en_US_POSIX")
        f.dateFormat = "yyyyMMdd"
        return f.string(from: d)
    }

    private static func parseDate(_ s: String) -> Date? {
        for p in ["yyyy-MM-dd'T'HH:mm'Z'", "yyyy-MM-dd'T'HH:mm:ss'Z'", "yyyy-MM-dd'T'HH:mmZ"] {
            let f = DateFormatter()
            f.locale = Locale(identifier: "en_US_POSIX")
            f.timeZone = TimeZone(identifier: "UTC")
            f.dateFormat = p
            if let d = f.date(from: s) { return d }
        }
        return nil
    }

    /// Partidos del día (hora del teléfono) de todas las ligas.
    static func matches(day: Date) async -> [Match] {
        let cal = Calendar.current
        let from = cal.startOfDay(for: day)
        let to = cal.date(byAdding: .day, value: 1, to: from) ?? from.addingTimeInterval(86400)
        let keys = Array(Set([dayKey(from.addingTimeInterval(-12 * 3600)), dayKey(from.addingTimeInterval(12 * 3600)), dayKey(to.addingTimeInterval(12 * 3600))]))
        var jobs: [(League, String)] = []
        for k in keys { for l in leagues { jobs.append((l, k)) } }
        let all = await withTaskGroup(of: [Match].self, returning: [Match].self) { group in
            var acc: [Match] = []
            var index = 0
            while index < min(16, jobs.count) {
                let job = jobs[index]
                group.addTask { await Sports.league(job.0, job.1) }
                index += 1
            }
            while let r = await group.next() {
                acc.append(contentsOf: r)
                if index < jobs.count {
                    let job = jobs[index]
                    group.addTask { await Sports.league(job.0, job.1) }
                    index += 1
                }
            }
            return acc
        }
        var seen = Set<String>()
        let order = Dictionary(uniqueKeysWithValues: leagues.enumerated().map { ($0.element.slug, $0.offset) })
        return all.filter { $0.start >= from && $0.start < to }
            .filter { seen.insert($0.league.sport + ":" + $0.id).inserted && seen.insert(Txt.norm($0.home.name) + "|" + Txt.norm($0.away.name)).inserted }
            .sorted {
                if $0.live != $1.live { return $0.live }
                if $0.start != $1.start { return $0.start < $1.start }
                return (order[$0.league.slug] ?? 99) < (order[$1.league.slug] ?? 99)
            }
    }

    private static func league(_ lg: League, _ day: String) async -> [Match] {
        var url = "\(base)/\(lg.sport)/\(lg.slug)/scoreboard?dates=\(day)"
        if lg.slug == "college-football" { url += "&groups=80&limit=400" }
        guard let o = try? await Http.json(url, timeout: 15) as? JObj else { return [] }
        let logo = o.objs("leagues").first?.objs("logos").first?.str("href") ?? ""
        var out: [Match] = []
        for ev in o.objs("events") {
            let comps = ev.objs("competitions")
            for (ci, comp) in comps.enumerated() {
                let status = comp.obj("status") ?? ev.obj("status") ?? [:]
                let type = status.obj("type") ?? [:]
                var home: Team?
                var away: Team?
                for t in comp.objs("competitors") {
                    let team = t.obj("team")
                    let ath = t.obj("athlete")
                    let name = team?.str("displayName").nilIfEmpty ?? ath?.str("displayName").nilIfEmpty ?? "?"
                    let short = team?.str("shortDisplayName").nilIfEmpty ?? name
                    let tlogo = team?.str("logo").nilIfEmpty ?? team?.objs("logos").first?.str("href").nilIfEmpty ?? ath?.obj("flag")?.str("href") ?? ""
                    let tm = Team(id: team?.str("id") ?? t.str("id"), name: name, short: short, logo: tlogo, score: t.str("score"))
                    if t.str("homeAway") == "away" { away = tm } else if home == nil { home = tm } else { away = tm }
                }
                guard let h = home, let a = away else { continue }
                var tv: [String] = []
                for b in comp.objs("broadcasts") {
                    for n in b.arr("names") { if let s = n as? String, !s.isEmpty, !tv.contains(s) { tv.append(s) } }
                }
                for g in comp.objs("geoBroadcasts") {
                    if let s = g.obj("media")?.str("shortName"), !s.isEmpty, !tv.contains(s) { tv.append(s) }
                }
                let dateStr = comp.str("date").nilIfEmpty ?? ev.str("date")
                guard let start = parseDate(dateStr) else { continue }
                let id = comps.count > 1 ? (comp.str("id").nilIfEmpty ?? "\(ev.str("id"))_\(ci)") : ev.str("id")
                out.append(Match(id: id, league: lg, leagueLogo: logo, start: start, state: type.str("state", "pre"),
                                 detail: type.str("shortDetail").nilIfEmpty ?? type.str("detail"), clock: status.str("displayClock"),
                                 home: h, away: a, tv: tv))
            }
        }
        return out
    }

    // MARK: Canales que transmiten el partido

    private static let generic: Set<String> = ["club", "deportivo", "atletico", "athletic", "united", "city", "real", "sporting",
                                               "fc", "cf", "sc", "ac", "cd", "de", "la", "el", "los", "las", "del", "fc.", "the",
                                               "team", "futbol", "football", "calcio", "sport", "sports", "unam", "cf."]

    static func teamKeys(_ t: Team) -> [String] {
        var keys = Set<String>()
        for source in [t.name, t.short] {
            for w in Txt.words(source) where w.count >= 4 && !generic.contains(w) { keys.insert(w) }
        }
        if keys.isEmpty, let w = Txt.words(t.short).max(by: { $0.count < $1.count }), w.count >= 3 { keys.insert(w) }
        return Array(keys)
    }

    static func channels(for m: Match, in live: [Channel]) -> [Channel] {
        let hk = teamKeys(m.home), ak = teamKeys(m.away)
        guard !hk.isEmpty, !ak.isEmpty else { return [] }
        func hasWord(_ text: String, _ keys: [String]) -> Bool {
            let words = Set(text.components(separatedBy: CharacterSet.alphanumerics.inverted))
            return keys.contains { words.contains($0) }
        }
        return Array(live.filter { hasWord($0.norm, hk) && hasWord($0.norm, ak) && !KidsFilter.esAdulto($0.name) }.prefix(20))
    }

    /// Canales de las cadenas que reporta ESPN (ESPN, TUDN, Fox Sports…).
    static func networkChannels(for m: Match, in live: [Channel]) -> [Channel] {
        let nets = m.tv.map { Txt.norm($0).trimmed }.filter { $0.count >= 3 }
        guard !nets.isEmpty else { return [] }
        let vs = try? NSRegularExpression(pattern: "\\b(vs|v|x)\\b")
        var out: [Channel] = []
        for ch in live {
            if KidsFilter.esAdulto(ch.name) { continue }
            if let r = vs, r.firstMatch(in: ch.norm, range: NSRange(ch.norm.startIndex..., in: ch.norm)) != nil { continue }
            let clean = ch.norm.replacingOccurrences(of: "[^a-z0-9 ]", with: " ", options: .regularExpression)
                .components(separatedBy: " ").filter { !$0.isEmpty && !["hd", "fhd", "sd", "4k", "mx", "us", "usa", "latam", "mex"].contains($0) }
                .joined(separator: " ")
            if nets.contains(where: { clean == $0 || (clean.hasPrefix($0 + " ") && clean.count <= $0.count + 4) }) { out.append(ch) }
            if out.count >= 12 { break }
        }
        return out
    }
}
