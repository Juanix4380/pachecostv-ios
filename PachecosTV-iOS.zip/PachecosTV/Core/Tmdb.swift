import Foundation

struct TmdbCast: Identifiable, Hashable {
    let id: Int
    let name: String
    let character: String
    let photo: String
}

struct TmdbInfo: Hashable {
    let id: Int
    let title: String
    let year: String
    let rating: Double
    let genres: String
    let overview: String
    let backdrop: String
    let poster: String
    let cast: [TmdbCast]
    let runtime: Int
}

struct TmdbUpcoming: Identifiable, Hashable {
    let id: Int
    let title: String
    let date: String
    let overview: String
    let poster: String
    let backdrop: String
}

actor TmdbCache {
    static let shared = TmdbCache()
    private var infos: [String: TmdbInfo?] = [:]
    private var logos: [String: String] = [:]
    private var upcoming: (Date, [TmdbUpcoming])?

    func info(_ k: String) -> TmdbInfo?? { infos[k] }
    func setInfo(_ k: String, _ v: TmdbInfo?) { infos[k] = v }
    func logo(_ k: String) -> String? { logos[k] }
    func setLogo(_ k: String, _ v: String) { logos[k] = v }
    func upcomingList() -> [TmdbUpcoming]? {
        guard let u = upcoming, Date().timeIntervalSince(u.0) < 6 * 3600 else { return nil }
        return u.1
    }
    func setUpcoming(_ v: [TmdbUpcoming]) { upcoming = (Date(), v) }
}

enum Tmdb {
    private static let key = "81fddc0ae6b0154bd90860ce58be4e8e"
    private static let base = "https://api.themoviedb.org/3"
    static let poster = "https://image.tmdb.org/t/p/w342"
    static let backdropBase = "https://image.tmdb.org/t/p/w1280"
    static let face = "https://image.tmdb.org/t/p/w185"
    private static let lang = "es-MX"

    private static func img(_ base: String, _ path: String) -> String {
        path.isEmpty || path == "null" ? "" : base + path
    }

    static func info(title raw: String, series: Bool) async -> TmdbInfo? {
        let k = "\(series)|\(raw)"
        if let cached = await TmdbCache.shared.info(k) { return cached }
        let result = await fetchInfo(raw, series)
        await TmdbCache.shared.setInfo(k, result)
        return result
    }

    private static func fetchInfo(_ raw: String, _ series: Bool) async -> TmdbInfo? {
        let q = TitleClean.clean(raw)
        guard !q.isEmpty else { return nil }
        let type = series ? "tv" : "movie"
        var url = "\(base)/search/\(type)?api_key=\(key)&language=\(lang)&query=\(Txt.query(q))"
        if let y = Txt.year(raw) { url += series ? "&first_air_date_year=\(y)" : "&year=\(y)" }
        guard let s = try? await Http.json(url, timeout: 9) as? JObj,
              let first = s.objs("results").first else { return nil }
        let id = first.int("id", -1)
        guard id > 0, let o = try? await Http.json("\(base)/\(type)/\(id)?api_key=\(key)&language=\(lang)&append_to_response=credits", timeout: 9) as? JObj else { return nil }
        let genres = o.objs("genres").map { $0.str("name") }.filter { !$0.isEmpty }.prefix(3).joined(separator: " · ")
        let cast = (o.obj("credits")?.objs("cast") ?? []).prefix(15).map {
            TmdbCast(id: $0.int("id"), name: $0.str("name"), character: $0.str("character"), photo: img(face, $0.str("profile_path")))
        }
        let date = o.str(series ? "first_air_date" : "release_date")
        var runtime = o.int("runtime")
        if runtime == 0, let r = o["episode_run_time"] as? [Any], let f = r.first as? NSNumber { runtime = f.intValue }
        return TmdbInfo(id: id, title: o.str(series ? "name" : "title"), year: String(date.prefix(4)),
                        rating: o.dbl("vote_average"), genres: genres, overview: o.str("overview"),
                        backdrop: img(backdropBase, o.str("backdrop_path")), poster: img(poster, o.str("poster_path")),
                        cast: Array(cast), runtime: runtime)
    }

    /// Logo del título (PNG transparente) en español o inglés.
    static func logo(id: Int, series: Bool) async -> String {
        let k = "\(series)|\(id)"
        if let c = await TmdbCache.shared.logo(k) { return c }
        var chosen = ""
        let type = series ? "tv" : "movie"
        if let o = try? await Http.json("\(base)/\(type)/\(id)/images?api_key=\(key)&include_image_language=es,en,null", timeout: 9) as? JObj {
            let logos = o.objs("logos")
            for lang in ["es", "en"] where chosen.isEmpty {
                if let l = logos.first(where: { $0.str("iso_639_1") == lang && !$0.str("file_path").hasSuffix(".svg") }) {
                    chosen = "https://image.tmdb.org/t/p/w500" + l.str("file_path")
                }
            }
        }
        await TmdbCache.shared.setLogo(k, chosen)
        return chosen
    }

    static func upcoming() async -> [TmdbUpcoming] {
        if let c = await TmdbCache.shared.upcomingList() { return c }
        guard let o = try? await Http.json("\(base)/movie/upcoming?api_key=\(key)&language=\(lang)&region=MX&page=1", timeout: 10) as? JObj else { return [] }
        let today = String(ISO8601DateFormatter().string(from: Date()).prefix(10))
        let list = o.objs("results").compactMap { r -> TmdbUpcoming? in
            let date = r.str("release_date")
            let poster = r.str("poster_path")
            guard !poster.isEmpty, date >= today else { return nil }
            return TmdbUpcoming(id: r.int("id"), title: r.str("title"), date: date, overview: r.str("overview"),
                                poster: img(Tmdb.poster, poster), backdrop: img(backdropBase, r.str("backdrop_path")))
        }.sorted { $0.date < $1.date }
        await TmdbCache.shared.setUpcoming(list)
        return list
    }

    static func trailerKey(id: Int, series: Bool) async -> String? {
        let type = series ? "tv" : "movie"
        for l in ["es-MX", "es-ES", "en-US"] {
            guard let o = try? await Http.json("\(base)/\(type)/\(id)/videos?api_key=\(key)&language=\(l)", timeout: 9) as? JObj else { continue }
            let vids = o.objs("results").filter { $0.str("site") == "YouTube" }
            if let t = vids.first(where: { $0.str("type") == "Trailer" }) ?? vids.first { return t.str("key") }
        }
        return nil
    }

    static func shortDate(_ iso: String) -> String {
        let parts = iso.split(separator: "-")
        guard parts.count == 3 else { return iso }
        let months = ["ene", "feb", "mar", "abr", "may", "jun", "jul", "ago", "sep", "oct", "nov", "dic"]
        let m = (Int(parts[1]) ?? 1) - 1
        return "\(Int(parts[2]) ?? 1) \(months[max(0, min(11, m))])"
    }
}
