import Foundation

/// Filtro único del perfil Kids (mismas reglas que Android).
enum KidsFilter {
    private static func rx(_ t: String) -> NSRegularExpression {
        // swiftlint:disable:next force_try
        try! NSRegularExpression(pattern: "(?:^|[^a-z0-9])(?:\(t))(?:$|[^a-z0-9])")
    }

    private static func has(_ r: NSRegularExpression, _ s: String) -> Bool {
        r.firstMatch(in: s, options: [], range: NSRange(s.startIndex..., in: s)) != nil
    }

    private static let categoria = rx(
        "kids|kid|infantil|infantiles|ninos|ninas|nino|nina|children|childrens|child|" +
        "preescolar|preschool|caricatura|caricaturas|cartoon|cartoons|toons|toon|" +
        "dibujos|dibujos animados|animadas|animados|animacion infantil|" +
        "familiar|familiares|family|en familia|para toda la familia|" +
        "disney|disney junior|disney channel|pixar|dreamworks|illumination|nickelodeon|nick|nick jr|" +
        "cartoon network|cartoonito|boomerang|discovery kids|baby tv|babytv|pbs kids|" +
        "tooncast|zoomoo|duck tv|paka paka|peques|pequenos|bebes|baby|" +
        "educativo|educativos|educativa|educativas|aprende|cuentos")

    private static let canales = rx(
        "disney|disney junior|disney channel|disney jr|nickelodeon|nick|nick jr|nicktoons|" +
        "cartoon network|cartoonito|boomerang|discovery kids|baby tv|babytv|baby first|babyfirst|" +
        "pbs kids|tooncast|clan|zoomoo|duck tv|paka paka|kids|kid|infantil|junior|toons|" +
        "baby shark|cocomelon|pocoyo|peppa|paw patrol|patrulla canina|bluey")

    private static let genero = rx("familia|family|infantil|kids|ninos|children")

    private static let titulos = rx(
        "paw patrol|patrulla canina|peppa|bluey|dora la exploradora|dora the explorer|mickey|minnie|" +
        "toy story|frozen|moana|encanto|zootopia|cars 2|cars 3|buscando a nemo|finding nemo|finding dory|" +
        "buscando a dory|monsters inc|monsters university|intensamente|inside out|minions|mi villano favorito|" +
        "despicable me|kung fu panda|madagascar|shrek|trolls|como entrenar a tu dragon|how to train your dragon|" +
        "pocoyo|cocomelon|bob esponja|spongebob|spidey|pj masks|heroes en pijamas|masha|super mario|sonic the hedgehog|lilo|" +
        "stitch|winnie|barbie|polly pocket|my little pony|princesa sofia|sofia the first|wall e|ratatouille|" +
        "los increibles|the incredibles|bichos|a bugs life|valiente|brave|enredados|tangled|la sirenita|" +
        "little mermaid|el rey leon|the lion king|aladdin|la bella y la bestia|beauty and the beast|" +
        "cenicienta|cinderella|blancanieves|snow white|pinocho|pinocchio|dumbo|bambi|el libro de la selva|" +
        "jungle book|hotel transylvania|hotel transilvania|la era de hielo|ice age|los pitufos|the smurfs|" +
        "paddington|garfield|scooby doo|tom y jerry|tom and jerry|looney tunes|el principito|baby shark|" +
        "lego|pokemon|doraemon|hey duggee|daniel tigre|daniel tiger|plaza sesamo|sesame street|barney|" +
        "teletubbies|thomas y sus amigos|thomas and friends|caillou|clifford|octonautas|octonauts|" +
        "jorge el curioso|curious george|robocar|super wings|ladybug|miraculous|gabby|la casa de munecas de gabby|" +
        "chip y dale|patoaventuras|ducktales|phineas y ferb|phineas and ferb|gravity falls|el increible mundo de gumball|" +
        "gumball|hora de aventura|adventure time|steven universe|las chicas superpoderosas|powerpuff|ben 10|" +
        "los padrinos magicos|fairly oddparents|jimmy neutron|rugrats|hey arnold|oye arnold|wild kratts|" +
        "aventuras con los kratt|tortugas ninja|ninja turtles|pinguinos de madagascar|penguins of madagascar|" +
        "boss baby|bebe jefazo|ven y canta|secret life of pets|la vida secreta de tus mascotas|elemental|" +
        "turning red|red el despertar|el gato con botas|puss in boots|los croods|the croods|" +
        "abominable|megamente|megamind|wreck it ralph|ralph el demoledor|big hero 6|grandes heroes|" +
        "mi pequeno pony|caballeros del zodiaco infantil")

    private static let prohibidoRx = rx(
        "adult|adults|adulto|adultos|adulta|adultas|xxx|18|18\\+|\\+18|hentai|ecchi|erotico|erotica|eroticas|" +
        "porn|porno|sexo|sex|sexy|hot|desnudo|desnuda|playboy|hustler|onlyfans|" +
        "terror|horror|miedo|gore|slasher|zombie|zombies|sangre|blood|exorcismo|exorcist|demonio|demonios|" +
        "thriller|suspenso|suspense|psicologico|crimen|crime|criminal|narco|narcos|mafia|cartel|gangster|" +
        "drogas|drugs|violencia|violento|guerra|war|belica|belicas|asesino|asesinos|asesinato|killer|" +
        "serial|true crime|policiaco|policiacas|carcel|prison|noticias|news|deportes|sports|futbol|" +
        "casino|apuestas|reality|lucha libre|wwe|ufc|box|boxeo|" +
        "south park|family guy|padre de familia|american dad|rick and morty|rick y morty|bojack|big mouth|" +
        "happy tree friends|sausage party|fiesta de las salchichas|beavis|archer|the boys|invincible|" +
        "invencible|castlevania|arcane|cyberpunk|devilman|berserk|tokyo ghoul|attack on titan|shingeki|" +
        "chainsaw man|jujutsu|demon slayer|kimetsu|death note|akira|perfect blue|seinen|harley quinn|" +
        "deadpool|joker|venom|the walking dead|anime adulto|stand up|comedia adulta")

    private static let adulto = rx("adult|adults|adulto|adultos|adulta|adultas|xxx|18\\+|\\+18|porn|porno|erotic|erotico|erotica|hentai|playboy|onlyfans|sexo|sex|hot")

    static func prohibido(_ textos: String...) -> Bool { textos.contains { has(prohibidoRx, Txt.norm($0)) } }

    static func categoriaInfantil(_ nombre: String) -> Bool {
        let n = Txt.norm(nombre)
        return has(categoria, n) && !has(prohibidoRx, n)
    }

    static func contenidoPermitido(nombre: String, genero g: String, categoria cat: String) -> Bool {
        if prohibido(nombre, g, cat) { return false }
        return categoriaInfantil(cat) || has(titulos, Txt.norm(nombre)) || has(genero, Txt.norm(g))
    }

    static func canalPermitido(nombre: String, categoria cat: String) -> Bool {
        if prohibido(nombre, cat) { return false }
        return categoriaInfantil(cat) || has(canales, Txt.norm(nombre))
    }

    /// Contenido para adultos (se oculta de Inicio y pide contraseña en TV en vivo).
    static func esAdulto(_ texto: String) -> Bool { has(adulto, Txt.norm(texto)) }
}

/// Limpieza de títulos del panel (mismo criterio que TmdbPacheco en Android).
enum TitleClean {
    private static func re(_ p: String, _ o: NSRegularExpression.Options = []) -> NSRegularExpression {
        // swiftlint:disable:next force_try
        try! NSRegularExpression(pattern: p, options: o)
    }
    private static let steps: [(NSRegularExpression, String)] = [
        (re("\\[[^\\]]*\\]"), " "),
        (re("\\([^)]*\\)"), " "),
        (re("^[A-Z]{2,3}\\s*[|:-]\\s*"), " "),
        (re("\\b(4k|uhd|fhd|hd|sd|1080p?|720p?|480p?|hevc|x264|x265|dual|latino|castellano|espanol|español|sub|subtitulado|vose|web-?dl|bluray|hdrip|dvdrip|cam|multi|ac3|aac)\\b", [.caseInsensitive]), " "),
        (re("[Ss]\\d{1,2}\\s?[EeXx]\\d{1,3}.*"), " "),
        (re("(?<![0-9])(19|20)\\d{2}(?![0-9])"), " "),
        (re("[._|]+"), " "),
        (re("\\s+-\\s+.*$"), " "),
        (re("\\s+"), " ")
    ]

    static func clean(_ raw: String) -> String {
        var t = raw
        for (r, w) in steps {
            t = r.stringByReplacingMatches(in: t, options: [], range: NSRange(t.startIndex..., in: t), withTemplate: w)
        }
        return t.trimmed
    }
}
