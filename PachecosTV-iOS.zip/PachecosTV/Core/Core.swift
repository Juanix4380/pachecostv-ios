import Foundation
import UIKit
import CryptoKit

// MARK: - Direcciones del servicio (mismas que la app Android)

enum Endpoints {
    static let cloud = "https://martineztvxtream.com/cloud"
    static let login = cloud + "/login"
    static let sessionStatus = cloud + "/session/status"
    static let logout = cloud + "/logout"
    static let ownServer = "https://tv.martineztvxtream.com"
    static let whatsapp = "15593834323"

    static func isOwnServer(_ s: String) -> Bool {
        s.trimmingCharacters(in: .whitespaces).trimmingCharacters(in: CharacterSet(charactersIn: "/")).lowercased() == ownServer
    }
}

// MARK: - JSON

typealias JObj = [String: Any]

extension Dictionary where Key == String, Value == Any {
    func str(_ k: String, _ def: String = "") -> String {
        guard let v = self[k] else { return def }
        if v is NSNull { return def }
        if let s = v as? String { return s }
        if let n = v as? NSNumber { return n.stringValue }
        return def
    }
    func int(_ k: String, _ def: Int = 0) -> Int {
        guard let v = self[k] else { return def }
        if let n = v as? NSNumber { return n.intValue }
        if let s = v as? String {
            if let i = Int(s.trimmingCharacters(in: .whitespaces)) { return i }
            if let d = Double(s.trimmingCharacters(in: .whitespaces)) { return Int(d) }
        }
        return def
    }
    func int64(_ k: String, _ def: Int64 = 0) -> Int64 {
        guard let v = self[k] else { return def }
        if let n = v as? NSNumber { return n.int64Value }
        if let s = v as? String {
            if let i = Int64(s.trimmingCharacters(in: .whitespaces)) { return i }
            if let d = Double(s.trimmingCharacters(in: .whitespaces)) { return Int64(d) }
        }
        return def
    }
    func dbl(_ k: String, _ def: Double = 0) -> Double {
        guard let v = self[k] else { return def }
        if let n = v as? NSNumber { return n.doubleValue }
        if let s = v as? String, let d = Double(s.replacingOccurrences(of: ",", with: ".")) { return d }
        return def
    }
    func bool(_ k: String, _ def: Bool = false) -> Bool {
        guard let v = self[k] else { return def }
        if let n = v as? NSNumber { return n.boolValue }
        if let s = v as? String { return ["true", "1", "yes"].contains(s.lowercased()) }
        return def
    }
    func obj(_ k: String) -> JObj? { self[k] as? JObj }
    func arr(_ k: String) -> [Any] { (self[k] as? [Any]) ?? [] }
    func objs(_ k: String) -> [JObj] { ((self[k] as? [Any]) ?? []).compactMap { $0 as? JObj } }
}

enum JSON {
    static func stripBOM(_ d: Data) -> Data {
        d.starts(with: [0xEF, 0xBB, 0xBF]) ? Data(d.dropFirst(3)) : d
    }

    /// Tolerante: quita BOM y repara texto con caracteres inválidos (como hace Android).
    static func parse(_ data: Data) -> Any? {
        let d = stripBOM(data)
        if let o = try? JSONSerialization.jsonObject(with: d, options: [.fragmentsAllowed]) { return o }
        let repaired = String(decoding: d, as: UTF8.self)
        if let d2 = repaired.data(using: .utf8), let o = try? JSONSerialization.jsonObject(with: d2, options: [.fragmentsAllowed]) { return o }
        if let latin = String(data: d, encoding: .isoLatin1), let d3 = latin.data(using: .utf8) {
            return try? JSONSerialization.jsonObject(with: d3, options: [.fragmentsAllowed])
        }
        return nil
    }
    static func parse(_ text: String) -> Any? {
        guard let d = text.data(using: .utf8) else { return nil }
        return parse(d)
    }
    static func string(_ obj: Any) -> String {
        guard JSONSerialization.isValidJSONObject(obj),
              let d = try? JSONSerialization.data(withJSONObject: obj, options: []) else { return "{}" }
        return String(data: d, encoding: .utf8) ?? "{}"
    }
}

// MARK: - Red

enum Http {
    struct Fail: Error { let code: Int }

    static let session: URLSession = {
        let c = URLSessionConfiguration.default
        c.timeoutIntervalForRequest = 40
        c.timeoutIntervalForResource = 900
        c.requestCachePolicy = .reloadIgnoringLocalCacheData
        c.urlCache = nil
        c.httpMaximumConnectionsPerHost = 8
        return URLSession(configuration: c)
    }()

    static func get(_ url: String, timeout: TimeInterval = 25, headers: [String: String] = [:]) async throws -> (Data, Int) {
        guard let u = URL(string: url) else { throw Fail(code: -1) }
        var r = URLRequest(url: u, cachePolicy: .reloadIgnoringLocalCacheData, timeoutInterval: timeout)
        r.setValue("application/json, */*", forHTTPHeaderField: "Accept")
        for (k, v) in headers { r.setValue(v, forHTTPHeaderField: k) }
        let (d, resp) = try await session.data(for: r)
        return (d, (resp as? HTTPURLResponse)?.statusCode ?? 0)
    }

    static func getOK(_ url: String, timeout: TimeInterval = 25, headers: [String: String] = [:]) async throws -> Data {
        let (d, code) = try await get(url, timeout: timeout, headers: headers)
        guard (200..<300).contains(code) else { throw Fail(code: code) }
        return d
    }

    static func json(_ url: String, timeout: TimeInterval = 25, headers: [String: String] = [:]) async throws -> Any {
        let d = try await getOK(url, timeout: timeout, headers: headers)
        guard let o = JSON.parse(d) else { throw Fail(code: -2) }
        return o
    }

    static func post(_ url: String, json: JObj, headers: [String: String] = [:], timeout: TimeInterval = 20) async throws -> (Any?, Int) {
        guard let u = URL(string: url) else { throw Fail(code: -1) }
        var r = URLRequest(url: u, cachePolicy: .reloadIgnoringLocalCacheData, timeoutInterval: timeout)
        r.httpMethod = "POST"
        r.setValue("application/json; charset=UTF-8", forHTTPHeaderField: "Content-Type")
        r.setValue("application/json", forHTTPHeaderField: "Accept")
        for (k, v) in headers { r.setValue(v, forHTTPHeaderField: k) }
        r.httpBody = try JSONSerialization.data(withJSONObject: json, options: [])
        let (d, resp) = try await session.data(for: r)
        return (JSON.parse(d), (resp as? HTTPURLResponse)?.statusCode ?? 0)
    }
}

// MARK: - Preferencias (equivalente a SharedPreferences, mismas claves que Android)

final class Prefs {
    private static var registry: [String: Prefs] = [:]
    private static let regLock = NSLock()

    static let dir: URL = {
        let base = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("prefs", isDirectory: true)
        try? FileManager.default.createDirectory(at: base, withIntermediateDirectories: true)
        return base
    }()

    static func named(_ name: String) -> Prefs {
        regLock.lock(); defer { regLock.unlock() }
        if let p = registry[name] { return p }
        let p = Prefs(name: name)
        registry[name] = p
        return p
    }

    let name: String
    private var dict: JObj
    private let lock = NSLock()
    private let url: URL

    private init(name: String) {
        self.name = name
        let safe = name.addingPercentEncoding(withAllowedCharacters: .alphanumerics) ?? name
        url = Prefs.dir.appendingPathComponent(safe + ".plist")
        if let data = try? Data(contentsOf: url),
           let obj = (try? PropertyListSerialization.propertyList(from: data, options: [], format: nil)) as? JObj {
            dict = obj
        } else {
            dict = [:]
        }
    }

    var all: JObj { lock.lock(); defer { lock.unlock() }; return dict }

    func get(_ k: String) -> Any? { lock.lock(); defer { lock.unlock() }; return dict[k] }
    func has(_ k: String) -> Bool { get(k) != nil }
    func str(_ k: String, _ def: String = "") -> String { (get(k) as? String) ?? def }
    func int(_ k: String, _ def: Int = 0) -> Int {
        if let n = get(k) as? NSNumber { return n.intValue }
        if let s = get(k) as? String, let i = Int(s) { return i }
        return def
    }
    func int64(_ k: String, _ def: Int64 = 0) -> Int64 {
        if let n = get(k) as? NSNumber { return n.int64Value }
        if let s = get(k) as? String, let i = Int64(s) { return i }
        return def
    }
    func bool(_ k: String, _ def: Bool = false) -> Bool {
        if let n = get(k) as? NSNumber { return n.boolValue }
        return def
    }
    func stringSet(_ k: String) -> Set<String> {
        if let a = get(k) as? [Any] { return Set(a.compactMap { $0 as? String }) }
        return []
    }

    func edit(_ block: (inout JObj) -> Void) {
        lock.lock()
        block(&dict)
        let snapshot = dict
        lock.unlock()
        write(snapshot)
    }

    func set(_ k: String, _ v: Any?) {
        edit { d in
            if let v = v { d[k] = v } else { d.removeValue(forKey: k) }
        }
    }

    func remove(_ keys: String...) { edit { d in keys.forEach { d.removeValue(forKey: $0) } } }
    func clear() { edit { d in d.removeAll() } }
    func replaceAll(_ values: JObj) { edit { d in d = values } }

    private func write(_ snapshot: JObj) {
        guard let data = try? PropertyListSerialization.data(fromPropertyList: snapshot, format: .binary, options: 0) else { return }
        try? data.write(to: url, options: [.atomic, .completeFileProtectionUntilFirstUserAuthentication])
    }
}

// MARK: - Texto

enum Txt {
    static func norm(_ s: String) -> String {
        s.folding(options: [.diacriticInsensitive, .caseInsensitive], locale: Locale(identifier: "es_MX"))
            .lowercased()
            .replacingOccurrences(of: "_", with: " ")
    }

    static func words(_ s: String) -> [String] {
        norm(s).components(separatedBy: CharacterSet.alphanumerics.inverted).filter { !$0.isEmpty }
    }

    static func sha256(_ s: String) -> String {
        SHA256.hash(data: Data(s.utf8)).map { String(format: "%02x", $0) }.joined()
    }

    /// Igual que java.util.UUID.nameUUIDFromBytes (UUID versión 3 con MD5).
    static func nameUUID(_ s: String) -> String {
        var b = Array(Insecure.MD5.hash(data: Data(s.utf8)))
        b[6] = (b[6] & 0x0f) | 0x30
        b[8] = (b[8] & 0x3f) | 0x80
        let hex = b.map { String(format: "%02x", $0) }.joined()
        let c = Array(hex)
        return String(c[0..<8]) + "-" + String(c[8..<12]) + "-" + String(c[12..<16]) + "-" + String(c[16..<20]) + "-" + String(c[20..<32])
    }

    /// Hash estable de cadena (para ordenar el Top 10 del día).
    static func stableHash(_ s: String) -> UInt32 {
        var h: UInt32 = 5381
        for b in s.utf8 { h = (h &<< 5) &+ h &+ UInt32(b) }
        return h
    }

    static let pathAllowed: CharacterSet = {
        var c = CharacterSet.alphanumerics
        c.insert(charactersIn: "-._~")
        return c
    }()

    static func path(_ s: String) -> String { s.addingPercentEncoding(withAllowedCharacters: pathAllowed) ?? s }

    static let queryAllowed: CharacterSet = {
        var c = CharacterSet.alphanumerics
        c.insert(charactersIn: "-._~")
        return c
    }()

    static func query(_ s: String) -> String { s.addingPercentEncoding(withAllowedCharacters: queryAllowed) ?? s }

    static func year(_ s: String) -> Int? {
        guard let r = s.range(of: "(?<![0-9])(19|20)[0-9]{2}(?![0-9])", options: .regularExpression) else { return nil }
        return Int(s[r])
    }

    static func time(_ seconds: Double) -> String {
        guard seconds.isFinite, seconds > 0 else { return "0:00" }
        let t = Int(seconds)
        let h = t / 3600, m = (t % 3600) / 60, s = t % 60
        return h > 0 ? String(format: "%d:%02d:%02d", h, m, s) : String(format: "%d:%02d", m, s)
    }

    static func date(_ seconds: Int64) -> String {
        guard seconds > 0 else { return "" }
        let f = DateFormatter()
        f.locale = Locale(identifier: "es_MX")
        f.dateFormat = "dd/MM/yyyy"
        return f.string(from: Date(timeIntervalSince1970: TimeInterval(seconds)))
    }

    static func hour(_ d: Date) -> String {
        let f = DateFormatter()
        f.locale = Locale(identifier: "es_MX")
        f.dateFormat = "h:mm a"
        return f.string(from: d).lowercased()
    }

    static func decodeBase64(_ s: String) -> String {
        guard !s.isEmpty, let d = Data(base64Encoded: s, options: [.ignoreUnknownCharacters]),
              let t = String(data: d, encoding: .utf8) else { return s }
        return t
    }

    /// "exp_date" puede venir en segundos o milisegundos.
    static func seconds(_ s: String) -> Int64 {
        guard let n = Int64(s.trimmingCharacters(in: .whitespaces)) else { return 0 }
        return n > 100_000_000_000 ? n / 1000 : n
    }
}

extension String {
    var trimmed: String { trimmingCharacters(in: .whitespacesAndNewlines) }
    var nilIfEmpty: String? { trimmed.isEmpty ? nil : self }
}

// MARK: - Dispositivo

enum Device {
    static var id: String {
        let p = Prefs.named("dispositivo")
        let saved = p.str("id")
        if !saved.isEmpty { return saved }
        let fresh = (UIDevice.current.identifierForVendor?.uuidString ?? UUID().uuidString).replacingOccurrences(of: "-", with: "").lowercased()
        p.set("id", fresh)
        return fresh
    }

    static var name: String { "iPhone" }

    static func haptic(_ style: UIImpactFeedbackGenerator.FeedbackStyle = .light) {
        UIImpactFeedbackGenerator(style: style).impactOccurred()
    }

    static func success() { UINotificationFeedbackGenerator().notificationOccurred(.success) }
    static func error() { UINotificationFeedbackGenerator().notificationOccurred(.error) }

    static var screen: UIScreen? {
        (UIApplication.shared.connectedScenes.first { $0 is UIWindowScene } as? UIWindowScene)?.screen
    }

    static func openWhatsApp(_ text: String = "Hola, necesito ayuda con mi cuenta de Pacheco's TV") {
        let t = text.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? ""
        if let u = URL(string: "https://wa.me/\(Endpoints.whatsapp)?text=\(t)") {
            UIApplication.shared.open(u)
        }
    }
}

// MARK: - Registro de diagnóstico (sin direcciones ni contraseñas)

enum Diag {
    private static let lock = NSLock()
    private static let file = Prefs.dir.appendingPathComponent("registro.txt")

    static func log(_ text: String) {
        let f = DateFormatter()
        f.locale = Locale(identifier: "es_MX")
        f.dateFormat = "dd/MM HH:mm:ss"
        let line = "\(f.string(from: Date()))  \(text)\n"
        lock.lock(); defer { lock.unlock() }
        var all = (try? String(contentsOf: file, encoding: .utf8)) ?? ""
        all += line
        if all.count > 60_000 { all = String(all.suffix(40_000)) }
        try? all.write(to: file, atomically: true, encoding: .utf8)
    }

    static func read() -> String {
        lock.lock(); defer { lock.unlock() }
        return (try? String(contentsOf: file, encoding: .utf8)) ?? ""
    }

    static func clear() {
        lock.lock(); defer { lock.unlock() }
        try? FileManager.default.removeItem(at: file)
    }

    /// Descripción corta de un error de red, sin mostrar servidores.
    static func describe(_ e: Error) -> String {
        if let f = e as? Http.Fail {
            switch f.code {
            case -1: return "dirección no válida"
            case -2, -3: return "respuesta no válida del servidor"
            default: return "error \(f.code) del servidor"
            }
        }
        if let u = e as? URLError {
            switch u.code {
            case .notConnectedToInternet: return "sin internet"
            case .timedOut: return "tiempo agotado"
            case .appTransportSecurityRequiresSecureConnection: return "conexión bloqueada por iOS"
            case .serverCertificateUntrusted, .serverCertificateHasBadDate, .serverCertificateNotYetValid,
                 .serverCertificateHasUnknownRoot, .secureConnectionFailed: return "certificado del servidor no válido"
            case .cannotFindHost, .cannotConnectToHost, .dnsLookupFailed: return "el servidor no responde"
            case .networkConnectionLost: return "se perdió la conexión"
            case .cancelled: return "cancelado"
            default: return "error de red \(u.code.rawValue)"
            }
        }
        return "error \((e as NSError).code)"
    }
}
