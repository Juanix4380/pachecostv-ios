import Foundation
import SwiftUI

/// Abre la reproducción de películas, series y canales con su avance guardado.
extension AppModel {
    func playMovie(_ p: PosterItem, fromStart: Bool = false, ext: String? = nil) {
        var start: Double = 0
        if !fromStart, let w = library.find(.movie, p.contentId), w.canResume { start = Double(w.position) / 1000 }
        let req = PlayRequest(kind: .movie, contentId: p.contentId, title: p.title, subtitle: p.yearText, artwork: p.image,
                              candidates: Streams.movie(p.contentId, ext: ext ?? p.ext, session.creds), startAt: start)
        play(req)
    }

    func playSeries(_ p: PosterItem, info: SeriesInfo? = nil, episodeId: String? = nil, fromStart: Bool = false) async {
        var i = info
        if i == nil || (i?.seasons.isEmpty ?? true) {
            router.show("Cargando episodio…")
            i = await Xtream.seriesInfo(session.creds, p.contentId)
        }
        let seasons = i?.seasons ?? [:]
        let eps = seasons.keys.sorted().flatMap { seasons[$0] ?? [] }
        guard !eps.isEmpty else { router.show("No hay episodios disponibles"); return }
        var idx = 0
        var start: Double = 0
        let watched = library.find(.series, p.contentId)
        if let e = episodeId, let k = eps.firstIndex(where: { $0.id == e }) {
            idx = k
            if !fromStart, let w = watched, w.episodeId == e, w.canResume { start = Double(w.position) / 1000 }
        } else if let w = watched, let k = eps.firstIndex(where: { $0.id == w.episodeId }) {
            if w.canResume { idx = k; start = Double(w.position) / 1000 } else { idx = min(k + 1, eps.count - 1) }
        }
        let ep = eps[idx]
        let req = PlayRequest(kind: .series, contentId: p.contentId, title: ep.title, subtitle: "T\(ep.season) E\(ep.number) · \(ep.title)",
                              artwork: p.image, candidates: Streams.episode(ep, session.creds), startAt: start,
                              seriesTitle: p.title, episodes: eps, episodeIndex: idx)
        play(req)
    }

    func channelRequest(_ ch: Channel, in list: [Channel], landscape: Bool = true) -> PlayRequest {
        let l = list.isEmpty ? [ch] : list
        return PlayRequest(kind: .tv, contentId: ch.id, title: ch.name, artwork: ch.icon,
                           candidates: Streams.live(ch, session.creds, format: AppSettings.liveFormat),
                           channels: l, channelIndex: l.firstIndex { $0.id == ch.id } ?? 0, landscape: landscape)
    }

    func playChannel(_ ch: Channel, in list: [Channel]) {
        play(channelRequest(ch, in: list))
    }

    func open(_ p: PosterItem) {
        router.open(.detail(p))
    }
}
