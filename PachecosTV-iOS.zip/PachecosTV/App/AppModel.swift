import Foundation
import SwiftUI
import AVFoundation

enum PlayerPref: String, CaseIterable {
    case auto, native, vlc
    var title: String {
        switch self {
        case .auto: return "Automático"
        case .native: return "Nativo de iPhone (PiP y AirPlay)"
        case .vlc: return "VLC (todos los formatos)"
        }
    }
}

enum AppSettings {
    static var liveFormat: LiveFormat { LiveFormat(rawValue: UserDefaults.standard.string(forKey: "live_format") ?? "") ?? .auto }
    static var player: PlayerPref { PlayerPref(rawValue: UserDefaults.standard.string(forKey: "player_engine") ?? "") ?? .auto }
    static var autoNext: Bool { UserDefaults.standard.object(forKey: "auto_next") as? Bool ?? true }
    static var autoSkipIntro: Bool { UserDefaults.standard.bool(forKey: "auto_skip_intro") }
    static var showAdult: Bool { UserDefaults.standard.bool(forKey: "show_adult") }
}

enum Tab: Hashable { case home, live, search, clips, profile }

enum Route: Hashable {
    case detail(PosterItem)
    case catalog(Kind)
    case events
    case settings
    case manageProfiles
    case myList
    case account
    case log
}

struct PlayRequest: Identifiable {
    let id = UUID()
    var kind: Kind
    var contentId: String
    var title: String
    var subtitle: String = ""
    var artwork: String = ""
    var candidates: [String] = []
    var startAt: Double = 0
    var seriesTitle: String = ""
    var episodes: [Episode] = []
    var episodeIndex: Int = 0
    var channels: [Channel] = []
    var channelIndex: Int = 0
    var landscape: Bool = true

    var episode: Episode? { episodes.indices.contains(episodeIndex) ? episodes[episodeIndex] : nil }
    var channel: Channel? { channels.indices.contains(channelIndex) ? channels[channelIndex] : nil }
    var isLive: Bool { kind == .tv }
}

@MainActor
final class Router: ObservableObject {
    @Published var tab: Tab = .home
    @Published var player: PlayRequest? = nil
    @Published var tabBarHidden = false
    @Published var homePath: [Route] = []
    @Published var livePath: [Route] = []
    @Published var searchPath: [Route] = []
    @Published var clipsPath: [Route] = []
    @Published var profilePath: [Route] = []
    @Published var toast: String? = nil
    @Published var moreMenu = false
    @Published var upcoming: TmdbUpcoming? = nil

    private var toastTask: Task<Void, Never>?

    func open(_ r: Route) {
        switch tab {
        case .home: homePath.append(r)
        case .live: livePath.append(r)
        case .search: searchPath.append(r)
        case .clips: clipsPath.append(r)
        case .profile: profilePath.append(r)
        }
    }

    func show(_ message: String) {
        toastTask?.cancel()
        withAnimation(.spring(response: 0.35, dampingFraction: 0.85)) { toast = message }
        toastTask = Task { [weak self] in
            try? await Task.sleep(nanoseconds: 2_400_000_000)
            if Task.isCancelled { return }
            withAnimation(.easeOut(duration: 0.25)) { self?.toast = nil }
        }
    }

    func reset() {
        tab = .home
        homePath = []; livePath = []; searchPath = []; clipsPath = []; profilePath = []
        player = nil
        tabBarHidden = false
    }
}

/// Une todo: sesión, perfiles, catálogo, biblioteca del perfil y navegación.
@MainActor
final class AppModel: ObservableObject {
    let session = SessionStore()
    let profiles = ProfileManager()
    let catalog = CatalogStore()
    let library = LibraryStore()
    let router = Router()

    func boot() {
        guard session.isLoggedIn else { return }
        profiles.bind(session.cloud)
        catalog.start(session.creds, kids: false)
    }

    func afterLogin() async {
        router.reset()
        profiles.bind(session.cloud)
        catalog.start(session.creds, kids: false)
        await profiles.refreshFromCloud()
        autoEnterIfSingle()
    }

    func autoEnterIfSingle() {
        if profiles.active == nil, profiles.profiles.count == 1, let p = profiles.profiles.first, !p.hasPin {
            enter(p.index)
        }
    }

    func enter(_ index: Int) {
        profiles.enter(index)
        guard let p = profiles.active else { return }
        library.bind(session.cloud, index)
        catalog.start(session.creds, kids: p.kids)
        catalog.setKids(p.kids)
        router.reset()
        Task { await library.syncOnEntry() }
    }

    func switchProfile() {
        router.reset()
        profiles.leave()
        library.unbind()
        Task { await profiles.refreshFromCloud() }
    }

    func logout() {
        router.reset()
        profiles.leave()
        library.unbind()
        catalog.stop()
        session.logout()
        profiles.bind(session.cloud)
    }

    /// Reproducción bloqueada si la cuenta está vencida o desactivada.
    func play(_ r: PlayRequest) {
        if let b = session.blocked, b.blocks {
            Device.error()
            return
        }
        router.player = r
    }
}

enum Orientation {
    static func set(_ mask: UIInterfaceOrientationMask, rotate: UIInterfaceOrientationMask? = nil) {
        AppDelegate.mask = mask
        guard let scene = UIApplication.shared.connectedScenes.compactMap({ $0 as? UIWindowScene }).first else { return }
        for w in scene.windows {
            w.rootViewController?.setNeedsUpdateOfSupportedInterfaceOrientations()
            var top = w.rootViewController?.presentedViewController
            while let t = top {
                t.setNeedsUpdateOfSupportedInterfaceOrientations()
                top = t.presentedViewController
            }
        }
        scene.requestGeometryUpdate(.iOS(interfaceOrientations: rotate ?? mask)) { _ in }
    }
}

final class AppDelegate: NSObject, UIApplicationDelegate {
    static var mask: UIInterfaceOrientationMask = .portrait

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]? = nil) -> Bool {
        let s = AVAudioSession.sharedInstance()
        try? s.setCategory(.playback, mode: .moviePlayback, options: [])
        try? s.setActive(true)
        URLCache.shared = URLCache(memoryCapacity: 40 << 20, diskCapacity: 300 << 20, diskPath: "ptv-images")
        StreamProxy.shared.start()
        return true
    }

    func application(_ application: UIApplication, supportedInterfaceOrientationsFor window: UIWindow?) -> UIInterfaceOrientationMask {
        AppDelegate.mask
    }
}
