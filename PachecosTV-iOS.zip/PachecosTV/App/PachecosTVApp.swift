import SwiftUI

@main
struct PachecosTVApp: App {
    @UIApplicationDelegateAdaptor(AppDelegate.self) private var delegate
    @StateObject private var app = AppModel()

    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(app)
                .environmentObject(app.session)
                .environmentObject(app.profiles)
                .environmentObject(app.catalog)
                .environmentObject(app.library)
                .environmentObject(app.router)
                .preferredColorScheme(.dark)
                .tint(PTV.red)
        }
    }
}

struct RootView: View {
    @EnvironmentObject var app: AppModel
    @EnvironmentObject var session: SessionStore
    @EnvironmentObject var profiles: ProfileManager
    @EnvironmentObject var catalog: CatalogStore
    @EnvironmentObject var library: LibraryStore
    @EnvironmentObject var router: Router
    @Environment(\.scenePhase) private var phase
    @State private var splash = true

    private var stage: Int {
        if splash { return 0 }
        if !session.isLoggedIn { return 1 }
        if profiles.active == nil { return 2 }
        return 3
    }

    var body: some View {
        ZStack {
            PTV.bg.ignoresSafeArea()
            switch stage {
            case 0: SplashView().transition(.opacity)
            case 1: LoginView().transition(.opacity)
            case 2: ProfilePickerView().transition(.opacity.combined(with: .scale(scale: 1.04)))
            default: MainTabView().transition(.opacity.combined(with: .scale(scale: 0.98)))
            }
            if let b = session.blocked, b.blocks, session.isLoggedIn, stage >= 2 {
                AccessBlockView(state: b).zIndex(10)
            }
            if let t = router.toast {
                VStack { Spacer(); ToastView(text: t).padding(.bottom, 110) }
                    .transition(.move(edge: .bottom).combined(with: .opacity))
                    .allowsHitTesting(false)
                    .zIndex(20)
            }
        }
        .animation(.easeInOut(duration: 0.35), value: stage)
        .animation(.easeInOut(duration: 0.3), value: session.blocked)
        .fullScreenCover(item: $router.player) { req in
            PlayerContainer(request: req)
                .environmentObject(app)
                .environmentObject(session)
                .environmentObject(profiles)
                .environmentObject(catalog)
                .environmentObject(library)
                .environmentObject(router)
        }
        .task {
            app.boot()
            try? await Task.sleep(nanoseconds: 900_000_000)
            withAnimation { splash = false }
            if session.isLoggedIn {
                await profiles.refreshFromCloud()
                app.autoEnterIfSingle()
            }
        }
        .task(id: session.isLoggedIn) {
            while session.isLoggedIn && !Task.isCancelled {
                await session.checkAccess(force: true)
                try? await Task.sleep(nanoseconds: 300_000_000_000)
            }
        }
        .onChange(of: phase) { _, p in
            if p == .active {
                Task {
                    await session.checkAccess()
                    await library.pull()
                }
            }
        }
    }
}

// MARK: - Pestañas con barra flotante de vidrio (como la barra inferior de Android)

struct MainTabView: View {
    @EnvironmentObject var router: Router
    @EnvironmentObject var profiles: ProfileManager

    var body: some View {
        ZStack(alignment: .bottom) {
            TabView(selection: $router.tab) {
                NavigationStack(path: $router.homePath) {
                    HomeView().routes()
                }
                .toolbar(.hidden, for: .tabBar)
                .tag(Tab.home)

                NavigationStack(path: $router.livePath) {
                    LiveTVView().routes()
                }
                .toolbar(.hidden, for: .tabBar)
                .tag(Tab.live)

                NavigationStack(path: $router.searchPath) {
                    SearchView().routes()
                }
                .toolbar(.hidden, for: .tabBar)
                .tag(Tab.search)

                NavigationStack(path: $router.clipsPath) {
                    ClipsView().routes()
                }
                .toolbar(.hidden, for: .tabBar)
                .tag(Tab.clips)

                NavigationStack(path: $router.profilePath) {
                    MyProfileView().routes()
                }
                .toolbar(.hidden, for: .tabBar)
                .tag(Tab.profile)
            }
            if !router.tabBarHidden {
                FloatingTabBar()
                    .padding(.horizontal, 16)
                    .padding(.bottom, 6)
                    .transition(.move(edge: .bottom).combined(with: .opacity))
            }
            if router.moreMenu { MoreMenuView().zIndex(5).transition(.opacity) }
        }
        .ignoresSafeArea(.keyboard)
        .animation(.spring(response: 0.35, dampingFraction: 0.85), value: router.tabBarHidden)
        .animation(.easeInOut(duration: 0.2), value: router.moreMenu)
        .sheet(item: $router.upcoming) { u in UpcomingSheet(item: u).presentationDetents([.large]).presentationBackground(.ultraThinMaterial) }
    }
}

struct FloatingTabBar: View {
    @EnvironmentObject var router: Router
    @EnvironmentObject var profiles: ProfileManager
    @Namespace private var ns

    private struct Item: Identifiable {
        let tab: Tab
        let icon: String
        let label: String
        var id: Tab { tab }
    }

    private let items = [
        Item(tab: .home, icon: "house.fill", label: "Inicio"),
        Item(tab: .live, icon: "dot.radiowaves.left.and.right", label: "TV en vivo"),
        Item(tab: .search, icon: "magnifyingglass", label: "Buscar"),
        Item(tab: .clips, icon: "play.rectangle.on.rectangle.fill", label: "Avances")
    ]

    var body: some View {
        HStack(spacing: 0) {
            ForEach(items) { it in
                button(it.tab) {
                    Image(systemName: it.icon).font(.system(size: 20, weight: .semibold))
                        .symbolEffect(.bounce, value: router.tab == it.tab)
                }
                .accessibilityLabel(it.label)
            }
            button(.profile) {
                AvatarView(avatar: profiles.active?.avatar ?? 0, size: 28, selected: router.tab == .profile)
            }
            .accessibilityLabel("Mi perfil")
        }
        .frame(height: 62)
        .padding(.horizontal, 6)
        .glass(RoundedRectangle(cornerRadius: 34, style: .continuous), tint: Color.black)
        .shadow(color: .black.opacity(0.5), radius: 20, y: 8)
    }

    private func button<Content: View>(_ tab: Tab, @ViewBuilder content: () -> Content) -> some View {
        Button {
            Device.haptic()
            if router.tab == tab {
                switch tab {
                case .home: router.homePath = []
                case .live: router.livePath = []
                case .search: router.searchPath = []
                case .clips: router.clipsPath = []
                case .profile: router.profilePath = []
                }
            }
            router.tab = tab
        } label: {
            VStack(spacing: 6) {
                content()
                    .foregroundStyle(router.tab == tab ? Color.white : Color.white.opacity(0.55))
                ZStack {
                    if router.tab == tab {
                        Capsule().fill(PTV.red).frame(width: 18, height: 3)
                            .matchedGeometryEffect(id: "underline", in: ns)
                    } else {
                        Capsule().fill(Color.clear).frame(width: 18, height: 3)
                    }
                }
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .contentShape(Rectangle())
        }
        .buttonStyle(PressScale(scale: 0.9))
        .animation(.spring(response: 0.35, dampingFraction: 0.8), value: router.tab)
    }
}

extension View {
    func routes() -> some View {
        navigationDestination(for: Route.self) { r in RouteView(route: r) }
    }
}

struct RouteView: View {
    let route: Route
    var body: some View {
        switch route {
        case .detail(let p): DetailView(item: p)
        case .catalog(let k): CatalogView(kind: k)
        case .events: EventsView()
        case .settings: SettingsView()
        case .manageProfiles: ManageProfilesView()
        case .myList: MyListView()
        case .account: AccountView()
        }
    }
}
