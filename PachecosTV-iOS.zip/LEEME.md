# Pacheco's TV para iPhone (1.6.23)

Versión de la app Android 1.6.23, solo modo teléfono. La misma cuenta, los mismos perfiles, el mismo PIN y el historial se comparten con Android.

## Compilar en GitHub (desde el teléfono)

1. Crea un repositorio nuevo en GitHub.
2. Sube **PachecosTV-iOS.zip** tal cual a la raíz del repositorio.
3. Crea el archivo del flujo: **Add file → Create new file**.
   - Nombre: `.github/workflows/build.yml`
   - Contenido: pega el contenido de **build.yml**.
   - Guarda con **Commit changes**.
4. Ve a **Actions**. La compilación arranca sola y tarda de 10 a 20 minutos.
5. Cuando termine, el archivo **PachecosTV.ipa** aparece en **Releases** (y también en la sección *Artifacts* de la compilación).

Si quieres volver a compilar, entra a **Actions → Compilar Pacheco's TV iPhone → Run workflow**.

## Instalar en el iPhone con Sideloadly

1. En la PC, abre Sideloadly y conecta el iPhone por cable.
2. Arrastra **PachecosTV.ipa** a Sideloadly.
3. Escribe tu Apple ID y pulsa **Start**.
4. En el iPhone, ve a **Ajustes → General → VPN y gestión de dispositivos** y confía en tu Apple ID.
5. En iOS 16 o posterior, activa **Ajustes → Privacidad y seguridad → Modo de desarrollador** y reinicia el iPhone.

- **Apple ID gratuito**: la app dura 7 días; después vuelve a instalarla con Sideloadly. Puedes tener hasta 3 apps así.
- **Cuenta de desarrollador de Apple**: la app dura 1 año.

Requisitos: iPhone con iOS 17 o posterior (iPhone XS o más nuevo). En iOS 26 se usa el diseño Liquid Glass. En versiones anteriores se usa vidrio esmerilado.

## Funciones incluidas

- **Inicio de sesión**: igual que Android, con las cuentas guardadas en verde (vigente), rojo (vencida) y gris (sin revisar). Si ya hay una sesión, la app entra directo.
- **Perfiles**: hasta 10, con avatares, perfil Kids, PIN de 4 números y recuperación del PIN con la contraseña de la cuenta. Todo se sincroniza con la nube y con los equipos Android.
- **Control de cuenta**: una cuenta vencida, desactivada o con la sesión vencida no reproduce nada y muestra el aviso con el QR de soporte.
- **Inicio**:
  - Banner de estrenos con el fondo del color de la portada.
  - Filas: Continuar viendo, Mi lista, Top 10 de hoy, Eventos en vivo, Próximamente, Películas nuevas, Series nuevas y filas por género.
  - Barra superior: Películas, Series, Deportes y Más.
- **Películas y Series**: categorías, búsqueda, orden, detalle con reparto, logo del título, tráiler, temporadas, episodios y "Más como esto".
- **TV en vivo**:
  - Vista previa arriba; desliza el video a los lados para cambiar de canal.
  - Guía de programación, favoritos, canales recientes y pantalla completa con la lista de canales.
- **Deportes**: partidos del día de todas las ligas, marcador en vivo y los canales que transmiten cada partido.
- **Avances**: películas recientes en pantalla completa, deslizando hacia arriba.
- **Reproductor**:
  - Gestos: brillo con la mitad izquierda, volumen con la derecha, doble toque para ±10 s y pellizcar para llenar la pantalla.
  - Bloqueo de controles; audio y subtítulos; velocidad; formato.
  - Series: saltar intro, siguiente episodio automático y lista de episodios.
  - Imagen en imagen y AirPlay.
  - Sigue sonando con la pantalla bloqueada y tiene controles en la pantalla de bloqueo.
- **Formatos**: usa el reproductor del iPhone para HLS y MP4, y VLC para .ts, .mkv, .avi y los demás. Si un formato falla, cambia solo al otro reproductor y luego a los servidores alternos.
- **Mi perfil**: cambio de perfil, Mi lista, Continuar viendo, datos de la cuenta, ajustes, actualizar listas, soporte por WhatsApp y cerrar sesión.

## Diferencias con Android

- No hay transmisión a Chromecast, Roku ni Firestick; en su lugar se usa AirPlay (Apple TV y televisores compatibles).
- No están la multipantalla ni las descargas sin conexión.
- La búsqueda por voz se hace con el dictado del teclado del iPhone.
